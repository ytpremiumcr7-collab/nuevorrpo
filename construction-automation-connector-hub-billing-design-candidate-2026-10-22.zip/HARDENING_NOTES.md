# Auditoría de hardening — Construction Automation REAL-PROOF

**Estado:** candidato endurecido, NO release aprobado. Fecha de revisión local: 21 de octubre de 2026. El archivo original `construction-automation-REAL-PROOF.aaf` se conserva sin modificar; los cambios viven en una copia de trabajo.

## Cambios aplicados

1. **Autenticación y contexto de tenant.** `X-User-Id` desactivado por defecto; API key validada por hash y tenant en una transacción; contexto PostgreSQL establecido con `set_config(..., true)` durante la transacción; usuario global OWNER dejó de inferirse a partir de una membresía de proyecto.
2. **Bootstrap de primer usuario.** Se exige secreto de despliegue; se compara en tiempo constante; una fila del tenant serializa el bootstrap; se crea un proyecto inicial si no se proporciona uno; la API key se entrega solo una vez.
3. **Autorización por proyecto.** Helper central para recursos concretos; varias mutaciones comprueban proyecto/rol y varios actores dejan de ser aceptados desde el body HTTP. Asignación de roles reservada al OWNER del proyecto.
4. **Consultas operativas.** Dashboard, cola de compliance y facturas requieren transacción para RLS, limitan resultados y filtran por membresía del usuario.
5. **Pagos.** Los IDs del request deben coincidir con la factura persistida; el monto no excede el monto facturado; proyecto/contrato/subcontratista se validan; se revalida compliance y versión; el registro queda `PENDING` con `executed_at = NULL`. La idempotencia también está reforzada por índice único en migración.
6. **Three-way match y BPMN.** El PO debe pertenecer al proyecto de la factura; líneas duplicadas/extra/faltantes bloquean; las compuertas BPMN de match y compliance son fail-closed.
7. **Procesamiento e integración.** Tipos de evento outbox sin handler hacen retry/dead-letter, no se marcan procesados; Procore inbound y envío de ofertas devuelven 501 explícito hasta resolver identidad, firma, tenant routing y procesamiento correctos.
8. **Secretos y permisos.** Se retiró la contraseña fija de `app_user`; se endurece el rol y se revoca `DELETE` a ese rol. El bootstrap token/HMAC/contraseñas se requieren mediante configuración.

## Verificación realizada

| Comprobación | Resultado | Qué demuestra |
|---|---|---|
| `python scripts/verify-hardening-static.py` | 13/13 PASS (actualizado en esta candidata) | Invariantes de texto/código presentes; no prueba runtime |
| `bash scripts/prove-construction-niche.sh` | PASS | Archivos/patrones principales existen; no prueba comportamiento |
| `bash -n` sobre scripts shell | PASS | Sintaxis de scripts shell |
| `node --check` en JavaScript | PASS | Parseo de scripts frontend |
| `xml.etree.ElementTree` sobre XML; PyYAML sobre YAML; JSON parser | PASS | Archivos parsean estructuralmente |
| Maven / JUnit / Testcontainers | NO EJECUTADO | Maven no está disponible en el entorno |
| PostgreSQL / Flyway / RLS real | NO EJECUTADO | `psql` y Docker no están disponibles |
| Deploy BPMN/DMN en Camunda | NO EJECUTADO | Sin motor desplegado para validación runtime; el gate estático exige el enlace DMN y la ruta manual fail-closed |

## Bloqueadores antes de producción

### P0 — gates de pago y aprobación

`nivelAprobacionPago.dmn` no está conectado al proceso BPMN. No existe en el flujo un registro durable de aprobación humana/política verificada; no se debe afirmar que un `PENDING` es un pago autorizado, ejecutado o liquidado. No hay proveedor bancario ni callback de liquidación. Mantener `PENDING`; no abrir transferencias reales sin workflow de aprobación, tabla/auditoría de aprobaciones, idempotency key del proveedor, conciliación y manejo de estados de error.

### P0/P1 — aislamiento y validación del worker de outbox

La candidata ahora crea `outbox_worker`, un pool/`DataSource` separado y revoca `EXECUTE` de `claim_projection_outbox(integer)` a `app_user`. También incrementa intentos al reclamar para que un worker caído no reintente infinitamente sin contabilización. Esto reduce la exposición, pero permanece sin verificación de runtime: `verify-gates.sh` debe confirmar que el rol se provisionó como LOGIN sin SUPERUSER/BYPASSRLS, que solo él ejecuta el claim y que se aplicó V17 sobre PostgreSQL real. En despliegues fuera de Docker el operador debe provisionar la contraseña del rol de forma segura antes de habilitar el worker.

### P1 — autorización y pertenencia a obra en toda la API

Los controllers principales recibieron guardas, pero no se ha demostrado una matriz completa para todos los endpoints, workers programados, delegates BPMN y servicios internos. Se necesitan pruebas negativas multi-tenant y por proyecto. Los IDs de actor, entidad, proyecto, documento, contrato y parte legal deben derivarse del principal o comprobarse contra registros de base de datos, nunca confiarse solo a valores del cliente.

### P1 — infraestructura y migración

- V17 no se ha ejecutado en PostgreSQL limpio ni sobre copia de datos existentes. El índice único de pago puede encontrar duplicados históricos y detener el despliegue; medir antes de migrar.
- Los scripts `docker-entrypoint-initdb.d` se ejecutan solo al inicializar un volumen nuevo. Cambiar `.env` no cambia contraseñas de un volumen PostgreSQL existente; requiere un procedimiento de rotación administrado.
- `application.yml` exige credenciales por variables; la combinación de perfiles debe verificarse en Compose de producción y en una instalación fuera de Docker.
- **Migraciones aisladas:** Compose ejecuta Flyway en el servicio corto `migrator`; `SPRING_FLYWAY_ENABLED=false` en el contenedor HTTP. El usuario de migración sigue siendo el owner/configurado de DB y requiere controles de despliegue; validar este límite en un entorno real.
- **Decisión de aprobación enlazada con fail-closed:** `paymentApprovalProcess` evalúa `nivelAprobacionPago` después del three-way match. La policy solo permite ruta automática para MXN bajo el umbral; moneda desconocida, ruta manual o salida inválida detienen el pago. Antes de registrar la instrucción se inserta evidencia `POLICY/APPROVED` con versión exacta de DMN y una restricción única por solicitud. Sigue faltando un servicio autenticado de aprobación humana para la ruta manual; esta ruta queda bloqueada a propósito.
- Las métricas de health actuator y endpoints administrativos aún requieren verificar controles de acceso, información expuesta y límites de red en entorno real.

### P1 — integrations

- Procore inbound quedó cerrado porque la implementación anterior encolaba el evento inbound como outbound. Se necesita autenticidad del emisor, vinculación tenant/project, deduplicación de evento, firma/rotación de secretos y handler inbound.
- Envío de ofertas quedó cerrado hasta asociar cada usuario autenticado con una `party` verificada. No aceptar `bidderId` libre desde HTTP.
- Notificaciones/transporte y generación OSHA requieren pruebas reales y revisión normativa antes de activar envío externo.

## Puerta de aceptación de release

No firmar GO-LIVE hasta que se demuestre en un runner con JDK 21, Maven, Docker y PostgreSQL: `mvn clean verify`; `docker compose config`; migración desde base vacía; `RlsIsolationTest` y pruebas con roles no propietarios; autorización cruzada entre proyectos; outbox concurrente y recuperación de crash; despliegue y ejecución de cada BPMN/DMN; pruebas negativas de pagos; y verificación/restore de backup. El resultado de la revisión actual es una **candidata para la siguiente iteración de hardening**, no software certificado para producción.
