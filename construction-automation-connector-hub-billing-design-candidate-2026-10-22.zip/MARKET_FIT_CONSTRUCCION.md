# Market Fit — Nicho Construcción (Logiclot / vertical automation)

## Qué pide el mercado (guía nichos 2025-2026)

### Cumplimiento de subcontratistas
| Requisito mercado | Estado en sistema |
|-------------------|-------------------|
| Recopilación/verificación de certificados de seguro, licencias, certificaciones de seguridad | ✅ `compliance_requirement` + verify/revoke + head proyectada |
| Seguimiento de vencimientos | ✅ `fecha_vencimiento` + **ComplianceExpirationSweepJob** (30d / 7d / vencido) |
| Recordatorios de renovación | ✅ `notification_outbox` → NotificationWorker |
| Bloqueo de pago si compliance no vigente | ✅ fencing + DMN + boundary BPMN |
| Versionado / no pagar con compliance obsoleto | ✅ VersionFencingTest (4 escenarios) |

### Documentación del proyecto
| Requisito mercado | Estado en sistema |
|-------------------|-------------------|
| RFI enrutamiento y aprobación | ✅ política BD `rfi_routing_policy` + BPMN `rfiProcess` |
| Órdenes de cambio | ✅ CO + approve → `billing_contract_projection` |
| Presentaciones (submittals) | ✅ tabla + API submit/review/list |
| Informes diarios | ✅ `daily_report` + API |
| Almacenamiento documental | ✅ `/api/files` SHA-256 + local storage |

### Coordinación manual / sistemas desconectados (dolor McKinsey)
| Requisito mercado | Estado en sistema |
|-------------------|-------------------|
| Pagos con 3-way match | ✅ ThreeWayMatchDelegate + tolerancia |
| Invalidación + compensación | ✅ cadena unidireccional + recovery_account |
| Seguridad OSHA plazos | ✅ OshaDeadlineSweepJob desde `occurred_at` |
| Permisos por jurisdicción | ✅ fail-loud sin config de plazo |
| Bidding / adjudicación | ✅ award atómico + justificación |
| Multi-tenant RLS | ✅ app_user NOSUPERUSER NOBYPASSRLS |

## Por qué poca competencia (alineado al artículo)
- Software genérico de "automatización CRM" no conoce compliance de obra, OSHA, RFI ni three-way match.
- Procore/Autodesk cubren parte del stack pero no el **cierre financiero con version fencing** ni compensación post-pago con evidencia.
- El conocimiento de dominio está en reglas (DMN, calendarios de negocio, políticas de enrutamiento) en BD, no hardcodeadas.

## Gaps aceptados (siguiente ola)
1. Frontend operativo (colas compliance, RFIs, pagos) — API lista
2. Identity real (JWT/roles por obra)
3. Integración Procore / ACL import
4. Progress 6.2 (SfM/MLOps)
5. Plantillas de documentos contractuales (ensamblaje)

## Precio orientativo del nicho (referencia artículo)
- Implementación vertical especializada: premium vs genérico
- Ingresos recurrentes: mantenimiento + monitorización de vencimientos/compliance
- DSO / multi-obra: 3–10× vs single site

Este backend está diseñado para ser el **motor de semi-automatización de obra** que un front vertical y un equipo de operaciones consumen extremo a extremo.
