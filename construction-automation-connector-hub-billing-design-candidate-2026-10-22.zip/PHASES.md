# Fases del sistema

## Fase 0 — Fundación

**Estado: implementada**

- Shared kernel: `project`, `party`, `party_role`, `site`, `contract`, `contract_party`, `work_package`, `document`, `shared_kernel_party_map`
- Audit con hash chain verificado (`compute_event_hash`, `verify_audit_chain`) + trigger append-only
- Outbox con lease, `SKIP LOCKED`, backoff exponencial, DLQ
- Multi-tenancy: RLS + `app_user` NOBYPASSRLS + `TenantContextFilter`
- Health indicator real (no `UP` vacío)
- Métricas Prometheus
- MDC con `tenantId`, `traceId`

**Gate**: evento de prueba atraviesa bus → audit → proyección; 2 tenants aislados.

## Fase 1 — Contextos hoja

**Estado: parcialmente implementada**

- Bidding: completo (service, controller, BPMN, tests de concurrencia)
- ProjectDocuments: completo (service, controller, BPMN para RFI y CO)
- Safety: completo (service, controller, BPMN, OSHA sweep job)
- Permits: completo (service, controller, BPMN con config de plazo)
- Progress: **pendiente** (`ProgressService`, BPMN de certificación, pipeline 6.2)

**Gate**: cada contexto tiene point of no return documentado; shadow mode en piloto.

## Fase 2 — Compliance

**Estado: completa**

- `compliance_subcontractor_head`, `compliance_requirement`
- `ComplianceService` con `addRequirement`, `verify`, `revoke`
- DMN `complianceVigente` (hitPolicy=FIRST, 6 reglas)
- `ComplianceProjectorSync` (mismo tx que el evento) + `ComplianceAsyncProjector` (solo columnas permitidas)
- `VerificarComplianceDelegate` con `version fencing`
- `boundaryEvent` de mensaje `ComplianceRevokedMessage` en `paymentApprovalProcess`
- `VersionFencingTest` (4 escenarios)

**Gate**: 4 tests de fencing verdes; 50 casos reales auditados con 0 falsos negativos; primera revocación real que bloquea un pago.

## Fase 3 — Billing

**Estado: completa para happy path + fallos**

- `invoice`, `purchase_order`, `goods_receipt` con líneas
- `three_way_match_result` (tabla normalizada, no JSONB)
- `payment_application`, `payment`, `payment_read_model`, `payment_invalidation`
- `ThreeWayMatchDelegate` real (no hardcoded)
- `nivelAprobacionPago` DMN (hitPolicy=FIRST)
- `PaymentApplicationService.submit` (valida compliance antes de crear proceso)
- `PaymentInvalidationService.invalidate` (con unicidad lógica por evidence)
- `PaymentInvalidatedEventHandler` (flujo unidireccional)
- `RegistrarPagoDelegate`
- `paymentApprovalProcess.bpmn` (8 tareas + boundaries)
- `EndToEndHappyPathTest` vía REST
- `ThreeWayMatchFailLoudTest`

**Gate**: shadow mode 8 semanas con 0 CRITICAL; primer pago real ejecutado; runbook de cutover documentado.

## Fase 4 — Compensación y disputa

**Estado: implementada**

- `compensation_case`, `recovery_account`, `deduction_log`
- `dispute_case`, `dispute_case_current`, `dispute_case_history`, `dispute_provision_snapshot`, `evidence_manifest`, `business_calendar`, `legal_interest_rate`, `dispute_phase_config`
- `CompensationService`, `DisputeService`
- `ApplyDeductionDelegate` con `UPDATE ... WHERE version=? AND saldo>=?`
- `ReverseDeductionDelegate` (idempotente)
- `GenerateEvidenceManifestDelegate` (HMAC obligatorio)
- `SendFormalNoticeDelegate` (fail-loud si estado no es NOTICE_PREPARED)
- `DisputeDeadlineJob` (con `time_unit`), `ProvisionSnapshotJob`
- `compensationCaseProcess`, `disputeCaseProcess`
- DMN `recoveryMethodDecision`, `disputeResolutionDecision`
- `RecoveryAccountConcurrencyTest`, `DisputeDeadlineTest`, `DisputeCalendarChangeTest`

**Gate**: 20 casos sintéticos + 1 caso real de bajo monto; ciclo auditable completo.

## Fase 5 — Cierre de puentes

**Estado: pendiente de implementación completa**

- Registro de puentes P0-P7 documentado
- Shared kernel como fuente única de datos maestros (retirar sync)
- Reconstrucción de proyecciones desde event store probada
- Retiro formal de cada puente con test de retiro

**Gate**: 0 puentes activos, 0 divergencias CRITICAL.

## Fase 6 — Visión por computadora

**Estado: parcialmente implementada (agregados), pendiente pipeline 6.2**

- **6.1 Implementado**: `bim_element_observation`, `progress_observation`, `progress_certified_read_model` con invariantes I1-I11 y P1-P8
- **6.2 Pendiente**: arquitectura edge/cloud, SfM/SLAM, crosswalk IFC, model registry, drift detection, MLOps

**Gate 6.1**: `PROGRESS_CERTIFIED` con intervalo de confianza; Billing solo lee `progress_certified_read_model`.

**Gate 6.2**: pipeline entrenado con datasets reales del piloto; precisión calibrada.

## Fase transversal — Identity

**Estado: pendiente**

- Actualmente `X-Tenant-Id` es un header libre; en producción necesita authN/authZ real
- Recomendación: OIDC + JWT con `tenant_id` en claims
- Sin esto, el sistema es funcional pero no multi-usuario seguro
