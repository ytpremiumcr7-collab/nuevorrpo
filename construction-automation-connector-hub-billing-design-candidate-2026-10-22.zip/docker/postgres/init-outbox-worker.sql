-- Worker independiente para reclamar/procesar outbox transversal con privilegio mínimo.
DO $$
BEGIN
    IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'outbox_worker') THEN
        CREATE ROLE outbox_worker WITH NOLOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
    END IF;
END $$;
GRANT CONNECT ON DATABASE construction TO outbox_worker;
