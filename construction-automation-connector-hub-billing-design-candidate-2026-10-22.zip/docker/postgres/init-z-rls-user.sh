#!/usr/bin/env bash
set -euo pipefail
: "${APP_DB_PASSWORD:?APP_DB_PASSWORD must be set when initializing PostgreSQL}"
psql --username "${POSTGRES_USER:-postgres}" --dbname "${POSTGRES_DB:-construction}"   --set=app_password="$APP_DB_PASSWORD" <<'SQL'
ALTER ROLE app_user WITH LOGIN PASSWORD :'app_password'
    NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
SQL
