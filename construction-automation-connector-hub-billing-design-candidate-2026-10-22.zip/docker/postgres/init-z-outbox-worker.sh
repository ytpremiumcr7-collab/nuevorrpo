#!/usr/bin/env bash
set -euo pipefail
: "${OUTBOX_DB_PASSWORD:?OUTBOX_DB_PASSWORD must be set when initializing PostgreSQL}"
psql --username "${POSTGRES_USER:-postgres}" --dbname "${POSTGRES_DB:-construction}" \
  --set=worker_password="$OUTBOX_DB_PASSWORD" <<'SQL'
ALTER ROLE outbox_worker WITH LOGIN PASSWORD :'worker_password'
    NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
SQL
