# Contributing and validation

1. Work on a topic branch and open a pull request; do not push feature work directly to `main`.
2. Never include real secrets, `.env`, personal data, production snapshots, compiled build output, or real payment/bank artifacts.
3. Before proposing changes, run: `bash -n run.sh test.sh scripts/*.sh`, `python3 scripts/verify-hardening-static.py`, `python3 scripts/verify-workflow-models.py`, `bash scripts/prove-construction-niche.sh`, `docker compose --env-file .env.example -f docker-compose.yml config --quiet`, and `mvn -B -ntp clean verify` on a JDK 21 host with Docker available for Testcontainers.
4. Schema migrations must fail closed, preserve tenant isolation, and include migration tests for a clean database and supported upgrade path. Do not rewrite an applied migration.
5. Workflow, permissions, branch protection, and dependency changes require explicit review. Third-party GitHub Actions must be pinned to full commit SHAs.
6. Payment policy must be fail-closed. A BPMN/DMN structural test is not proof of authorization, durable human approval, bank execution, or reconciliation.
