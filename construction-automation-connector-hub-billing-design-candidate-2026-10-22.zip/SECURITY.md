# Security policy

## Reporting a vulnerability

Do not publish exploit details, credentials, personal data, or production identifiers in a public issue. Use GitHub's private vulnerability reporting / Security Advisories for this repository when available. If that feature is not enabled, contact the repository owner privately through a verified channel and include a minimal reproduction, impact, affected version/commit, and suggested mitigation.

## Release posture

This repository is a hardening candidate until the CI build, PostgreSQL/RLS/Testcontainers, Camunda runtime, migration and recovery gates pass. Payment instructions are not bank transfers. Do not enable real payment execution or external integration callbacks without a reviewed threat model and explicit deployment approval.

Never commit `.env` files, tokens, credentials, signing keys, production data, or database dumps. Rotate any credential that may have been exposed.
