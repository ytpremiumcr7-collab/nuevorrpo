# Estado verificable del sistema Construction Automation

Este archivo distingue presencia de código, validación estática y evidencia de ejecución. **No es una certificación de producción.**

## Inventario de fuentes

El árbol contiene Java de producción y pruebas, migraciones PostgreSQL/Flyway, procesos BPMN/decisiones DMN, frontend estático, scripts y configuración Docker. Las cifras se pueden volver a calcular desde el repositorio:

```bash
find src/main/java -name '*.java' | wc -l
find src/test/java -name '*.java' | wc -l
find src/main/resources/db/migration -name 'V*__*.sql' | wc -l
find src/main/resources/bpmn -name '*.bpmn' | wc -l
find src/main/resources/dmn -name '*.dmn' | wc -l
```

El tamaño del ZIP mide código fuente, no el JAR desplegable ni las imágenes de dependencias. Para generar el artefacto se requiere Maven, JDK compatible y resolver dependencias; para ejecutar flujos completos se requiere PostgreSQL y el motor Camunda.

## Evidencia actualmente ejecutable en el entorno de revisión

- `scripts/prove-construction-niche.sh`: prueba estructural por presencia de archivos/cadenas. Es un inventario de cobertura, no prueba comportamiento.
- `scripts/verify-hardening-static.py`: comprobaciones estáticas sobre controles de autenticación, bootstrap, pagos, gates BPMN, autorización de colas y fail-closed en integraciones incompletas. No compila ni ejecuta la aplicación.
- XML, YAML, JSON, JavaScript y scripts shell se pueden validar sintácticamente por separado.

## Flujo de pago: límite funcional explícito

El flujo calcula el three-way match con factura, orden de compra y recibos, verifica el estado global/proyección de compliance y comprueba la versión vista antes de crear una instrucción `PENDING`. **No efectúa transferencia bancaria, no confirma liquidación y no tiene una integración bancaria.** La decisión DMN `nivelAprobacionPago.dmn` existe, pero no estaba conectada al BPMN; no se debe describir como una aprobación operativa ya aplicada. La ruta de éxito del BPMN exige una evidencia de match explícita; ante ausencia o inconsistencia, la ruta queda bloqueada.

## Integraciones cerradas hasta completar su contrato

- **Webhook inbound Procore:** responde `501 Not Implemented`. En la versión original se enviaba el payload inbound al método de cola outbound, que no constituye un adaptador inbound correcto. Se requiere verificar la firma de Procore, resolver tenant/proyecto, deduplicar eventos y procesar el evento con un handler inbound antes de abrirlo.
- **Envío de ofertas:** responde `501 Not Implemented` hasta disponer de un vínculo verificado entre el usuario autenticado y la parte legal (`party`). No se confía en un `bidderId` controlado por el cliente.
- **Generación de formularios OSHA:** sigue cerrada hasta completar y revisar el mapeo legal y documental correspondiente.
- **Tres-way match y pagos:** requieren pruebas con datos reales controlados, migraciones aplicadas y revisión de Finanzas/Legal; este sistema no debe tratar el estado `PENDING` como dinero pagado.

## Criterio de aceptación

No marcar una capacidad como entregada solo porque existe una clase, un archivo BPMN/DMN, una migración o una cadena estática. Para aceptar un release se requiere, como mínimo, compilación Maven limpia, suite JUnit/Testcontainers verde, migración Flyway sobre PostgreSQL limpio, pruebas negativas de RLS y autorización por obra, prueba de recuperación/idempotencia del outbox, despliegue real del BPMN/DMN y revisión de los gaps abiertos de `HARDENING_NOTES.md`.


## Snapshot congelado — 2026-10-22

La candidata incluye migraciones V18–V21, hardening de idempotencia/reservas y una compuerta BPMN conectada a la DMN `nivelAprobacionPago`. La ruta automática está limitada a MXN bajo el umbral y registra evidencia durable/versionada antes de crear una instrucción `PENDING`; moneda distinta o ruta manual termina sin crear instrucción, porque aún no hay servicio de aprobación humana verificable. Las pruebas estáticas reproducibles son:

```bash
python3 scripts/verify-hardening-static.py
python3 scripts/verify-workflow-models.py
for file in run.sh test.sh scripts/*.sh; do bash -n "$file"; done
```

En el entorno usado para congelar este paquete no están disponibles Maven, Docker ni `psql`. No se ejecutó `mvn test`, Testcontainers, Flyway contra PostgreSQL ni despliegue Camunda. No se debe interpretar el resultado estático como compilación, migración exitosa o autorización de producción. La DMN ya se invoca desde BPMN y la ruta automática persiste evidencia de política antes del pago; la rama manual es fail-closed, pero todavía falta servicio autenticado de aprobación humana, prueba real de despliegue Camunda y validación runtime. Las instrucciones generadas por la ruta automática siguen en `PENDING`; nunca son una transferencia ejecutada.
