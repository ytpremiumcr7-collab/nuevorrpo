# Changelog

## [1.0.0-SNAPSHOT] — Parte 4

### Añadido
- V12: creación idempotente de `app_user` (NOSUPERUSER NOBYPASSRLS) para RLS real en tests y prod
- DMN `complianceVigente` (hitPolicy=FIRST, 6 reglas: REVOCADO, RECHAZADO, PENDIENTE, EXPIRADO, vencido, vigente)
- DMN `nivelAprobacionPago` (hitPolicy=FIRST, solo depende de montoFactura)
- `BiddingAwardConcurrencyTest` (8 threads, solo 1 gana)
- `OutboxClaimConcurrencyTest` (2 claimers, SKIP LOCKED)
- `RecoveryAccountConcurrencyTest` (8 threads, no overshoot)
- `RlsIsolationTest` (SET LOCAL ROLE app_user)
- `EndToEndHappyPathTest` (HTTP + servicio + BPMN + BD + audit chain)
- `DisputeCalendarChangeTest` (agregar festivo extiende deadline)
- Seeds: `db/seed/01-04_*.sql`
- `TRACEABILITY.md`, `PHASES.md`, `GO-LIVE-CHECKLIST.md`
- `scripts/verify-invariants.sh`, `scripts/verify-gates.sh`
- `.env.example`, `.gitignore`, `application-prod.yml`, `docker-compose.prod.yml`, `prometheus.yml`
- `THIRD-PARTY.md` con licencias

### Corregido
- **Deadlock en `OutboxPoller`**: `@Transactional` en `claimAndProcess` + `REQUIRES_NEW` en `processOne` mantenía lock de filas durante el procesamiento. Ahora: claimBatch y processOne en transacciones separadas (TransactionTemplate).
- `DMN complianceVigente` y `nivelAprobacionPago` faltantes, bloqueando deployment con `decisionRefBinding="deployment"`.

### Cambiado
- `OutboxPoller` reescrito con `TransactionTemplate` para granularidad de tx.
- `nivelAprobacionPago` DMN ya no depende de `resultadoMatch` como input (el mismatch nunca llega a esa tarea).

## [0.3.0-SNAPSHOT] — Parte 3

### Añadido
- V10: `rfi`, `rfi_routing_policy`, `change_order`, `submittal`, `bid_package`, `bid`, `permit_application`
- V11: índices + trigger append-only en `audit_event` + columnas OSHA
- `ProjectDocumentsService`, `BiddingService`, `SafetyService`, `PermitService`
- `OshaDeadlineSweepJob` (independiente del BPMN)
- `VersionFencingTest` (4 escenarios)
- `OPERATIONS.md`

### Corregido
- `PaymentInvalidatedEventHandler` con doble correlación de mensaje BPMN

## [0.2.0-SNAPSHOT] — Parte 2

### Añadido
- V9: enum `compensation_state`, `evidence_status`, `deduction_status`, `finance_approval_status`
- Compensation completa (service, delegates, BPMN, DMN)
- Dispute completa (service, delegates, jobs, BPMN, DMN)
- Safety (classify, generateOsha, escalate)
- NotificationWorker, ProvisionSnapshotJob
- Tests: ThreeWayMatchFailLoud, RecoveryAccountConcurrency, DisputeDeadline, ClassifyIncident

## [0.1.0-SNAPSHOT] — Parte 1

### Añadido
- Infra (pom, docker, Flyway V1-V8, run.sh, test.sh)
- Plataforma (tenant, RLS, outbox, audit chain, MDC, health, métricas)
- Compliance (service, async projector, delegate, controller)
- Billing (payment service, three-way match, invalidación)
- `PaymentInvalidatedEventHandler`
- `OutboxPoller`

## Wave Hardening + Product (V16; baseline)

- Identity: app_user, project_membership (roles por obra), api_credential, AuthFilter
- Front operativo: / index.html colas compliance / RFI / pagos / submittals
- Ops API: /api/ops/*
- Plantillas documentales: assemble fail-loud si falta variable
- Puente Procore: cliente HTTP real + DRY-RUN explícito + webhooks + external_id_map
- ApiExceptionHandler: errores estructurados, sin stack al cliente
- ComplianceExpirationSweepJob + daily reports + submittals (V15)
- Bootstrap /api/auth/bootstrap para primer usuario del tenant

## Candidate hardening — 2026-10-21 (no release tag)

### Corregido / endurecido
- `X-User-Id` queda deshabilitado por defecto; su uso requiere habilitación explícita de desarrollo/prueba.
- Bootstrap inicial requiere `CONSTRUCTION_BOOTSTRAP_TOKEN`, compara el secreto en tiempo constante, bloquea por fila de tenant, crea OWNER de proyecto y entrega API key una sola vez.
- `TenantJdbcAspect` establece el `app.tenant_id` dentro de la transacción que ejecuta el servicio; `AuthFilter` ejecuta autenticación y carga de membresías dentro de una transacción RLS-scoped.
- Autorización por proyecto añadida a varios endpoints y colas operativas; asignación de rol OWNER reservada al OWNER de esa obra.
- Three-way match exige mismo proyecto y mismas líneas de PO/factura; la compuerta BPMN requiere `MATCH` explícito. El gate de compliance considera estado global, conteos, estado del requisito crítico y vencimiento.
- El delegate de pago crea una instrucción `PENDING`, conserva el importe aprobado sin inventarlo como aprobado y no registra una transferencia ejecutada.
- Outbox falla de forma explícita para tipos sin handler; el webhook inbound Procore y el envío de ofertas se cierran hasta que estén implementadas las fronteras de seguridad que les faltan.
- La composición de PostgreSQL ya no contiene un password de aplicación codificado; el acceso de `app_user` no tiene `DELETE` y no usa `BYPASSRLS`.

### No verificado / no listo para release
- No se pudo ejecutar `mvn test`, Docker/Testcontainers ni PostgreSQL en el entorno de revisión; no se afirma que el proyecto compile ni que las migraciones se apliquen correctamente.
- `claim_projection_outbox(integer)` está definido como `SECURITY DEFINER` y su ejecución sigue concedida a `app_user`; separar el worker con un rol/credencial independiente es un bloqueador de least-privilege antes de un despliegue con datos multi-tenant sensibles.
- La decisión DMN de nivel de aprobación no está conectada al BPMN. El proceso actual no acredita una aprobación humana/política antes de crear la instrucción pendiente.
- El resto de controladores, trabajos y delegates requiere una auditoría de autorización/RLS exhaustiva con pruebas de integración, no solo revisión estática.


## Candidate hardening — 2026-10-22 (frozen snapshot; no release tag)

### Añadido / endurecido
- V18: contexto de contrato obligatorio en solicitudes de pago, constraints compuestas que vinculan la solicitud a la factura/obra/contrato/subcontratista, clave de idempotencia y hash de solicitud, y evidencia durable `payment_approval_decision` con RLS.
- V19: restricciones monetarias e índices para reservas y consulta de pagos por factura.
- V20: esquema Camunda separado (`camunda`), rechazo explícito si existen tablas `ACT_%` antiguas en `public`, y revocación de `CREATE` en `public` para `app_user`.
- Migración Flyway aislada en un contenedor/job de una sola ejecución; el runtime HTTP no ejecuta migraciones ni recibe la contraseña del propietario de la base.
- `Idempotency-Key` obligatoria para solicitudes de pago, hash canónico del contexto, bloqueo transaccional de clave, reintentos idénticos y reserva total de factura.
- Three-way match rechaza discrepancia entre importe de encabezado y suma extendida de líneas (`MISMATCH_FACTURA_TOTAL`). Fixtures de integración actualizados para que sus importes sean consistentes.
- Tests configurados para usar `app_user` y `outbox_worker` en los pools de aplicación y una conexión administrativa separada para fixtures; añadida comprobación RLS de `payment_approval_decision`.
- Corregida la salida DMN de `GERENTE` para requerir revisión manual y añadido `scripts/verify-workflow-models.py`.

### Evidencia de esta instantánea
- 18/18 guardarraíles estáticos pasan.
- 6/6 verificaciones estáticas de estructura BPMN/DMN pasan.
- Parseo XML/POM/BPMN/DMN y YAML/JSON pasa; sintaxis shell pasa.
- No ejecutados: compilación Maven, JUnit/Testcontainers, migraciones en PostgreSQL real, permisos/RLS en runtime ni despliegue/ejecución Camunda. Este entorno no tiene `mvn`, Docker ni `psql`; por tanto esta instantánea no es una release aprobada.

### Bloqueadores restantes
- La DMN de aprobación sigue sin estar conectada al BPMN de pago y no existe todavía un servicio completo que persista la decisión de política/humana antes de crear la instrucción `PENDING`. La tabla de evidencia y las guardas son infraestructura, no prueba de aprobación aplicada.
- La migración V20 bloquea deliberadamente instalaciones que tengan tablas Camunda en `public`; se necesita una migración de datos revisada para instalaciones preexistentes.
- No se ha demostrado compatibilidad de la propiedad de esquema de Camunda con el runtime real, ni compilación del conjunto de dependencias.

## 2026-10-22 — CI and release-gate hardening

- Wired `nivelAprobacionPago` into `paymentApprovalProcess` after the three-way match. Auto-approval is explicitly restricted to MXN below the threshold; currency and policy version are inputs/outputs of DMN. A new delegate persists idempotent `POLICY/APPROVED` evidence before `registrarPagoDelegate`; manual/default paths terminate without a payment instruction.
- Corrected DB release gates to inspect Camunda metadata in schema `camunda`, validate Flyway V17–V21, verify Camunda schema privileges, and check `FORCE ROW LEVEL SECURITY` for approval evidence.
- Removed obsolete documentation that said the HTTP application runs Flyway as `postgres`; corrected the Camunda version inventory.
- Added a hardened CI workflow, CodeQL scanning, Dependabot, security-reporting guidance, and separate production management/metrics port configuration.
- Runtime validation remains required in CI; no production release is authorized by static checks.
