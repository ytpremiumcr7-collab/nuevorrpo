# GO-LIVE Checklist

## Pre-flight técnico

> Estado actual: no aprobar GO-LIVE. `HARDENING_NOTES.md` detalla los bloqueadores P0/P1 y qué evidencia falta. La revisión estática no sustituye el build, Testcontainers, PostgreSQL/Flyway ni el deploy de BPMN/DMN.

- [ ] `mvn clean package` compila sin warnings de deprecation (no ejecutado en el entorno de auditoría)
- [ ] `mvn test` pasa (0 flaky, < 5 min; no ejecutado en el entorno de auditoría)
- [ ] `docker compose up` levanta app + DB
- [ ] `curl -s http://localhost:8080/actuator/health | jq .status` == `"UP"`
- [ ] `EVIDENCE_HMAC_KEY` configurado (NO el default de dev)
- [ ] `SPRING_DATASOURCE_USERNAME=app_user` (NO superuser)
- [ ] Flyway V1-V21 aplicadas sin warnings; V17/V18 requieren preflight de datos históricos y V20 bloquea deliberadamente tablas Camunda heredadas en `public`
- [ ] `scripts/verify-gates.sh` pasa contra PostgreSQL real, incluyendo Camunda en schema `camunda`, V17-V20 y FORCE RLS de `payment_approval_decision`

## Verificación de despliegue BPMN/DMN

- [ ] 8 BPMN desplegados (`Deployment created` en logs ×8)
- [ ] 4 DMN desplegados (`Decision definition created` ×4):
  - `complianceVigente`
  - `nivelAprobacionPago`
  - `recoveryMethodDecision`
  - `disputeResolutionDecision`
- [ ] `complianceValid`, gates de match y `nivelAprobacionPago` se prueban en el motor Camunda; la rama manual de aprobación termina sin instrucción hasta que exista servicio de aprobación autenticado y evidencia durable
- [ ] `incidentReportProcess` tiene timers PT8H y PT24H
- [ ] `disputeCaseProcess` tiene `receiveTask` con `Msg_AckReceived`

## Invariantes en BD

Ejecutar `./scripts/verify-invariants.sh`:

- [ ] `SELECT count(*) FROM verify_audit_chain(tenant)` == 0
- [ ] `SELECT count(*) FROM projection_outbox WHERE status='DEAD_LETTERED'` == 0
- [ ] `SELECT count(*) FROM recovery_account WHERE saldo_pendiente < 0` == 0
- [ ] `SELECT count(*) FROM progress_observation WHERE status='CERTIFIED' AND progress_ratio_lower < contractual_threshold` == 0
- [ ] `SELECT count(*) FROM safety_incident WHERE osha_recordability='NOT_RECORDABLE_WITH_JUSTIFICATION' AND osha_justification IS NULL` == 0

## Aislamiento multi-tenant

- [ ] `RlsIsolationTest` pasa
- [ ] Manual: crear 2 tenants, verificar que tenant A no ve datos de B
- [ ] RLS activo: `SELECT relname FROM pg_class WHERE relrowsecurity = false AND relnamespace = 'public'::regnamespace AND relkind = 'r'` vacío excepto `tenant`

## Fail-loud behavior documentado y probado

- [ ] `POST /api/payments/applications` sin compliance → 500 con mensaje explícito
- [ ] `POST /api/bids/packages/{id}/award` sin justificación → 400
- [ ] `POST /api/permits` con jurisdicción sin config → 500
- [ ] `POST /api/safety/incidents` con `occurredAt` futuro → 400
- [ ] Request sin `X-Tenant-Id` → 400
- [ ] `POST /api/compliance/requirements/{id}/verify` sin documento → 400

## Seguridad

- [ ] `app_user` NO es superuser, NO tiene `BYPASSRLS`
- [ ] `app_user` NO puede conectar como `postgres`
- [ ] `EVIDENCE_HMAC_KEY` viene de KMS/Vault en prod (no env var plana)
- [ ] Endpoints `/actuator/*` requieren autenticación en prod
- [ ] `X-Tenant-Id` + API key se prueban contra tenants distintos; el tenant del credential debe coincidir siempre con el header
- [ ] Logs no contienen PII ni credenciales
- [ ] DB backups configurados (PITR si es posible)

## Backup y recuperación

- [ ] Backup diario automatizado de PostgreSQL
- [ ] Restore probado en ambiente limpio (< 2 horas RTO)
- [ ] Procedimiento documentado en runbook
- [ ] WAL archiving habilitado si PITR requerido

## Rollback

- [ ] Runbook de cutover de Billing tiene disparadores R1-R5
- [ ] `mvn clean package` produce artefacto versionado
- [ ] Docker image tageada con SHA de commit
- [ ] Migración Flyway reversible (o al menos documentada como no reversible)
- [ ] Plan de rollback a versión N-1 probado en staging

## Observabilidad

- [ ] `/actuator/health` incluye `DeadLetterHealthIndicator`
- [ ] `/actuator/prometheus` scrapeado por Prometheus
- [ ] Alertas configuradas:
  - [ ] `outbox_dlq_count > 0`
  - [ ] `billing.payments.blocked` con rate > 0 por 1h
  - [ ] `http_server_requests_errors_total` > 0
- [ ] Logs JSON parseados por ELK/Loki
- [ ] MDC `traceId` propagado a BPMN

## Puentes externos (integración)

- [ ] Procore mapping y ACL bidireccional implementados; webhook inbound permanece deshabilitado (HTTP 501) hasta completar firma, tenant routing y handler
- [ ] OSHA forms payload validado contra ITA API
- [ ] Autoridades municipales: fallback a `PENDING_VERIFICATION` documentado
- [ ] ERP/banking conciliación implementada (o explícitamente fuera de alcance)

## Documentación

- [ ] `TRACEABILITY.md` completo
- [ ] `PHASES.md` completo
- [ ] `OPERATIONS.md` con curl end-to-end
- [ ] `CHANGELOG.md` actualizado
- [ ] `THIRD-PARTY.md` con licencias de dependencias
- [ ] Runbook de cutover Ola 1 aprobado por Finanzas + Legal
- [ ] Runbook de rollback aprobado por CTO + CFO

## Gaps aceptados explícitamente (documentar)

- [ ] Identity: capa inicial de API key y autorización de proyecto añadida, pero la matriz completa de endpoints/jobs/workers no está certificada
- [ ] Progress vision pipeline 6.2 — pendiente (sub-proyecto)
- [ ] Procore ACL bidireccional — pendiente
- [ ] Fase 5 (cierre de puentes) — pendiente; envío de ofertas también está deshabilitado hasta vincular usuario autenticado con party legal

## Firma

- [ ] CTO
- [ ] CFO
- [ ] Legal / Compliance
- [ ] DPO / Seguridad
