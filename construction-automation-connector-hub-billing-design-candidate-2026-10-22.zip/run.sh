#!/usr/bin/env bash
set -euo pipefail
echo "🔨 Build..."
mvn -q clean package -DskipTests
echo "🐳 Docker compose..."
docker compose up -d --build
echo "⏳ Esperando health..."
for i in {1..45}; do
  if curl -sf http://localhost:8080/actuator/health > /dev/null 2>&1; then
    echo ""
    echo "✅ App UP"
    curl -s http://localhost:8080/actuator/health | head -c 500
    echo ""
    echo ""
    echo "Camunda REST/UI: no expuesto; el motor se invoca desde el backend."
    echo "Health:    http://localhost:8080/actuator/health"
    echo "Métricas:  http://localhost:8080/actuator/metrics"
    exit 0
  fi
  sleep 2
done
echo "❌ Timeout. Logs:"
docker compose logs app --tail 200
exit 1
