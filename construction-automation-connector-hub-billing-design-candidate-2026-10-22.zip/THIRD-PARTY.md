# Third-party dependencies and licenses

## Runtime

| Componente | Versión | Licencia | Uso | Obligaciones |
|------------|---------|----------|-----|--------------|
| Spring Boot | 3.2.5 | Apache 2.0 | Framework | Preservar NOTICE |
| Camunda BPM | 7.21.0 | Apache 2.0 | Motor BPMN/DMN | Preservar NOTICE |
| PostgreSQL | 16 | PostgreSQL License | Base de datos | Preservar copyright |
| Flyway | (Spring Boot managed) | Apache 2.0 | Migraciones | Ninguna en community edition |
| Micrometer | (Spring Boot managed) | Apache 2.0 | Métricas | Preservar NOTICE |
| Logstash Logback Encoder | 7.4 | Apache 2.0 | Logs JSON | Preservar NOTICE |
| Jackson | (Spring Boot managed) | Apache 2.0 | JSON | Preservar NOTICE |

## Development / test

| Componente | Licencia | Uso |
|------------|----------|-----|
| Testcontainers | MIT | Tests de integración |
| Mockito | MIT | Tests unitarios |
| JUnit 5 | EPL 2.0 | Tests |

## Inspiración (no incorporado)

Los siguientes proyectos influyeron en el diseño pero **no se ha incorporado código**:

| Proyecto | Licencia | Cómo influyó |
|----------|----------|--------------|
| Ledgic | MIT | Patrón de three-way match con `Decimal` y tolerancia ±2% o $25. Reimplementado sin copiar. |
| OpenProcurement | Apache 2.0 | Modelo de estados de licitación. |
| OpenConstructionERP | AGPL-3.0 | Referencia funcional (no adoptado por licencia). |
| UrbanLayer | AGPL-3.0+ | Ontología de permisos (no adoptado). |
| Construction Safety Tracker | archivado | Patrón de formularios OSHA 300/301. |

## Verificación del inventario

Este archivo es un inventario manual inicial, no una salida generada del grafo efectivo. Antes de una release:

```bash
mvn -B -ntp dependency:tree -DoutputFile=target/dependency-tree.txt
```

Revisar las dependencias transitivas, licencias distribuidas y avisos de seguridad usando el árbol real del build. No inferir que una licencia/transitiva no existe porque no figure en esta tabla. Cada PR que añada o actualice dependencias debe revisar este archivo.
