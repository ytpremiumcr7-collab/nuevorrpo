-- Más configuraciones de fase para contratos no FIDIC

INSERT INTO dispute_phase_config
  (contract_type, jurisdiction, phase, time_unit, duration)
VALUES
  ('AIA_A201',       'US_TX',    'NOTICE',              'CALENDAR_DAYS', 21),
  ('AIA_A201',       'US_TX',    'RESPONSE',            'CALENDAR_DAYS', 10),
  ('AIA_A201',       'US_TX',    'NEGOTIATION',         'CALENDAR_DAYS', 45),
  ('AIA_A201',       'US_TX',    'ARBITRATION',         'CALENDAR_DAYS', 180),
  ('LCSP_ES',        'ES_MADRID','NOTICE',              'CALENDAR_DAYS', 20),
  ('LCSP_ES',        'ES_MADRID','RESPONSE',            'CALENDAR_DAYS', 10),
  ('LCSP_ES',        'ES_MADRID','NEGOTIATION',         'CALENDAR_DAYS', 30),
  ('LOPSRM_MX',      'MX_CDMX',  'NOTICE',              'BUSINESS_DAYS', 20),
  ('LOPSRM_MX',      'MX_CDMX',  'RESPONSE',            'BUSINESS_DAYS', 15),
  ('LOPSRM_MX',      'MX_CDMX',  'NEGOTIATION',         'BUSINESS_DAYS', 30)
ON CONFLICT DO NOTHING;

INSERT INTO permit_phase_config
  (jurisdiction, permit_type, phase, time_unit, duration)
VALUES
  ('MX_CDMX',   'CONSTRUCCION_NUEVA', 'REVIEW',    'BUSINESS_DAYS', 30),
  ('MX_CDMX',   'CONSTRUCCION_NUEVA', 'OBSERVED',  'BUSINESS_DAYS', 15),
  ('MX_CDMX',   'USO_SUELO',          'REVIEW',    'BUSINESS_DAYS', 20),
  ('ES_MADRID', 'LICENCIA_OBRA',      'REVIEW',    'CALENDAR_DAYS', 60),
  ('ES_MADRID', 'LICENCIA_OBRA',      'OBSERVED',  'CALENDAR_DAYS', 30),
  ('US_TX',     'BUILDING_PERMIT',    'REVIEW',    'CALENDAR_DAYS', 45),
  ('US_TX',     'BUILDING_PERMIT',    'OBSERVED',  'CALENDAR_DAYS', 15)
ON CONFLICT DO NOTHING;
