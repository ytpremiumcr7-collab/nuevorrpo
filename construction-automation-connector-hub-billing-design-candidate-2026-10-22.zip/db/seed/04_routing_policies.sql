-- Políticas de enrutamiento de RFIs por work_package
-- El primero (global) ya está en V10.

INSERT INTO rfi_routing_policy
  (tenant_id, project_id, work_package_id, assigned_to_role, priority)
VALUES
  ('00000000-0000-0000-0000-000000000001', NULL, NULL, 'PROJECT_ENGINEER', 100),
  ('00000000-0000-0000-0000-000000000001', NULL, NULL, 'ARCHITECT',        200)
ON CONFLICT DO NOTHING;
-- Nota: como hay PK sobre (tenant_id, project_id, work_package_id),
-- la segunda fila violaría la PK si ambas tienen los mismos NULEs.
-- Ajustar el esquema o eliminar esta fila. Ver FIXME en V10.
