-- Calendario laboral: MX_CDMX 2024-2025, ES_MADRID 2025, US_TX 2025
-- Sin festivos (los oficiales se añaden con otro script o por API).

INSERT INTO business_calendar (jurisdiction_id, calendar_date, is_business_day, source)
SELECT 'MX_CDMX', d::date,
       EXTRACT(DOW FROM d) NOT IN (0, 6),
       'SEED_MX_2024'
  FROM generate_series('2024-01-01'::date, '2024-12-31'::date, '1 day') d
  ON CONFLICT (jurisdiction_id, calendar_date) DO NOTHING;

INSERT INTO business_calendar (jurisdiction_id, calendar_date, is_business_day, source)
SELECT 'MX_CDMX', d::date,
       EXTRACT(DOW FROM d) NOT IN (0, 6),
       'SEED_MX_2025'
  FROM generate_series('2025-01-01'::date, '2025-12-31'::date, '1 day') d
  ON CONFLICT (jurisdiction_id, calendar_date) DO NOTHING;

-- Festivos oficiales MX 2025 (LFT art. 74)
UPDATE business_calendar SET is_business_day = false, holiday_name = 'Año Nuevo'
 WHERE jurisdiction_id = 'MX_CDMX' AND calendar_date = '2025-01-01';
UPDATE business_calendar SET is_business_day = false, holiday_name = 'Día de la Constitución'
 WHERE jurisdiction_id = 'MX_CDMX' AND calendar_date = '2025-02-03';
UPDATE business_calendar SET is_business_day = false, holiday_name = 'Natalicio Benito Juárez'
 WHERE jurisdiction_id = 'MX_CDMX' AND calendar_date = '2025-03-17';
UPDATE business_calendar SET is_business_day = false, holiday_name = 'Día del Trabajo'
 WHERE jurisdiction_id = 'MX_CDMX' AND calendar_date = '2025-05-01';
UPDATE business_calendar SET is_business_day = false, holiday_name = 'Día de la Independencia'
 WHERE jurisdiction_id = 'MX_CDMX' AND calendar_date = '2025-09-16';
UPDATE business_calendar SET is_business_day = false, holiday_name = 'Día de la Revolución'
 WHERE jurisdiction_id = 'MX_CDMX' AND calendar_date = '2025-11-17';
UPDATE business_calendar SET is_business_day = false, holiday_name = 'Transmisión Poder Ejecutivo'
 WHERE jurisdiction_id = 'MX_CDMX' AND calendar_date = '2025-10-01';
UPDATE business_calendar SET is_business_day = false, holiday_name = 'Navidad'
 WHERE jurisdiction_id = 'MX_CDMX' AND calendar_date = '2025-12-25';

INSERT INTO business_calendar (jurisdiction_id, calendar_date, is_business_day, source)
SELECT 'ES_MADRID', d::date,
       EXTRACT(DOW FROM d) NOT IN (0, 6),
       'SEED_ES_2025'
  FROM generate_series('2025-01-01'::date, '2025-12-31'::date, '1 day') d
  ON CONFLICT (jurisdiction_id, calendar_date) DO NOTHING;

INSERT INTO business_calendar (jurisdiction_id, calendar_date, is_business_day, source)
SELECT 'US_TX', d::date,
       EXTRACT(DOW FROM d) NOT IN (0, 6),
       'SEED_TX_2025'
  FROM generate_series('2025-01-01'::date, '2025-12-31'::date, '1 day') d
  ON CONFLICT (jurisdiction_id, calendar_date) DO NOTHING;
