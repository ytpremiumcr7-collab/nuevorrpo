INSERT INTO legal_interest_rate
  (jurisdiction_id, effective_from, effective_to, annual_rate, source_reference)
VALUES
  ('MX_CDMX',   '2024-01-01', '2024-12-31', 0.111400, 'DOF 2024'),
  ('MX_CDMX',   '2025-01-01', NULL,         0.113100, 'DOF 2025'),
  ('ES_MADRID', '2024-01-01', '2024-12-31', 0.031500, 'BOE 2024'),
  ('ES_MADRID', '2025-01-01', NULL,         0.032500, 'BOE 2025'),
  ('US_TX',     '2024-01-01', '2024-12-31', 0.072500, 'TX Finance 2024'),
  ('US_TX',     '2025-01-01', NULL,         0.075000, 'TX Finance 2025')
ON CONFLICT DO NOTHING;
