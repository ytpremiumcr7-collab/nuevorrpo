# Seeds opcionales

Estos SQL **no** se aplican automáticamente con Flyway. Se ejecutan
manualmente para preparar datos de referencia por tenant:

```bash
psql -h localhost -U postgres -d construction -f db/seed/01_business_calendars.sql
psql -h localhost -U postgres -d construction -f db/seed/02_interest_rates.sql
psql -h localhost -U postgres -d construction -f db/seed/03_phase_configs.sql
psql -h localhost -U postgres -d construction -f db/seed/04_routing_policies.sql
```

Ajustar el tenant hardcodeado (`00000000-0000-0000-0000-000000000001`)
al tenant real antes de ejecutar en producción.
