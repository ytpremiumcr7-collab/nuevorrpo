# Diseño de ingeniería — Connector Hub y SaaS Billing

**Proyecto:** Construction Automation / REAL-PROOF  
**Fecha:** 2026-10-22  
**Estado:** Diseño técnico listo para implementación por fases; no habilita proveedores ni cobros reales.  
**Regla de liberación:** todas las integraciones externas y facturación de suscripción siguen en modo cerrado hasta superar compilación, pruebas de integración, revisión de seguridad y una aceptación explícita de producción.

## 1. Decisión ejecutiva

Construir un **monolito modular** con un Connector Hub interno y un subsistema separado de SaaS Billing. Mantener PostgreSQL, Spring Boot y el outbox existentes; no desplegar microservicios nuevos hasta que escala, aislamiento operacional o requisitos de disponibilidad lo justifiquen.

Orden recomendado:

1. Corregir las fronteras de confianza y crear contratos de conectores.
2. Completar la entrada durable de webhooks y la entrega asíncrona de eventos salientes.
3. Migrar Procore a un adapter OAuth real y verificable, primero en sandbox.
4. Añadir suscripciones SaaS en Stripe Test Mode, separadas de pagos de facturas de obra.
5. Medir, reconciliar y probar recuperación antes de abrir producción.

**No ejecutar aún** el generador de “Parte 6” presentado en la conversación. El repositorio ya contiene `V15__construction_niche_ops.sql`, `V16__identity_templates_integration.sql` y tablas de plantilla, integración y outbox. Reutilizar el número V15 chocaría con el historial Flyway; además, ese generador no es seguro ni compatible sin cambios sustanciales (sección 12).

## 2. Evidencia del sistema actual

Inspección del árbol empaquetado, no inferencias del README:

- `src/main/resources/db/migration/V16__identity_templates_integration.sql`: crea `integration_outbox`, `external_id_map`, `document_template` y tablas con RLS.
- `src/main/java/com/tuempresa/integration/procore/ProcoreController.java`: endpoint `/webhooks` devuelve 501 deliberadamente hasta implementar autenticación, deduplicación y procesamiento inbound.
- `ProcoreClient.java`: usa un bearer token estático por configuración; si no hay credenciales opera en DRY-RUN. El cliente no declara límites explícitos de conexión/lectura ni OAuth lifecycle.
- `ProcoreBridgeService.java`: `pushRfiNow()` llama a Procore en línea y luego escribe un evento `PUSHED` al outbox. Mezcla ejecución externa y persistencia dentro de una operación transaccional.
- `IntegrationOutboxService.java`: inserta mensajes en `integration_outbox`, pero no se encontró un worker dedicado que reclame, entregue, reprograme y coloque esas filas en dead letter.
- `platform/events/OutboxPoller.java`: procesa `projection_outbox`, no `integration_outbox`. Son colas diferentes; el worker actual no demuestra entrega externa.
- `V4__billing.sql`: el dominio de factura/pago es **finanzas de construcción** (`invoice`, `payment_application`, `payment`), no facturación SaaS.
- `PaymentApplicationService.java`: solicitud de pago de subcontratista con validación de factura, contrato y compliance. No debe compartir tablas ni transiciones con las suscripciones comerciales de Megalodón/Construction Automation.
- `V15`, `V16`, `V17`, `V18`, `V19`, `V20` y `V21` ya existen. Toda evolución debe ser una migración **aditiva V22+**, sin editar migraciones históricas.

## 3. Arquitectura objetivo

```text
                               ┌─────────────────────────────┐
Procore / ERP / custom webhook ─► Ingress por proveedor       │
Stripe Billing webhook ─────────► verificación / normalización│
                               └──────────────┬──────────────┘
                                              │ transacción corta
                                     ┌────────▼────────┐
                                     │ connector_inbox │  dedup + estado durable
                                     └────────┬────────┘
                                              │ worker
                                   ACL / Adapter / Policy
                                              │
                                        Dominio propio
                                              │ misma transacción
                                     ┌────────▼────────┐
                                     │ integration_outbox│
                                     └────────┬────────┘
                                              │ worker por conector
                                ┌─────────────▼──────────────┐
                                │ timeout / retry / breaker │
                                │ métricas / DLQ / replay    │
                                └────────────────────────────┘

Checkout/Portal Stripe ─► BillingService ─► Stripe API (Test Mode primero)
                                 │
                                 ▼
                  SaaS customer / subscription / entitlement
```

El Connector Hub no es un proxy HTTP arbitrario. Es el borde anti-corrupción (ACL) que traduce contratos externos a eventos/comandos internos versionados.

### Principios

- **Hexagonal / Ports & Adapters:** los servicios de dominio dependen de `ConnectorAdapter`, no de SDKs de Procore/Stripe.
- **Adapter + Translator:** cada proveedor tiene DTO y errores propios; normalizar solamente los conceptos necesarios.
- **Inbox + Idempotent Receiver:** recepción durable y una única aplicación lógica por ID de evento.
- **Transactional Outbox:** el evento saliente se inserta en la misma transacción que el cambio del dominio; el worker lo envía después del commit.
- **Retry + Circuit Breaker + Bulkhead:** límites por proveedor y por conexión, no globales.
- **State/Policy versioned:** las decisiones de negocio se apoyan en reglas versionadas; no desplegar BPMN/formularios dinámicos para toda variante antes de necesitarlos.
- **Least privilege + RLS:** roles separados para HTTP, migrador, worker de proyección y worker de conectores, con permisos explícitos.

## 4. Connector Hub — contratos de aplicación

### 4.1 Interface interna

Contrato conceptual; los nombres finales se ajustarán al estilo de paquetes existente:

```java
public interface ConnectorAdapter {
    ConnectorKey key();
    ConnectorCapabilities capabilities();
    NormalizedEvent normalizeInbound(VerifiedInboundEvent event);
    DeliveryResult deliver(OutboundCommand command, ConnectorConnection connection);
}
```

Reglas del contrato:

- `key()` es un identificador registrado en código (por ejemplo `PROCORE` o `GENERIC_WEBHOOK`), nunca nombre de clase libre en BD.
- `normalizeInbound` solo recibe un evento que ya pasó la verificación específica del proveedor. No debe asumir que JSON válido equivale a autenticidad.
- `deliver` recibe una conexión ya autorizada y devuelve un resultado tipado: `DELIVERED`, `RETRYABLE_FAILURE`, `PERMANENT_FAILURE`, `AUTH_REQUIRED`, `RATE_LIMITED`.
- No permitir que un tenant configure código, expresión SpEL, nombre de clase Java o URL de destino libre para disparar lógica arbitraria.
- Las capacidades (RFI export, project lookup, webhook inbound, OAuth refresh) se declaran explícitamente y se validan antes de aceptar comandos.

### 4.2 Modelo de conexión

Crear, vía migración aditiva, `connector_connection` con mínimo:

- `tenant_id`, `connection_id`, `provider_key`, `status`, `environment` (`SANDBOX`/`PRODUCTION`), `provider_account_id` opcional, `scopes`, `config_version`, `created_by`, `created_at`, `updated_at`, `last_success_at`, `last_error_code`.
- `secret_ref` o referencias separadas para access/refresh/client secrets; **no** almacenar tokens o contraseñas en texto plano dentro de JSONB.
- `public_endpoint_token_hash` (hash de un token aleatorio de alta entropía) para resolver una conexión inbound sin recibir `X-Tenant-Id` del emisor.
- unicidad por tenant/proveedor/cuenta externa según el modelo de negocio acordado.
- RLS con `USING` y `WITH CHECK`; pruebas de aislamiento entre tenants.

La conexión no almacena una URL arbitraria para `base-url` en la primera versión. Cada adapter usa hosts oficiales allowlisted. Un futuro webhook genérico necesita política de egress independiente, DNS/IP revalidation y bloqueo de loopback, redes privadas, link-local y endpoints de metadatos para evitar SSRF y DNS rebinding.

### 4.3 Inbox inbound

Añadir `connector_webhook_inbox`:

- Identidad: `tenant_id`, `connection_id`, `provider_key`, `provider_event_id`, `event_type`, `provider_created_at`, `received_at`.
- Integridad: `body_sha256`, `signature_verified`, `schema_version`; no registrar cabeceras de autenticación ni tokens.
- Estado: `RECEIVED`, `PROCESSING`, `PROCESSED`, `RETRY`, `DEAD`; `attempts`, `next_attempt_at`, `lease_until`, `last_error_code`, `processed_at`.
- Unicidad idempotente sobre la identidad del proveedor, usualmente `(connection_id, provider_event_id)`. No usar un hash del cuerpo como identidad de evento: dos eventos legítimos pueden tener payloads idénticos.
- Payload mínimo y de retención limitada; si la fuente permite recuperar el recurso autoritativo por API, preferir guardar identificadores y volver a consultar al proveedor.
- Política explícita de retención/borrado compatible con auditoría y datos personales; no asumir que guardar cada cuerpo íntegro indefinidamente es necesario.

### 4.4 Flujo inbound seguro

1. Limitar tamaño (`Content-Length` y cuerpo leído), content-type, timeout, nesting/JSON y tasa antes de procesar.
2. Resolver endpoint público aleatorio a la conexión, sin confiar en `X-Tenant-Id`, IDs de tenant incluidos en payload ni query params controlados por el remitente.
3. Verificar autenticidad usando el mecanismo soportado por el proveedor. La verificación se ejecuta sobre los bytes originales del cuerpo antes de deserializar.
4. Validar timestamp/replay cuando el protocolo lo soporte; aplicar tolerancia documentada y rotación de secretos.
5. Validar cuenta/instalación/proyecto externo contra la conexión, tenant y `external_id_map` autorizado.
6. En una transacción corta insertar en inbox. Evento duplicado ya aceptado: responder `2xx` sin volver a procesarlo. Evento inválido: rechazar sin crear trabajo de dominio.
7. Encolar/activar worker y responder `2xx` rápido sólo después de confirmar almacenamiento durable.
8. Worker reclama con `FOR UPDATE SKIP LOCKED` o lease recuperable; normaliza a evento interno, verifica estado/versión y aplica idempotentemente.
9. Si el proveedor es solo de notificación, consultar el recurso en su REST API para confirmar el estado canónico; completar con reconciliación periódica para eventos perdidos/desordenados.
10. Fallo transitorio: backoff exponencial con jitter y límite. Fallo permanente o límite agotado: DLQ, alerta y replay manual auditado.

**Procore específico:** la documentación oficial actual describe OAuth 2.0 para la REST API y recomienda emparejar webhooks con reconciliación API, porque los webhooks son señales de mejor esfuerzo y no la fuente canónica del objeto. No asumir que Procore ofrece el mismo encabezado HMAC que Stripe. Verificar el mecanismo exacto que soporte el producto/evento configurado; si no hay firma verificable, usar una URL opaca de alta entropía más comprobación mediante API autenticada, cuotas estrictas y reconciliación, documentando el riesgo residual. Referencias: https://developers.procore.com/documentation/content/introduction, https://developers.procore.com/documentation/content/building-data-connection-apps, https://developers.procore.com/documentation/content/payload-formats

**Stripe específico:** utilizar el SDK oficial para verificar `Stripe-Signature` sobre el cuerpo raw y el secreto endpoint. No implementar HMAC a mano ni compartir el webhook secret con otro proveedor. Referencia: https://docs.stripe.com/webhooks/signature

### 4.5 Outbound real

`integration_outbox` existe, pero la inspección actual no encontró un worker dedicado que la consuma. Resolverlo en vez de crear un segundo outbox innecesario.

- Cambios de dominio y filas de outbox en una única transacción PostgreSQL.
- El worker reclama lote con lease y `SKIP LOCKED`; ningún HTTP externo dentro de la transacción que cambia el dominio.
- Guardar `message_id`, clave idempotente estable, número de intento, instante del siguiente intento, error categorizado, proveedor/conexión y timestamps. Añadir una clave única donde el contrato de negocio la determine.
- Enviar fuera de transacción; registrar el resultado en una transacción nueva y comprobar `status/lease` para no finalizar un trabajo reclamado por otro worker.
- Retry sólo para fallos transitorios y operaciones idempotentes. `429` respeta `Retry-After`; errores de autenticación requieren reconexión; `4xx` permanentes no se reintentan indiscriminadamente.
- Circuit breaker y bulkhead por proveedor/conexión. Timeout de conexión y respuesta siempre definidos. Límites de concurrencia y cuota por tenant.
- Si hay respuesta exitosa remota pero falla el commit local, la operación remota puede repetirse; usar idempotency key del proveedor cuando exista y reconciliación por ID externo. Outbox no significa “exactly-once” en redes: garantiza entrega al menos una vez y requiere consumidor idempotente.
- DLQ con replay explícito, motivo, actor y audit event; no repetir permanentemente cargas con credenciales inválidas.

### 4.6 Procore adapter

Fase inicial sólo RFI push/pull en sandbox. Mantener `ProcoreBridgeService` como fachada de dominio mientras se extrae la llamada síncrona a `ProcoreClient` y se sustituye por la outbox.

- OAuth 2.0 Authorization Code para usuario conectado; añadir DMSA/client credentials sólo cuando el modelo de permisos de Procore lo permita y después de configurar el alcance exacto. Gestionar expiración/revocación/rotación y cifrar refresh tokens con KMS/secret manager.
- No usar bearer token fijo de ambiente como modelo de producción definitivo.
- Resolver company/project IDs mediante la cuenta y permisos conectados; no aceptar que el cliente elija arbitrariamente el proyecto remoto.
- DTOs Procore en el adapter, modelos propios en el dominio, traducción de errores y paginación/rate limits del proveedor.
- Pruebas contractuales con fixtures sanitizados y sandbox; ningún test automatizado debe tocar producción.
- El endpoint webhook permanece cerrado hasta autenticar/validar los eventos con el mecanismo real documentado para cada configuración.

## 5. SaaS Billing — contexto distinto del dinero de obra

### 5.1 Borde del dominio

No reutilizar las tablas `invoice`, `payment` o `payment_application`. El módulo comercial usará nombres prefijados `saas_*` (por ejemplo `saas_customer`, `saas_subscription`, `saas_entitlement`, `saas_webhook_inbox`). Así se evita mezclar el dinero que se paga a subcontratistas con la mensualidad que paga una constructora por usar el SaaS.

**MVP:** setup fee único + suscripción mensual fija. No implementar usage-based billing, Stripe Connect, desembolsos, manejo directo de PAN/CVV ni ledger completo en la primera entrega. El uso medido puede agregarse cuando exista una política comercial real.

### 5.2 Fuente de verdad y límites

- Stripe es autoridad del cobro y los objetos de facturación del proveedor; nuestra BD es la proyección local para acceso, panel y trazabilidad.
- La autorización de funciones no se concede por el redirect de Checkout ni por un parámetro de la URL de retorno. Sólo cambia al procesar un webhook verificado y aplicar la transición permitida.
- Ninguna solicitud HTTP pública puede establecer directamente `subscription.status=ACTIVE` ni modificar los IDs Stripe.
- Catálogo de precios allowlisted: el cliente envía un `plan_code`, nunca un `price_id`, monto, moneda, descuento o tenant de destino libre.
- Usar Checkout alojado y Customer Portal para reducir la superficie PCI; el backend nunca recibe ni almacena datos completos de tarjeta.
- El setup fee se representa como línea de cobro separada, con su propio ID de operación e idempotency key; no confundir pago único y recurring price.
- La factura legal/fiscal mexicana (CFDI) es un flujo separado. Un receipt/invoice de Stripe no debe presentarse automáticamente como CFDI. Requiere decisión fiscal y, si aplica, integración certificada correspondiente.

### 5.3 Tablas propuestas (migración aditiva, después del Connector Hub)

`saas_customer`

- `(tenant_id, saas_customer_id)` PK.
- `provider` (`STRIPE` para el MVP), `provider_customer_id`, status, timestamps.
- unique `(provider, provider_customer_id)`; no guardar tarjetas ni client secret.
- RLS por tenant.

`saas_subscription`

- `tenant_id`, `subscription_id`, `saas_customer_id`, `plan_code`, `provider_subscription_id`, `provider_price_id`, `status`, `currency`, `current_period_start`, `current_period_end`, `cancel_at_period_end`, `grace_until`, `version`, timestamps.
- estados enumerados/validados explícitamente (`PENDING_CHECKOUT`, `TRIALING`, `ACTIVE`, `PAST_DUE`, `PAUSED`, `CANCELED`, `INCOMPLETE`, `UNPAID`). No mapear cualquier string del proveedor sin validación.
- unique IDs de proveedor y claves compuestas que impidan asociar una suscripción a otro tenant.
- RLS + `WITH CHECK`; las actualizaciones vienen del servicio autorizado de webhooks y comandos admin explícitos.

`saas_entitlement`

- `tenant_id`, `feature_key`, `source_subscription_id`, `enabled`, `valid_from`, `valid_until`, `policy_version`, `updated_at`.
- Proyección derivada de plan + estado de suscripción + política de gracia. No permitir modificarla desde el frontend.
- Los guards de API comprueban entitlement server-side, además de RBAC y tenant.

`saas_provider_event`

- `provider`, `provider_event_id`, `received_at`, `signature_verified`, `payload_sha256`, `event_type`, `processing_status`, `attempts`, `processed_at`, `last_error_code`.
- unique `(provider, provider_event_id)` para idempotencia global de la cuenta/plataforma; tenant se vincula después de mapear el customer/subscription a IDs internos.
- RLS no se aplica ingenuamente a una cola central sin tenant conocido: la ingestión inicial requiere rol dedicado y permisos mínimos; el worker obtiene tenant desde el mapa verificado de customer/subscription. Ninguna clave del payload define el tenant por sí sola.

`saas_usage_event` (opcional fase 2, no requisito del MVP)

- append-only, `tenant_id`, `event_id`, `feature_key`, `units`, `occurred_at`, `source`, `idempotency_key`, `pricing_version`.
- unique para la clave de idempotencia; agregados como proyección reconstruible. Definir explícitamente qué acciones son facturables y cómo se corrigen eventos.

### 5.4 Estados y eventos de suscripción

- `checkout.session.completed`: registrar correlación y confirmar el customer/subscription referido; no basta por sí solo para activar si la modalidad requiere primer pago confirmado.
- `invoice.paid`: confirma pago de la factura del proveedor; actualizar estado con reglas idempotentes.
- `invoice.payment_failed`: mover a `PAST_DUE` o a estado definido por política, aplicar período de gracia configurable y notificar.
- `customer.subscription.updated` / `.deleted`: reconciliar status, periodos y cancelación.
- `entitlements.active_entitlement_summary.updated`: considerar sólo si se decide que Stripe Entitlements sea autoridad para los features; no duplicar dos modelos de verdad sin ADR.

Los webhooks pueden llegar duplicados o desordenados. Deduplicar por ID de evento; validar la transición; si el evento está obsoleto o existe ambigüedad, consultar el objeto canónico en Stripe antes de modificar la proyección. Añadir job de reconciliación para detectar suscripciones locales divergentes.

### 5.5 Idempotencia y operación

- Idempotency key estable por operación semántica (`tenant + operation + internal command id`) al crear customer/checkout/subscription. No utilizar correo ni dato personal como clave.
- Registrar respuesta externa mínima y provider IDs; no almacenar headers sensibles ni loguear secretos.
- Cada webhook válido se guarda durable antes de responder 2xx. Reprocesarlo nunca duplica entitlements ni onboarding.
- No ejecutar efectos externos dentro de la transacción local. Para provisioning/checkout usar un estado persistente más outbox/worker; compensaciones explícitas para recursos remotos creados parcialmente.
- Revisión de monedas e impuestos: el precio y moneda provienen del catálogo publicado; si el negocio vende en MXN y/o EUR debe decidir impuestos, factura fiscal, zona geográfica y condiciones contractuales antes de producción.

Referencias oficiales: https://docs.stripe.com/webhooks/signature, https://docs.stripe.com/api/idempotent_requests, https://docs.stripe.com/api/events/types

## 6. API propuesta (MVP cerrado por permisos)

### Connector Hub

- `GET /api/connectors` — lista conexiones visibles al tenant actual, sin secretos.
- `POST /api/connectors/procore/authorize` — inicia OAuth con `state` aleatorio, PKCE cuando aplique, redirect URI allowlisted y nonce de corta duración.
- `GET /api/connectors/procore/callback` — valida state, intercambia código server-side y persiste sólo secreto cifrado/referencia de vault.
- `POST /api/connectors/{connectionId}/test` — prueba de conectividad/autorización con cuotas.
- `POST /api/connectors/{connectionId}/sync` — encola una reconciliación, no bloquea el request.
- `GET /api/connectors/{connectionId}/deliveries` — auditoría paginada, valores sanitizados.
- `POST /api/connectors/{connectionId}/deliveries/{messageId}/replay` — sólo rol de operación autorizado, idempotencia y audit event.
- `POST /api/connectors/webhooks/{opaqueEndpointToken}` — endpoint público por proveedor; no exige `X-Tenant-Id` del remitente. El endpoint opaco sólo selecciona configuración y NO sustituye la autenticación criptográfica cuando el proveedor la soporta.

No exponer un endpoint genérico para configurar cualquier host HTTP en MVP.

### SaaS Billing

- `POST /api/saas-billing/checkout` — requiere user auth + permisos de owner/admin; acepta `plan_code` y `request_id` idempotente, no importe ni price ID.
- `POST /api/saas-billing/portal` — genera URL de portal para el customer interno correlacionado.
- `GET /api/saas-billing/subscription` — lectura del estado local y periodo, sin consultar Stripe en cada request.
- `POST /api/saas-billing/webhooks/stripe` — raw body, verificación de firma mediante SDK oficial, almacenamiento durable de evento y deduplicación.
- `GET /api/saas-billing/invoices` — lista proyecciones de facturación del proveedor y enlaces de hosted invoice sólo si proceden del provider.

No añadir endpoints para cambiar directamente plan, estado o entitlement sin una operación de negocio controlada.

## 7. Estados de operación y recuperación

### Outbound delivery

```text
PENDING -> PROCESSING -> SUCCEEDED
                    \-> RETRY -> PROCESSING
                    \-> DEAD (terminal; replay manual auditado)
```

Leases vencidos recuperables; un worker reiniciado no deja fila permanentemente en `PROCESSING`. Un timeout remoto no implica que el proveedor no procesó el comando: resolverlo por clave idempotente/lectura autoritativa antes de reenviar.

### Subscription

```text
PENDING_CHECKOUT -> TRIALING / ACTIVE
ACTIVE -> PAST_DUE -> ACTIVE
ACTIVE -> CANCELED (inmediato o al fin del periodo)
PAST_DUE -> UNPAID / CANCELED según política contractual
```

Cambiar entitlements según una tabla de decisión versionada: no borrar datos si vence la suscripción; restringir nuevas escrituras o workflows nuevos con periodo de gracia acordado; mantener export de datos y soporte administrativo según contrato.

## 8. Seguridad, abuso y privacidad

| Amenaza | Control obligatorio |
|---|---|
| Webhook falsificado/replay | Firma del proveedor sobre raw body, timestamp, deduplicación, rotación de secreto; mecanismo específico por proveedor |
| Tenant spoofing | Tenant proviene del credential/connection mapping verificado, no de header/body externo |
| SSRF de webhook genérico | No habilitar destino libre; allowlist, egress control, validación DNS/IP, bloquear redes privadas/link-local/metadata y redirects |
| Token OAuth filtrado | Vault/KMS, cifrado, scopes mínimos, rotación/revocación, redacción en logs |
| Payload malicioso | Límite de tamaño, schema validation, content-type, parser seguro, no deserialización polimórfica, no ejecución de scripts |
| Doble procesamiento | Uniqueness constraints, inbox/outbox, handlers idempotentes, prueba de carreras |
| Provider caído | Timeout, rate limit, circuit breaker, bulkhead, backoff+jitter y DLQ |
| Envío de eventos a cliente equivocado | Validación cuenta externa ↔ conexión ↔ tenant ↔ mapping; no confiar en ID incluido en payload |
| Cobro SaaS duplicado | Idempotency keys servidor a proveedor, IDs únicos, webhook dedup, reconciliación |
| Escalada de plan/entitlement | Checkout creado por backend desde catálogo; eventos verificados como fuente de estado; guards server-side |
| Exposición PCI/PII | Hosted Checkout/Portal; no PAN/CVV; payloads minimizados, retención, redacción y logs sin secretos |
| Abuso de replay/sync | RBAC de operación, auditoría, rate-limit por tenant y conexión, cuotas y aprobación para acciones de producción |

Los permisos de GitHub Actions también deben ser mínimos y las actions externas fijarse a SHA completo. No otorgar `contents: write` a jobs de compilación o análisis; reservar escritura para jobs separados y acotados. Referencia: https://docs.github.com/en/actions/reference/security/secure-use

## 9. Observabilidad y soporte

Métricas sin etiquetas de alta cardinalidad ni PII:

- `connector_webhook_received_total{provider,result}`
- `connector_webhook_duplicate_total{provider}`
- `connector_delivery_total{provider,result}`
- `connector_delivery_attempts`, `connector_delivery_latency_seconds`
- `connector_dead_letter_total{provider}`
- `saas_billing_webhook_total{type,result}`
- `saas_subscription_state_change_total{from,to}`

Cada solicitud interna lleva `trace_id`, `tenant_id` sólo en el contexto de observabilidad protegido y correlation/idempotency IDs; nunca tokens, API keys, payloads completos o información sensible en logs. Dashboard con última sincronización, latencia, autenticación vencida, retries, DLQ y discrepancias de reconciliación.

## 10. Pruebas de aceptación obligatorias

### Connector Hub

1. Firma inválida no crea inbox ni mutación de dominio.
2. Firma válida se persiste y responde rápido; si la persistencia falla, no se responde 2xx.
3. Repetir un mismo `provider_event_id` N veces genera una única aplicación lógica.
4. Eventos fuera de orden no revierten estado nuevo ni saltan una transición permitida.
5. La misma conexión no puede mapear recursos de otro tenant.
6. El payload externo no puede seleccionar `tenant_id`, handler Java o destino arbitrario.
7. Errores 429/5xx reciben reintento apropiado; errores 400/401 persistentes no generan tormenta de retries.
8. El worker puede morir después de reclamar, expirar lease y recuperar la fila.
9. Un timeout tras éxito remoto no provoca duplicado funcional.
10. Circuit breaker abierto protege a las otras conexiones/proveedores.
11. Webhook perdido se recupera mediante reconciliación.
12. Logs/metrics no exponen tokens, firmas o datos personales.

### SaaS Billing

1. Sólo catálogo servidor decide el `price_id`, importe y moneda.
2. Cliente A no puede consultar customer/subscription/portal del tenant B.
3. Checkout duplicado por request id retorna la misma operación o resultado estable.
4. Signature inválida no cambia subscription ni entitlement.
5. Evento Stripe duplicado no duplica estado/entitlements.
6. Eventos desordenados no regresan una suscripción a un estado obsoleto.
7. `invoice.payment_failed` aplica grace policy; el frontend no se concede estado `ACTIVE` por redirect.
8. `invoice.paid` sólo afecta la suscripción vinculada a customer y tenant previamente correlacionados.
9. Renovación, cancelación al fin del periodo, cancelación inmediata, reembolso/disputa y estado `unpaid` tienen transiciones definidas.
10. Reconciliación detecta divergencia entre provider y DB sin doble cobro.
11. El test usa Stripe Test Mode/fixtures; no credenciales ni cobros reales.
12. RLS y permisos de DB se prueban contra PostgreSQL real con rol runtime, no sólo admin.

### Gate para merge/release

- `mvn -B -ntp clean verify` verde en JDK 21.
- Migraciones V1–V22+ contra base vacía y estrategia documentada para instalaciones heredadas.
- Testcontainers PostgreSQL para RLS, constraints, idempotencia/concurrencia y leases.
- Pruebas de contrato del adapter con fixtures y sandbox si está disponible.
- CodeQL, dependency review, secret scanning y Compose validation.
- Revisar SBOM/árbol real de dependencias y licencias.
- Evidencia de backup/restore y rollback para migraciones de estado.
- Revisión manual del diff final y aprobación humana explícita antes de producción.

## 11. Plan de implementación ordenado

### Sprint A — cerrar las brechas base (bloquea el resto)

- Establecer tenant confiable a partir de credencial autenticada; headers por sí solos no son identidad.
- Definir actor y roles de operación para administrar conexiones, ver DLQ y replay.
- Corregir el flujo actual de Procore para no hacer la red externa dentro de una transacción de dominio.
- Especificar retención de payloads/secretos y límites de tamaño/timeout.

### Sprint B — Connector Hub core

- V22 aditiva: connection registry, inbox, y expansión mínima de outbox/índices/roles.
- DAO/repository con RLS y worker con lease, retry, DLQ.
- Adapter registry typed y error taxonomy.
- Tests de PostgreSQL real para carreras, tenant isolation, dedup y lease recovery.

### Sprint C — Procore sandbox

- OAuth lifecycle, secret vault/KMS, scope mínimo.
- Adapter RFI con ID mapping y reconciliación.
- Webhook sólo con el mecanismo de autenticidad realmente soportado; el endpoint actual continúa 501 hasta cerrar los tests.
- Rollout por una conexión allowlisted, kill switch y métricas.

### Sprint D — SaaS Billing Test Mode

- V23+: tablas `saas_*`, catálogo plan/precio, webhook inbox Stripe, checkout/portal y entitlements.
- SDK oficial de Stripe con versión fijada y licencia verificada; sin dependencias `latest`.
- Pruebas de eventos duplicados/desordenados, checkout idempotente y reconciliación.
- Setup fee como operación única separada; pricing no configurable por el navegador.

### Sprint E — aceptación preproducción

- Simular expiración/revocación del token, errores 429/5xx, timeout tras éxito externo, reinicio de workers y duplicación de webhooks.
- Revisar seguridad, privacidad, soporte, export de datos y política comercial/fiscal de MXN/EUR.
- Activación gradual por tenant; el resto permanece disabled.

## 12. Revisión crítica del generador “Parte 6” aportado

No integrarlo literalmente. Riesgos y defectos observables:

1. **Colisión Flyway:** intenta crear V15, pero V15 ya existe; sería una migración con versión duplicada.
2. **Identidad de tenant:** el `TenantContext` actual procede del header. Para una plataforma multi-tenant, la selección de tenant debe ligarse a la credencial autenticada; no basta que el request mande un UUID.
3. **SQL y RLS:** no concatenar contextos/valores al SQL. Usar `set_config('app.tenant_id', ?, true)` en la misma transacción/connection; verificar rol real y RLS.
4. **JSONB:** asumir que `jdbc.queryForMap` devuelve `String` para `jsonb` puede fallar según driver (puede ser `PGobject`). Deserializar a DTO de manera explícita.
5. **Validación de esquema insuficiente:** sólo revisa presencia de campos; no valida tipos, campos extra, tamaños, patrones, enum de opciones, nulabilidad ni versión del schema. El `required` no está expresado formalmente.
6. **Process key controlado por datos:** cargar `process_key` de BD y llamar `startProcessInstanceByKey` sin allowlist/versionado permite iniciar cualquier proceso desplegado con variables no apropiadas. Exigir registro aprobado de modelo, versionado y permisos.
7. **Sin idempotencia ni auditoría:** cada retry genera UUID/instancia BPMN nueva; no hay request key ni registro de quién inicia el trabajo.
8. **Form renderer incompleto:** `any`, `parseFloat`, opciones controladas desde datos y ausencia de manejo de error/estado accesible. No integra automáticamente `embedded:app:forms/dynamic.html` con una app React externa.
9. **Módulos incompatibles con código existente:** importa `com.tuempresa.platform.tenant.TenantContext`, pero se debe revisar el contrato real; usa `RuntimeService` de paquete Camunda aunque el objetivo debe fijar la versión/motor y evitar mezclar Operaton con Camunda sin decisión explícita.
10. **SLA sin timer durable:** guardar `sla_hours` no instala un timer BPMN ni define calendario/feriados/escalamiento.
11. **Plantillas globales sin lifecycle:** no hay estados DRAFT/APPROVED/RETIRED, vigencia, versión de esquema, actor aprobador o auditoría de cambio.
12. **Falta autorización funcional:** no verifica membership/rol sobre la clase de tarea, cuota por tenant, ni si el actor puede iniciar ese `taskType`.

Primero cerrar Connector Hub y los boundaries de identidad; diseñar Template Registry como una iteración separada con migración V24+ y contrato de formularios validado, no colarlo dentro de V22/V23.

## 13. Dependencias nuevas: política

No añadir un paquete sólo por moda. Antes de incorporar Stripe Java SDK u otro cliente:

- confirmar versión estable/compatible con JDK 21 y Spring Boot actual;
- fijar versión exacta, revisar licencia y dependencias transitivas;
- escanear CVEs/SCA y mantener SBOM;
- usar SDK oficial para criptografía de firmas y serialización del proveedor;
- encapsularlo en `integration/stripe` o `billing/provider/stripe`; el dominio no importa clases Stripe;
- incluir solo permisos OAuth/scopes y eventos requeridos.

Dependencias operativas de bajo riesgo/alto valor: CI con `mvn clean verify`, CodeQL, dependency review/Dependabot ya presentes, secret scanning/push protection activados en GitHub, Testcontainers para PostgreSQL, fixtures de contrato y métricas existentes Micrometer. Nunca agregar secretos reales al repositorio ni usar credenciales productivas en CI.

## 14. Decisiones que deben quedar registradas antes de código productivo

1. Procore app propia privada vs distribución Marketplace. La documentación de Procore distingue aplicaciones privadas y las que se licencian/reutilizan comercialmente; validar requisitos si se piensa vender el conector a varias empresas.
2. Secret manager disponible (por ejemplo KMS/Vault/servicio gestionado) y proceso de rotación de OAuth/webhook secrets.
3. Política de gracia, suspensión, cancelación y export al terminar una suscripción.
4. Moneda, impuestos, factura fiscal/CFDI y entidad que factura al cliente.
5. Si el primer plan comercial será sólo mensual fijo + setup fee, o si metering es una necesidad contractual inmediata.
6. Qué datos puede conservar el inbox y durante cuánto tiempo.

## Fuentes primarias consultadas

- Procore, Start Here / API and OAuth: https://developers.procore.com/documentation/content/introduction
- Procore, Build a Data Connector App (OAuth, usuario y cuenta de servicio): https://developers.procore.com/documentation/content/building-data-connection-apps
- Procore, Webhook payloads, delivery and reconciliation: https://developers.procore.com/documentation/content/payload-formats
- Stripe, webhook signature verification: https://docs.stripe.com/webhooks/signature
- Stripe, idempotent requests: https://docs.stripe.com/api/idempotent_requests
- Stripe, event types for subscription/invoice state: https://docs.stripe.com/api/events/types
- GitHub Actions, secure use and SHA pinning: https://docs.github.com/en/actions/reference/security/secure-use
