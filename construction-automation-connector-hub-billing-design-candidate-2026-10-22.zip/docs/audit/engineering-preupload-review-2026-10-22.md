# Engineering pre-upload review — 2026-10-22

## Scope and evidence

This report covers the candidate prepared for `ytpremiumcr7-collab/nuevorrpo`. The original frozen package has been left intact. Changes below are made in a separate working copy and will be proposed on an isolated branch; the base branch must not be overwritten.

### Static checks run on this working copy

- `python3 scripts/verify-workflow-models.py`: **14/14 PASS** (XML/model structure only).
- `python3 scripts/verify-hardening-static.py`: **18/18 PASS** (source/configuration checks only).
- `bash -n run.sh test.sh scripts/*.sh`: **PASS**.
- `bash scripts/prove-construction-niche.sh`: **PASS** (structural inventory, not runtime proof).
- Parse all XML/POM/BPMN/DMN files: **PASS, 14 files**.
- Parse all YAML files: **PASS, 12 files**.
- Basic credential-pattern scan of text/config files: **no likely hardcoded credential found**. This is not a replacement for GitHub Secret Scanning/push protection.

### Environment limitation

The current local execution environment has JDK 21 but does not have Maven, Docker/Podman or `psql`; Maven dependency resolution over the network also failed. Therefore no local `mvn clean verify`, Spring application boot, Testcontainers, PostgreSQL migration/RLS test, Compose runtime, or Camunda engine deployment is claimed. CI must provide this evidence before any release decision.

## Main corrections applied

1. Connected `paymentApprovalProcess` to `nivelAprobacionPago` after a successful three-way match.
2. Changed the BPMN to fail closed on unknown/manual approval decisions. Only the explicit automatic branch reaches the durable approval-evidence delegate; all manual review routes terminate without a payment instruction.
3. Added `PersistAutomaticPaymentApprovalDelegate`, which checks tenant and business context, decision output, policy version, currency and threshold; locks the application row; writes immutable `POLICY/APPROVED` evidence; transitions the application to `APPROVED`; and only then permits the payment-instruction delegate.
4. Added V21 to prevent duplicate approved policy decisions for a single application.
5. Strengthened `RegistrarPagoDelegate` to independently require durable, matching approval evidence before inserting a payment; instruction status remains `PENDING`.
6. Expanded BPMN/DMN structural assertions to cover approval delegate ordering and the currency/versioned policy contract.
7. Corrected `verify-gates.sh` to inspect the `camunda` schema, Flyway migrations V17–V21, schema privileges and `FORCE ROW LEVEL SECURITY` on approval evidence.
8. Fixed stale Flyway deployment documentation and Camunda version inventory; fixed an end-to-end test to send the required `Idempotency-Key`.
9. Restricted default Actuator exposure and health-detail disclosure, moved production management endpoints to an internal management port, and added hardened CI/CodeQL/Dependabot/dependency-review workflows pinned to full action commit SHAs. A dedicated dependency-review gate fails PRs for newly introduced high-severity vulnerabilities.
10. Added `README.md`, `SECURITY.md`, `CONTRIBUTING.md` and this audit trail.

## Material residual risks / release blockers

- **Manual approval is not end-to-end.** `GERENTE` and `COMITE` requests fail closed and create no payment instruction, because no authenticated human-approval API/UI, RBAC policy, signed/attributed decision operation and audit flow are implemented yet.
- **The $1,000 MXN automated threshold is inherited from the candidate DMN and must be business-approved explicitly.** The code does not claim it is a legally mandated threshold. If no formal owner approves it, remove automatic approval and route all amounts to manual review.
- **Maven/Testcontainers/Camunda runtime is not locally verified.** CI has been added to run the real build on a Docker-capable GitHub runner. An all-green static gate does not imply CI is green.
- **V20 requires a reviewed migration for installations whose Camunda ACT_% tables are currently in `public`.** Do not bypass its fail-closed guard or run against a production database without a tested migration/backup plan.
- No bank transfer is implemented. PENDING means an instruction record, not a payment executed at a bank.
- Procore inbound webhook and offer submission remain closed/disabled; do not configure external callbacks or call these complete until signature/authentication, tenant identity, deduplication, replay defense, state transitions and integration tests are finished.
- Run the full migration suite against an empty database and a representative prior database, real cross-tenant RLS tests, concurrent idempotency/reservation tests, Camunda deployment/expression tests, restore drill, dependency/license review, and a deployment rollback rehearsal before production.

## GitHub security posture to apply

Workflow YAML uses full-length commit-SHA pins for first-party GitHub Actions, minimal permissions, dependency review on pull requests (high-severity threshold), and unprivileged verification jobs. The archive-import mechanism, if used, must only extract a size-limited/path-validated ZIP in a dedicated write-permission job; it must not execute project files while a write-capable token is available. Build/test must occur in a separate read-only job. Remove the temporary importer workflow before opening the final PR.

For the public repository, enable Secret Scanning + push protection where available, Dependabot alerts and security updates, require pull requests and green checks on `main`, block force pushes/deletion, and keep Actions default token permissions read-only. These repository settings are external controls and are not claimed enabled by this source package.


## Upload handoff state (2026-10-22)

- Target repository: `https://github.com/ytpremiumcr7-collab/nuevorrpo` (public, initially empty).
- Work branch: `prepare/construction-automation-2026-10-22`; default branch `main` is not being replaced or merged.
- A temporary branch-scoped import workflow exists to validate paths/size before extraction, remove itself and the ZIP, and run build/test in a separate read-only job. It was corrected before upload so deleting the untracked ZIP does not fail `git rm`.
- The browser automation could not invoke the operating-system file picker, so the package has not yet been uploaded and the CI workflow has not yet run. Upload only `construction-automation-candidate-upload.zip` using GitHub's upload page for the work branch.
- Since the repository is public, all files in the upload will become public. This archive intentionally excludes the original `.aaf` reference artifact and excludes real `.env`/credential files.
