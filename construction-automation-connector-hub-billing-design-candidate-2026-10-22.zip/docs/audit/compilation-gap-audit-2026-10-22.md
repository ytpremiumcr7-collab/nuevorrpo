# Construction Automation REAL-PROOF — investigación de compilación y pendientes

**Fecha:** 22 de octubre de 2026  
**Artefacto inspeccionado:** `construction-automation-REAL-PROOF-frozen-2026-10-22.zip`  
**Alcance:** determinar si las herramientas disponibles pueden compilar el proyecto ahora; reejecutar las validaciones que sí son ejecutables; consolidar brechas para una build verificable y una eventual autorización de producción.  
**Integridad:** el ZIP congelado y el archivo de referencia no fueron modificados.

## 1. Dictamen ejecutivo

**No hay evidencia de compilación Maven todavía.** En esta ejecución no fue posible compilar ni correr JUnit/Testcontainers: el entorno tiene Java/Javac 21, pero no tiene `mvn`, Maven Wrapper, caché local `~/.m2`, Docker, Podman ni `psql`. Además, la resolución DNS hacia Maven Central falla (`curl: (6) Could not resolve host: repo.maven.apache.org`), por lo que no fue posible instalar Maven ni descargar dependencias.

Sí fue posible reejecutar el análisis estático: 18/18 controles de hardening, 6/6 validaciones estructurales BPMN/DMN, sintaxis de scripts shell y parseo YAML pasaron. **Eso no equivale a compilar, ejecutar pruebas, migrar PostgreSQL ni arrancar Camunda.**

El conector de GitHub instalado puede descubrir repositorios conectados e inspeccionar/volver a ejecutar determinados jobs que ya existen; también hay herramientas para leer logs y artefactos. No encontré un repositorio conectado que correspondiera a `construction-automation`/`REAL-PROOF`, y el ZIP no incluye `.github/workflows/*`. Por ello no hay una CI remota identificada a la cual enviar esta candidata de forma segura. No se publicó código privado en un repositorio ajeno.

## 2. Qué componente sirve para cada cosa

| Componente disponible | Puede aportar | Límite observado en esta tarea | Resultado |
|---|---|---|---|
| Consola de ejecución local del entorno (`container.exec`) | Ejecutar shell, Python, parsers, `javac` y comandos instalados | Maven/Wrapper y caché de dependencias ausentes; DNS a Maven Central no resuelve; Docker/Podman/psql ausentes | **Útil para checks locales, bloqueada para build completa ahora** |
| Integración GitHub | Buscar repos conectados; leer archivos; inspeccionar runs/jobs/logs/artefactos y reejecutar jobs existentes | No apareció repo coincidente ni workflow existente; no se encontró una acción de dispatch de workflow entre las herramientas disponibles | **Útil cuando el código/CI esté en el repo correcto** |
| TinyFish (automatización de navegador) | Navegar e interactuar con páginas web y sitios autenticados | No es un runner de Java/Maven; subir el código a un IDE/repositorio externo implicaría una transferencia externa innecesaria y no autorizada por esta revisión | **No usar como compilador principal** |
| Codelit / Ask-the-Code / skills de revisión | Planificación, lectura de arquitectura, inspección de código y criterios de verificación | No sustituyen un proceso Maven ni un motor PostgreSQL/Camunda; no generan evidencia ejecutable por sí solos | **Complementos de análisis, no el ejecutor de build** |

### Ruta recomendada de compilación real

1. Poner esta versión exacta en un repositorio privado correcto, sin publicar secretos ni `.env` real.
2. Añadir un workflow de CI para JDK 21 y Maven, con caché de dependencias, que ejecute `mvn -B -ntp clean verify`, los dos scripts estáticos y `bash -n`.
3. Ejecutar Testcontainers en un runner que sí tenga Docker funcional. Después, añadir una puerta separada de integración: `docker compose config`, PostgreSQL limpio, aplicación de Flyway V1–V20 y despliegue/ejecución de BPMN/DMN en Camunda.
4. Conservar logs, versiones de toolchain, SHA del commit y artefacto JAR. Un workflow verde acredita exclusivamente los pasos que realmente ejecutó.

GitHub documenta `actions/setup-java` para fijar la distribución/versión del JDK y cachear Maven; el patrón oficial termina ejecutando `mvn verify`. Maven Wrapper puede fijar una versión de Maven y evitar exigirlo preinstalado, pero descarga Maven y dependencias: no resuelve un entorno sin conectividad. Fuentes: [actions/setup-java](https://github.com/actions/setup-java), [Maven Wrapper](https://maven.apache.org/tools/mavenwrapper.html).

## 3. Evidencia reproducida en esta revisión

| Comprobación | Resultado nuevo | Alcance real |
|---|---:|---|
| `python3 scripts/verify-hardening-static.py` | **18/18 PASS** | Presencia de invariantes/patrones en fuentes; no prueba comportamiento en runtime |
| `python3 scripts/verify-workflow-models.py` | **6/6 PASS** | IDs/referencias de BPMN, gates estáticos y reglas DMN; no despliega en Camunda |
| `bash -n run.sh test.sh scripts/*.sh` | **PASS** | Sintaxis shell solamente |
| Parseo con PyYAML de Compose y perfiles de aplicación | **4/4 PASS** | YAML válido; no equivale a `docker compose config` ni a levantar contenedores |
| XML de BPMN/DMN/POM | **PASS en la revisión previa del snapshot** | XML estructural, no validación del motor |
| `mvn clean verify` | **BLOCKED / NO EJECUTADO** | Maven no instalado, sin wrapper/caché; DNS de Maven Central no resuelve |
| JUnit/Testcontainers | **NO EJECUTADO** | Requiere build/dependencias y Docker funcional |
| `docker compose config` / construcción de imagen | **NO EJECUTADO** | Docker no instalado |
| Flyway V1–V20 contra PostgreSQL limpio y BD existente | **NO EJECUTADO** | PostgreSQL/psql y servidor de BD no disponibles |
| RLS, permisos, concurrencia, crash-recovery | **NO EJECUTADO en runtime** | Los checks estáticos no prueban la semántica de PostgreSQL |
| Despliegue/expresiones de 8 BPMN y 4 DMN en Camunda | **NO EJECUTADO** | Sin motor Camunda en ejecución |

Inventario recalculado desde el ZIP: **89 fuentes Java de producción, 13 archivos Java de prueba/soporte, 20 migraciones SQL, 8 BPMN y 4 DMN**. No encontré Maven Wrapper ni archivos `.github/workflows/*`.

## 4. Bloqueadores de máxima prioridad (P0)

### P0-1 — La aprobación de pagos sigue sin aplicarse en el flujo

**Evidencia:** `src/main/resources/bpmn/paymentApprovalProcess.bpmn` conduce desde el resultado `MATCH` (`GW_Match`) directamente a `Task_RegistrarPago`; no aparece una `businessRuleTask` con `camunda:decisionRef="nivelAprobacionPago"`. La DMN está presente, pero no es llamada por el proceso. La tabla `payment_approval_decision` creada en V18 es infraestructura de datos; la presencia de una tabla y pruebas de RLS no demuestra que una decisión se escriba/verifique antes de registrar la instrucción.

**Falta:** integrar la decisión DMN; definir variables de entrada/salida y versión de política; persistir evidencia durable de decisión y aprobador; validar rol/pertenencia a tenant/obra; hacer que cualquier rechazo, ausencia, timeout o inconsistencia cierre la ruta; añadir pruebas positivas y negativas de extremo a extremo. `RegistrarPagoDelegate` no debe poder saltarse este gate por llamada directa.

### P0-2 — Los pagos no tienen integración bancaria ni liquidación

El propio código/documentación limita la acción al registro de una instrucción en estado `PENDING`; no hay proveedor bancario ni callback de liquidación verificado. Falta definir e implementar, si entra en alcance: adaptador bancario, idempotencia del proveedor, autenticidad de callbacks, máquina de estados, reintentos/errores, conciliación bancaria y recuperación ante respuestas inciertas. Hasta entonces, no afirmar que un pago está autorizado, ejecutado o liquidado ni activar una transferencia real.

### P0-3 — No se ha demostrado la compilación

El resultado de release no puede ser PASS hasta ejecutar al menos `mvn -B -ntp clean verify` con Java 21, resolver cualquier error real de compilación/pruebas y guardar logs. La ausencia de evidencia no prueba que compile ni que no compile.

### P0-4 — Migración de bases de datos Camunda existentes

`V20__camunda_schema_isolation.sql` falla deliberadamente si encuentra tablas `ACT_%` en `public`. Esto es fail-closed para una instalación heredada; no es un camino automático de actualización. Antes de migrar una BD ya existente se necesita inventario, backup/restore comprobado, plan de mantenimiento, migración revisada al esquema `camunda` y validación de historial/IDs/relaciones del motor. No eliminar ni recrear esas tablas para “pasar” la migración.

## 5. Defectos e inconsistencias concretos para corregir antes de confiar en los gates (P1)

### P1-1 — El script de release consulta Camunda en el esquema anterior

**Evidencia:** `scripts/verify-gates.sh` líneas 63–70 consulta `public.act_re_procdef` y `public.act_re_decision_def`. La candidata configura `camunda.bpm.database.schema-name: camunda` en `src/main/resources/application.yml` y V20 prepara ese esquema. Tras el cambio, las consultas de gate seguirían buscando en `public` y pueden reportar fallo aunque el motor esté desplegado correctamente en `camunda`.

**Corrección:** hacer configurable/verificar el esquema del motor y consultar `camunda.act_re_procdef`/`camunda.act_re_decision_def` para la instalación nueva. Añadir una prueba de regresión del script con el esquema esperado. La revisión estática actual no valida estas consultas contra PostgreSQL.

### P1-2 — La puerta SQL está desactualizada respecto de V18–V20

`verify-gates.sh` exige V17 registrada, pero no verifica que V18, V19 y V20 estén aplicadas correctamente; además, todavía presupone las tablas Camunda en `public`. Actualizar el gate de versión de esquema, role grants, RLS de `payment_approval_decision`, esquema Camunda y constraints de reservas. Evitar que un gate viejo sea tratado como certificado de una BD de la candidata actual.

### P1-3 — Documentación contradictoria sobre Flyway

El Compose actual incluye un servicio `migrator` aislado y `SPRING_FLYWAY_ENABLED: "false"` en `app`, pero `.env.example` líneas 18–22 y `HARDENING_NOTES.md` mantienen texto antiguo que dice que Flyway corre con `postgres` en el arranque de la aplicación. Corregir estos textos y retirar variables Flyway que ya no corresponden al runtime HTTP, o dejar explícitamente documentado cuándo se usan en pruebas locales. La configuración ejecutada manda; documentación vieja puede inducir un despliegue inseguro.

### P1-4 — Inventario de licencias/versiones tiene al menos una discrepancia

`pom.xml` declara Camunda Spring Boot Starter **7.21.0**; `THIRD-PARTY.md` lo lista como **1.0.0**. Corregir versión, verificar licencias/versiones efectivamente resueltas mediante `mvn dependency:tree` y el plugin/escáner aprobado, y revisar avisos/licencias/transitivas antes de distribuir el JAR o imagen. No declarar terminado este control hasta producir el inventario real de build.

### P1-5 — Falta una CI reproducible dentro del proyecto

No hay `.github/workflows/*` ni `mvnw`. Hoy el paquete depende de que el entorno ya tenga Maven y conectividad. Añadir CI y, opcionalmente, Maven Wrapper con versión fijada. El Wrapper facilita reproducibilidad y evita depender de una instalación global, pero no evita necesitar descargas la primera vez.

## 6. Resto de trabajo pendiente, por área

### Build, pruebas y release engineering

- Ejecutar Maven clean/verify y clasificar cada fallo como código, prueba, configuración o entorno; no omitir/silenciar fallos.
- Correr los 13 archivos Java de prueba/soporte y comprobar cuántas clases/métodos de test se ejecutan realmente, duración y flakes.
- Testcontainers con roles separados (`app_user`, `outbox_worker`, usuario admin de fixtures); probar RLS por tenant y permisos, no sólo compilación.
- `docker compose config` en modo local y prod con variables de prueba; construir ambas imágenes; levantar stack limpio y comprobar readiness.
- Aplicar Flyway desde base vacía y actualizar copia de versión anterior; medir posibles duplicados que bloqueen el índice único de V17; probar V18–V20 y reinstalación idempotente donde aplique.
- Desplegar los 8 BPMN y 4 DMN en Camunda y ejecutar cada ruta relevante, timers, mensajes, expresiones y delegates. La validación XML actual no sustituye esto.
- Generar JAR y contenedor identificados por SHA de commit; guardar logs/artefactos SBOM y resultados de dependencias.

### Seguridad, identidad y aislamiento

- Certificar una matriz completa de permisos para **cada endpoint, job, worker, delegate BPMN y servicio interno**, por tenant y por obra.
- Probar que `X-Tenant-Id` siempre coincide con el tenant de la API key; no aceptar IDs de usuario, party, proyecto, contrato o documento sólo porque vienen en el body.
- Verificar RLS activa y `FORCE ROW LEVEL SECURITY` en todas las tablas operativas con `tenant_id`, excepciones justificadas, y que `app_user` no sea owner, superuser ni `BYPASSRLS`.
- Comprobar `outbox_worker` con `LOGIN`, sin superuser/BYPASSRLS, y permisos mínimos; probar que sólo él puede reclamar la cola global.
- Probar autorización de `/actuator/*`, salud/detalles e información desplegada; el checklist ya señala este control como pendiente.
- Llevar `EVIDENCE_HMAC_KEY`, tokens y credenciales a KMS/Vault/secret manager en producción; rotación segura de contraseñas de roles en volúmenes PostgreSQL existentes.
- Revisar logs por PII/secretos, propagación de `traceId` y límites/abuso de API; no habilitar `ALLOW_X_USER_ID` fuera de test/dev aislado.

### Integridad del flujo de pagos y outbox

- Tests de idempotencia: mismo `Idempotency-Key` + mismo payload retorna el mismo proceso; misma clave con payload distinto falla; simultaneidad con facturas/obras diferentes; rollback entre escritura de solicitud y creación de proceso.
- Tests de reservas parciales, pagos `PENDING`/`EXECUTED`/`FAILED`, facturas ya pagadas/canceladas, moneda y escala decimal; aclarar si las instrucciones `FAILED` deben reservar importe o liberarlo según reglas de negocio.
- Probar carreras y bloqueo de factura bajo concurrencia real; no inferir que `FOR UPDATE` se comporta bien sólo por leer el código.
- Probar tres-way match con cabecera/líneas, cantidades, precios, moneda, duplicados/extras/faltantes, PO de otro proyecto y evidencia/compliance revocados durante el proceso.
- Probar outbox con dos workers, lease expirado, crash después del claim, reintentos, backoff, dead-letter, evento sin handler y recuperación/replay sin duplicar efectos.

### Integraciones y capacidades cerradas

- **Procore inbound:** permanece HTTP 501. Falta verificación de firma del emisor, deduplicación de evento, tenant/proyecto confiable, handler inbound y pruebas replay/tampering.
- **Envío de ofertas:** permanece HTTP 501. Falta vínculo verificado entre identidad del usuario y `party` legal, autorización por paquete/licitación, reglas de cierre y auditoría del envío.
- **OSHA/ITA:** el payload de formularios y sus mapeos documentales/normativos no están validados contra el contrato real; mantener cerrado hasta test contractual y revisión normativa.
- **Autoridades municipales/permisos:** documentar y probar el flujo manual `PENDING_VERIFICATION`, responsables, tiempos, auditoría y reanudación.
- **ERP/banca:** conciliación no implementada; establecer de forma explícita si se excluye de la primera versión.
- **Progress vision pipeline 6.2:** está señalado como subproyecto pendiente.
- **Fase 5/cierre de puentes:** sigue pendiente, incluyendo autorización legal de los ofertantes y ACL bidireccional de Procore.
- **Notificaciones:** SMTP/entrega externa, reintentos, fallos permanentes, idempotencia y alertas requieren pruebas de integración reales; no tratar una llamada interna como entrega confirmada.

### Operación, recuperación y gobierno de release

- Automatizar backups; probar restore en ambiente limpio y medir RTO; habilitar/validar WAL/PITR sólo según una configuración realmente probada.
- Aprobar runbook de cutover de Billing (R1–R5) y runbook de rollback N-1 por responsables de Finanzas/Legal/CTO/CFO.
- Confirmar alertas reales para dead-letter, pagos bloqueados y errores HTTP; confirmar scrape Prometheus y parser ELK/Loki.
- Completar/reconciliar `TRACEABILITY.md`, `PHASES.md`, `OPERATIONS.md`, `THIRD-PARTY.md`, checklist y CHANGELOG con los nombres/versiones actuales.
- Revisión y firma final de CTO, Finanzas, Legal/Compliance y Seguridad/DPO antes de cualquier GO-LIVE.

## 7. Secuencia sugerida de cierre

1. **Habilitar evidencia de build:** conseguir un runner con JDK 21/Maven/red y ejecutar `mvn clean verify`; agregar CI permanente.
2. **Corregir los gates y drift documental:** `verify-gates.sh` para schema `camunda` y V18–V20; corregir `.env.example`, `HARDENING_NOTES.md`, checklist y versión de Camunda en `THIRD-PARTY.md`.
3. **Cerrar aprobación de pagos (P0):** conectar DMN+BPMN+persistencia+autorización y pruebas negativas; conservar `PENDING`, sin transferencia real.
4. **Validar DB y permisos reales:** base limpia, upgrade desde snapshot anterior, V1–V20, RLS, roles y concurrencia/outbox.
5. **Validar Camunda de extremo a extremo:** despliegue/ejecución de BPMN/DMN/timers/mensajes/delegates en runtime.
6. **Cerrar o documentar explícitamente las integraciones aplazadas** y aprobar recuperación/seguridad/operación.
7. **Sólo entonces** decidir release, firmar evidencia y etiquetar artefactos por commit.

## Veredicto

**Estado: CANDIDATA CON BLOQUEOS; GO-LIVE NO APROBADO.** Los controles estáticos reproducidos están verdes, pero compile, suite de pruebas, migraciones, RLS real, despliegue Camunda y varios contratos de integración siguen sin evidencia ejecutable. La prioridad inmediata no es “forzar verde”: es obtener un runner con Maven/Docker y CI sobre esta misma versión, corregir el script de gates que aún consulta el esquema anterior y completar la aprobación de pagos antes de describirla como operativa.
