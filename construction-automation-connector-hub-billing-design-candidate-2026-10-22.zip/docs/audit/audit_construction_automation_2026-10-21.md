# Informe de hardening — Construction Automation REAL-PROOF

**Fecha:** 21 de octubre de 2026  
**Estado:** candidata endurecida para siguiente ciclo de verificación. **NO aprobada para producción.**  
**Archivo fuente recibido:** `construction-automation-REAL-PROOF.aaf`

## 1. Integridad y alcance

Se trabajó sobre una copia extraída del paquete original. El archivo subido se conservó sin alteración.

- Archivos originales: **161**.
- Archivos originales ausentes en la candidata: **0**.
- Archivos originales modificados: **49**.
- Archivos nuevos: **10**.
- Prueba de integridad del ZIP candidato: `unzip -t` terminó sin errores.

Los archivos nuevos incluyen la migración `V17__hardening_security_outbox_payment.sql`, configuración de conexión independiente para el worker del outbox, provisionamiento de su rol, autorización por proyecto, comprobaciones estáticas y esta documentación de hardening.

## 2. Cambios principales

### Autenticación, tenant y autorización

- `X-User-Id` queda deshabilitado por defecto; el modo de desarrollo debe activarse explícitamente.
- La búsqueda de API key se hace mediante hash y dentro del tenant suministrado.
- El bootstrap requiere un secreto, tiene comparación de tiempo constante, bloqueo por fila del tenant y emite una API key que se almacena como hash.
- Se añadió una autorización por proyecto y se quitaron varias decisiones de actor confiadas a campos del cuerpo HTTP.
- Las consultas del dashboard y de colas operativas se limitan por membresías de obra y tienen límites de paginación.
- El contexto RLS se configura dentro de transacciones de base de datos donde corresponde; los filtros limpian su contexto de thread al concluir la petición.

### Pagos y controles de workflow

- La factura, el proyecto, el contrato, el subcontratista, el monto y la versión de compliance se vuelven a comprobar contra datos persistidos.
- La evaluación three-way rechaza órdenes de compra de otra obra, líneas duplicadas y conjuntos de líneas asimétricos.
- Las compuertas BPMN de cumplimiento y three-way match son *fail-closed*.
- El delegate deja una instrucción `PENDING`; no afirma que haya aprobación final ni que una transferencia bancaria se haya ejecutado.
- La migración añade una unicidad para evitar pagos duplicados por una misma solicitud. Debe medirse si existen duplicados históricos antes de aplicar V17 a una base con datos.

### Outbox e integraciones

- El claim transversal del outbox ya no está concedido al rol de API `app_user`; se reserva al rol `outbox_worker`, configurado por una conexión/pool separado.
- Los eventos sin handler provocan error/reintento y no se marcan silenciosamente como procesados.
- Los scripts de inicialización configuran las credenciales de `app_user` y `outbox_worker` después de crear sus roles.
- El gate de RLS ahora inspecciona tablas operativas que tengan `tenant_id`, evitando clasificar tablas globales de Camunda como tablas tenant de la aplicación.
- Se corrigió la discrepancia de Compose entre la contraseña que inicializa el rol `postgres` y la contraseña suministrada a Flyway.
- Procore inbound y el envío de ofertas devuelven `501 NOT_IMPLEMENTED` hasta implementar la verificación de firma/identidad, el enrutamiento tenant-proyecto y la atribución confiable al contratista. Es un cierre explícito, no una funcionalidad terminada.

## 3. Evidencia ejecutada

| Comprobación | Resultado | Alcance real |
|---|---|---|
| `python scripts/verify-hardening-static.py` | **13/13 PASS** | Invariantes textuales seleccionados; no es compilación ni prueba de runtime. |
| `bash scripts/prove-construction-niche.sh` | **PASS** | Inventario y existencia de módulos/recursos esperados. |
| `bash -n` para los scripts `.sh` | **PASS** | Sintaxis shell. |
| `node --check` para JavaScript estático | **PASS** | Parseo JavaScript. |
| XML, YAML y referencias de flujo BPMN | **PASS** | Se parsearon 2 XML, 8 YAML y 8 BPMN; IDs BPMN únicos y extremos de `sequenceFlow` resueltos. No significa que Camunda acepte/despliegue todos los artefactos. |
| ZIP candidato (`unzip -t`) | **PASS** | Archivo comprimido íntegro. |
| `./test.sh` / Maven | **BLOQUEADO** | `mvn` no está instalado; JUnit/Testcontainers no se ejecutaron. |
| `scripts/verify-gates.sh` y `scripts/verify-invariants.sh` | **BLOQUEADOS** | `psql`/PostgreSQL no están disponibles. Los scripts abortan sin declarar éxito. |
| Docker Compose | **NO EJECUTADO** | `docker` no está disponible; no se verificó configuración efectiva ni arranque. |
| Flyway/RLS contra PostgreSQL real | **NO EJECUTADO** | No se aplicó V17 ni se probaron roles/policies. |
| Despliegue BPMN/DMN en Camunda | **NO EJECUTADO** | No hay motor desplegado para validar semántica y ejecución. |

## 4. Bloqueadores de release

### P0 — Migraciones con credencial superuser en el proceso HTTP

La aplicación aún usa Flyway al arrancar con `SPRING_FLYWAY_USER=postgres`; por eso el contenedor HTTP recibe la contraseña superuser. La candidata alinea esa contraseña con la que realmente inicializa PostgreSQL, pero **no elimina el riesgo de privilegios**. Antes de producción debe moverse la migración a un job/runner aislado y quitarse la credencial superuser del contenedor HTTP.

### P0 — Aprobación de pago y liquidación bancaria

El DMN `nivelAprobacionPago.dmn` no está conectado al BPMN de pago. No se ha demostrado un registro durable de aprobación humana/política ni una integración de banco, callback, idempotency key del proveedor o conciliación. Mantener el estado pendiente y no habilitar transferencias reales.

### P1 — Autorización completa

Los controles incorporados afectan los endpoints y servicios identificados, pero no se demostró una matriz negativa completa para todos los controladores, servicios, jobs y delegates BPMN. Se necesitan pruebas cross-tenant y cross-project con roles reales de base de datos.

### P1 — Migración y outbox

- Aplicar V17 sobre base vacía y sobre una copia de datos; comprobar duplicados antes de crear `ux_payment_one_per_application`.
- Verificar que `outbox_worker` tiene LOGIN y no posee `SUPERUSER`, `BYPASSRLS`, `CREATEROLE` ni `CREATEDB`; confirmar que `app_user` no ejecuta la función de claim.
- Probar concurrencia, caída del worker, reintentos, dead-letter y recuperación con PostgreSQL real. La prueba actual usa inspección estática y el entorno local no replica los permisos del worker.

### P1 — Gaps de producto/integración

- Completar el contrato de identidad `app_user` → `party` antes de habilitar el envío de ofertas.
- Implementar y verificar autenticidad y procesamiento de webhooks entrantes Procore antes de reactivarlos.
- La generación de formularios OSHA debe permanecer bloqueada hasta completar mapeo, revisión normativa y pruebas.
- Probar seguridad de Actuator, secretos, backups/restauración y configuración efectiva de producción.

## 5. Decisión recomendada

Aceptar el paquete solo como **candidata de hardening para la siguiente iteración**. No etiquetar, publicar ni desplegar como release de producción hasta cerrar ambos bloqueadores P0 y demostrar `mvn clean verify`, despliegue real de PostgreSQL/Flyway, RLS con roles no propietarios, autorización cross-tenant/project y ejecución de BPMN/DMN en Camunda.

## 6. Identificación del artefacto

SHA-256 del archivo original y del ZIP candidato incluidos en `construction-automation-manifest.sha256`.
