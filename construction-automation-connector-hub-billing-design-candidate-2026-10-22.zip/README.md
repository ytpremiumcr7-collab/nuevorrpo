# Construction Automation — hardening candidate

> **Release status: candidate only. Not approved for production or real disbursements.**

Construction-workflow automation with deterministic compliance gates, contractor/project documentation, three-way invoice/PO/receipt matching, and controlled payment-instruction creation. This repository does not execute bank transfers. Payment instructions remain `PENDING`.

## Security and workflow posture

- Payment registration is downstream of a successful persisted three-way match and a versioned approval decision.
- The only automated policy route currently modeled is MXN below the configured threshold; it writes durable, tenant-scoped `POLICY/APPROVED` evidence before the payment delegate runs.
- Requests routed to human review end without an instruction. An authenticated human-approval API/UI has **not** been implemented; do not treat manual approval as operational.
- The HTTP runtime does not run Flyway as the database owner. Migrations run in a one-shot migrator service; Camunda is configured for schema `camunda`.
- Procore inbound webhook and offer submission remain disabled/closed until identity, signature, deduplication, and complete processing contracts are implemented.
- No production credentials, `.env`, database dumps, or generated build output belong in the repository.

## Local verification

Requirements: JDK 21, Maven 3.9.x, Docker Engine with Compose plugin, and a network connection to resolve dependencies.

```bash
bash -n run.sh test.sh scripts/*.sh
python3 scripts/verify-hardening-static.py
python3 scripts/verify-workflow-models.py
bash scripts/prove-construction-niche.sh
mvn -B -ntp clean verify
```

The Maven test suite uses Testcontainers and therefore needs a working Docker daemon. Static checks are not a substitute for the compile, database, RLS, or Camunda runtime tests.

To validate Compose configuration with placeholders rather than production values:

```bash
docker compose --env-file .env.example config --quiet
docker compose --env-file .env.example -f docker-compose.yml -f docker-compose.prod.yml config --quiet
```

For a local runtime, copy `.env.example` to `.env` and replace every `REPLACE_WITH_*` value with distinct random development secrets. Never copy production credentials into a workstation `.env` or commit it.

## Production-blocking limitations

1. Build and integration tests must pass on CI with Maven, PostgreSQL/Testcontainers, and the Camunda engine.
2. The human-approval service for routes `GERENTE` / `COMITE` is not implemented; those routes fail closed.
3. V20 intentionally refuses a database where legacy Camunda `ACT_%` tables remain in `public`; a reviewed migration is required first.
4. Real bank transfer, webhook-driven state changes, and external offer submission are not implemented/authorized.
5. Full migration rehearsal from representative existing data, restore drill, dependency/license review, and deployment rollback test remain required.

See `GO-LIVE-CHECKLIST.md`, `SECURITY.md`, `PROOF.md`, and `docs/audit/` for the verification contract and blockers.
