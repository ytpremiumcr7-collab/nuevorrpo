# Matriz de trazabilidad: requisito → tabla → servicio → BPMN → DMN → test

## Los 7 procesos originales

### 1. Cumplimiento de subcontratistas

| Capa | Artefactos |
|------|-----------|
| Tablas | `compliance_subcontractor_head`, `compliance_requirement`, `payment_invalidation` |
| Servicio | `ComplianceService`, `PaymentInvalidationService` |
| BPMN | `paymentApprovalProcess` (con `Task_VerifyComp` → `Task_EvalCompDMN` → `GW_Comp`) |
| DMN | `complianceVigente` |
| Delegates | `VerificarComplianceDelegate`, `ComplianceProjectorSync`, `ComplianceAsyncProjector` |
| Controller | `ComplianceController` (`POST /api/compliance/requirements`, `/verify`, `/revoke`) |
| Tests | `VersionFencingTest` (4 escenarios), `ThreeWayMatchFailLoudTest` |
| Garantía | `errorEndEvent` + `boundaryEvent` de mensaje + proyección síncrona + fencing por `complianceVersionSeen` |

### 2. Documentación del proyecto

| Capa | Artefactos |
|------|-----------|
| Tablas | `rfi`, `rfi_routing_policy`, `change_order`, `submittal` |
| Servicio | `ProjectDocumentsService` |
| BPMN | `rfiProcess`, `changeOrderProcess` |
| Delegates | `RouteRfiDelegate`, `EscalateRfiDelegate`, `CalcChangeOrderImpactDelegate` |
| Controller | `ProjectDocumentsController` |
| Tests | Pendiente: `RfiRoutingTest` (política por `work_package`, fallback global) |
| Garantía | Política de asignación en BD; escalación por umbral de monto; justificación obligatoria en CO |

### 3. Gestión de licitaciones

| Capa | Artefactos |
|------|-----------|
| Tablas | `bid_package`, `bid` |
| Servicio | `BiddingService` |
| BPMN | `bidProcess` |
| Delegates | `RequestBidsDelegate`, `CompareBidsDelegate` |
| Controller | `BiddingController` |
| Tests | `BiddingAwardConcurrencyTest` |
| Garantía | `UPDATE ... WHERE status IN (...)` atómico; justificación obligatoria; crea `Contract` transaccionalmente |

### 4. Incidentes OSHA

| Capa | Artefactos |
|------|-----------|
| Tablas | `safety_incident`, `corrective_action`, `osha_300_log`, `osha_form_300`, `osha_form_301` |
| Servicio | `SafetyService` |
| BPMN | `incidentReportProcess` (timer 8h/24h) |
| Delegates | `ClassifyIncidentDelegate`, `GenerateOshaFormsDelegate`, `EscalateOshaDeadlineDelegate` |
| Controller | `SafetyController` |
| Jobs | `OshaDeadlineSweepJob` (independiente del BPMN) |
| Tests | `ClassifyIncidentTest` |
| Garantía | Timer BPMN + sweep independiente + retención 5 años en `osha_300_log.retained_until` |

### 5. Seguimiento de permisos

| Capa | Artefactos |
|------|-----------|
| Tablas | `permit_application`, `permit_phase_config` |
| Servicio | `PermitService` |
| BPMN | `permitApplicationProcess` (timer con fecha absoluta) |
| Delegates | `SubmitPermitDelegate`, `EscalatePermitDelegate` |
| Controller | `PermitController` |
| Tests | Pendiente: `PermitConfigRequiredTest` |
| Garantía | Fail-loud sin configuración de plazo; `time_unit` explícito (calendar vs business days) |

### 6. Informes de progreso

| Capa | Artefactos |
|------|-----------|
| Tablas | `bim_element_observation`, `progress_observation`, `progress_certified_read_model` |
| Servicio | Pendiente: `ProgressService` |
| BPMN | Pendiente: `progressCertificationProcess` |
| Tests | Pendiente: `ProgressIntervalTest` |
| Garantía | `PROGRESS_CERTIFIED` solo si `progress_ratio_lower >= contractual_threshold`; Billing solo lee la proyección certificada |
| Gap | Pipeline de visión 6.2 (SfM, NeRF, MLOps) — sub-proyecto independiente |

### 7. Facturas y pagos

| Capa | Artefactos |
|------|-----------|
| Tablas | `invoice`, `invoice_line`, `purchase_order`, `purchase_order_line`, `goods_receipt`, `goods_receipt_line`, `three_way_match_result`, `payment_application`, `payment`, `payment_read_model`, `payment_invalidation` |
| Servicio | `PaymentApplicationService`, `PaymentInvalidationService` |
| BPMN | `paymentApprovalProcess` |
| DMN | `complianceVigente`, `nivelAprobacionPago` |
| Delegates | `ThreeWayMatchDelegate`, `RegistrarPagoDelegate`, `VerificarComplianceDelegate` |
| Controller | `PaymentController` |
| Tests | `ThreeWayMatchFailLoudTest`, `VersionFencingTest`, `EndToEndHappyPathTest` |
| Garantía | Three-way match + gate de compliance + fencing + saga de compensación + disputa |

## Post-ejecución (compensación + disputa)

| Proceso | Tablas | Servicio | BPMN | DMN | Tests |
|---------|--------|----------|------|-----|-------|
| Compensación | `compensation_case`, `recovery_account`, `deduction_log` | `CompensationService` | `compensationCaseProcess` | — | `RecoveryAccountConcurrencyTest` |
| Disputa | `dispute_case`, `dispute_case_current`, `dispute_case_history`, `dispute_provision_snapshot`, `evidence_manifest`, `business_calendar`, `dispute_phase_config` | `DisputeService` | `disputeCaseProcess` | `disputeResolutionDecision` | `DisputeDeadlineTest`, `DisputeCalendarChangeTest` |

## Garantías estructurales por capa

| Garantía | Mecanismo | Verificable en |
|----------|-----------|----------------|
| Pago sin compliance NO se ejecuta | `errorEndEvent` + `boundaryEvent` | `VersionFencingTest` |
| Revocación en vuelo cancela el pago | `boundaryEvent` de mensaje | `VersionFencingTest` |
| Doble award no crea dos contratos | `UPDATE ... WHERE status IN (...)` | `BiddingAwardConcurrencyTest` |
| Dos deducciones no sobregiran | `UPDATE ... WHERE version = ? AND saldo >= ?` | `RecoveryAccountConcurrencyTest` |
| Outbox no se procesa dos veces | `SKIP LOCKED` + `UNIQUE (tenant, event_id)` | `OutboxClaimConcurrencyTest` |
| Aislamiento entre tenants | RLS + `SET LOCAL app.tenant_id` | `RlsIsolationTest` |
| Audit chain no se corrompe | Trigger append-only + `verify_audit_chain` | `EndToEndHappyPathTest` |
| Plazos respetan calendario laboral | `add_business_days` SQL | `DisputeCalendarChangeTest` |
| Timezone inmutable post-pago | Trigger `enforce_timezone_immutability` | Pendiente test |
| Adjudicación exige justificación | `IllegalArgumentException` | Pendiente test |
| Permiso sin config falla ruidoso | `IllegalStateException` | Pendiente test |
