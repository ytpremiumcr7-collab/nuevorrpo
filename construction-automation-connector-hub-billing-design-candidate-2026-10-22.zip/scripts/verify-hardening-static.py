#!/usr/bin/env python3
"""Static guardrails for critical source invariants. This is not a compiler or integration test."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
checks = []
def check(name, condition, detail): checks.append((name, bool(condition), detail))
def read(rel): return (ROOT / rel).read_text(encoding="utf-8")

auth = read("src/main/java/com/tuempresa/identity/security/AuthFilter.java")
config = read("src/main/resources/application.yml")
bootstrap = read("src/main/java/com/tuempresa/identity/web/BootstrapController.java")
payment = read("src/main/java/com/tuempresa/billing/delegate/RegistrarPagoDelegate.java")
threeway = read("src/main/java/com/tuempresa/billing/delegate/ThreeWayMatchDelegate.java")
compliance = read("src/main/java/com/tuempresa/compliance/delegate/VerificarComplianceDelegate.java")
bpmn = read("src/main/resources/bpmn/paymentApprovalProcess.bpmn")
outbox = read("src/main/java/com/tuempresa/platform/events/OutboxPoller.java")
ops = read("src/main/java/com/tuempresa/platform/web/OpsDashboardController.java")
webhook = read("src/main/java/com/tuempresa/integration/procore/ProcoreController.java")

check("X-User-Id deshabilitado por defecto", '@Value("${construction.auth.allow-user-id:false}")' in auth and 'allow-user-id: ${ALLOW_X_USER_ID:false}' in config,
      "El bypass solo debe usarse por configuración explícita de dev/test.")
check("Bootstrap requiere secreto y compara en tiempo constante", 'X-Bootstrap-Token' in bootstrap and 'MessageDigest.isEqual' in bootstrap and 'expectedToken.isBlank()' in bootstrap,
      "Sin secreto, bootstrap debe quedar deshabilitado.")
check("Pago no se marca ejecutado sin proveedor", "'PENDING'" in payment and "SET status = 'EXECUTED'" not in payment and "executed_at" in payment and "NULL, 'PENDING'" in payment,
      "El delegate crea instrucción pendiente, no transferencia bancaria.")
check("Three-way match cubre proyecto y simetría de líneas", "project_id = ?" in threeway and "invLines.size() != poLines.size()" in threeway and "invoiceLineNumbers.equals(poLineNumbers)" in threeway,
      "No aceptar PO de otra obra ni líneas omitidas/duplicadas.")
check("Three-way match concilia total de encabezado y líneas", "MISMATCH_FACTURA_TOTAL" in threeway and "invoiceLineTotal" in threeway,
      "No se registra pago si el total del encabezado no coincide con la suma extendida de líneas.")
check("Match BPMN es fail-closed", 'id="GW_Match" default="F_Match_Fail"' in bpmn and "matchResult.estado == 'MATCH'" in bpmn,
      "Solo una salida MATCH explícita entra a registrar pago.")
check("Compliance BPMN es fail-closed", 'id="GW_ComplianceDecision" default="F_P2_Blocked"' in bpmn and "complianceValid == true" in bpmn and "requisitos_vigentes" in compliance and "!expiry.isBefore(hoy)" in compliance,
      "El gate exige estado global, conteos, estado crítico y fecha vigente.")
check("Outbox rechaza handlers desconocidos", 'Tipo outbox sin handler registrado' in outbox and 'default -> throw new IllegalStateException' in outbox,
      "Un evento sin handler no debe marcarse procesado.")
outbox_sql = read("src/main/resources/db/migration/V17__hardening_security_outbox_payment.sql")
outbox_cfg = read("src/main/java/com/tuempresa/platform/events/OutboxDataSourceConfiguration.java")
check("Claim global aislado en credencial de worker", "REVOKE ALL ON FUNCTION claim_projection_outbox(integer) FROM app_user" in outbox_sql and "TO outbox_worker" in outbox_sql and '@Qualifier("outboxJdbcTemplate")' in outbox and 'outboxTransactionManager' in outbox_cfg,
      "El worker tiene su propio datasource/pool y app_user no recibe permiso de ejecución.")
check("Dashboard limita colas por membresía de obra", "project_membership pm" in ops and "pm.user_id = ?" in ops and "boundedLimit" in ops,
      "Las métricas/colas no deben ser de todo el tenant para cada usuario.")
check("Webhook Procore no devuelve falso éxito", "HttpStatus.NOT_IMPLEMENTED" in webhook and "deshabilitado" in webhook.lower(),
      "Inbound permanece cerrado hasta verificación y procesamiento real.")
check("Ofertas no aceptan bidderId no verificado", "HttpStatus.NOT_IMPLEMENTED" in read("src/main/java/com/tuempresa/bidding/web/BiddingController.java") and "vínculo de identidad" in read("src/main/java/com/tuempresa/bidding/web/BiddingController.java"),
      "Evita atribuir una oferta a un tercero antes de enlazar el usuario con la parte legal.")
compose = read("docker-compose.yml")
gates = read("scripts/verify-gates.sh")
check("Migraciones aisladas del runtime HTTP", 'dockerfile: Dockerfile.migrator' in compose and 'SPRING_FLYWAY_ENABLED: "false"' in compose and 'enabled: ${SPRING_FLYWAY_ENABLED:false}' in config,
      "La credencial de propietario solo debe estar en el job de migración, nunca en el API.")
check("Camunda aislado de public", "schema-name: camunda" in config and "CREATE SCHEMA IF NOT EXISTS camunda" in read("src/main/resources/db/migration/V20__camunda_schema_isolation.sql") and "REVOKE CREATE ON SCHEMA public FROM app_user" in read("src/main/resources/db/migration/V20__camunda_schema_isolation.sql"),
      "Las tablas del motor no deben forzar privilegios CREATE amplios sobre public.")
payment_service = read("src/main/java/com/tuempresa/billing/service/PaymentApplicationService.java")
payment_controller = read("src/main/java/com/tuempresa/billing/web/PaymentController.java")
check("Solicitud de pago exige idempotencia", 'RequestHeader("Idempotency-Key")' in payment_controller and "submission_idempotency_key" in payment_service and "submission_request_hash" in payment_service,
      "Los reintentos exactos devuelven el proceso existente y una clave reutilizada con otro payload falla.")
check("Reservas parciales no exceden factura", "pendingApplications.add(reservedPayments).add(amount).compareTo(invoiceAmount)" in payment_service and "FOR UPDATE" in payment_service,
      "El bloqueo de factura serializa la comprobación de solicitudes y pagos reservados.")
test_base = read("src/test/java/com/tuempresa/testsupport/PostgresTestBase.java")
test_admin = read("src/test/java/com/tuempresa/testsupport/TestAdminJdbcConfiguration.java")
check("Suite usa roles de aplicación y worker separados", '() -> "app_user"' in test_base and '() -> "outbox_worker"' in test_base and 'withInitScript("db/test-roles.sql")' in test_base and 'testAdminJdbcTemplate' in test_admin,
      "Las pruebas usan roles restringidos para runtime y conexión administrativa separada para fixtures.")
check("Gate RLS inspecciona tablas que realmente tienen tenant_id", "col.column_name='tenant_id'" in gates and "NOT c.relrowsecurity" in gates,
      "Evita tratar tablas globales del motor como tablas multi-tenant y omitir las de aplicación.")

errors = 0
for name, passed, detail in checks:
    print(f"{'PASS' if passed else 'FAIL'} | {name} | {detail}")
    errors += not passed
print(f"RESULT: {len(checks)-errors}/{len(checks)} static guardrails passed")
print("LIMIT: static source inspection only; not compilation, database, BPMN-engine or integration evidence.")
sys.exit(1 if errors else 0)
