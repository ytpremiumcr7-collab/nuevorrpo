#!/usr/bin/env bash
# Release gates backed by PostgreSQL metadata. Presence-only checks are not sufficient.
set -euo pipefail

PGHOST="${PGHOST:-localhost}"
PGPORT="${PGPORT:-5432}"
PGUSER="${PGUSER:-postgres}"
PGDATABASE="${PGDATABASE:-construction}"
PSQL=(psql -X -v ON_ERROR_STOP=1 -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$PGDATABASE" -t -A)

if ! command -v psql >/dev/null 2>&1; then
  echo "BLOCKED: psql no está instalado; no se pueden verificar gates de BD."
  exit 2
fi
if ! "${PSQL[@]}" -c 'SELECT 1' >/dev/null 2>&1; then
  echo "BLOCKED: no se pudo conectar a $PGHOST:$PGPORT/$PGDATABASE como $PGUSER."
  exit 2
fi

fail=0
check() {
  local name="$1" query="$2" expected="$3" actual
  if actual=$("${PSQL[@]}" -c "$query" 2>/dev/null); then :; else actual="ERR"; fi
  actual="$(printf '%s' "$actual" | tr -d '[:space:]')"
  if [[ "$actual" == "$expected" ]]; then
    echo "  PASS | $name"
  else
    echo "  FAIL | $name | esperado=$expected obtenido=$actual"
    fail=1
  fi
}

echo "Gates release DB=$PGDATABASE host=$PGHOST:$PGPORT user=$PGUSER"

check "schema public: audit_event existe" \
  "SELECT count(*) FROM information_schema.tables WHERE table_schema='public' AND table_name='audit_event'" "1"
check "schema public: projection_outbox existe" \
  "SELECT count(*) FROM information_schema.tables WHERE table_schema='public' AND table_name='projection_outbox'" "1"
check "app_user existe" \
  "SELECT count(*) FROM pg_roles WHERE rolname='app_user'" "1"
check "app_user sin SUPERUSER/BYPASSRLS/CREATEROLE/CREATEDB" \
  "SELECT count(*) FROM pg_roles WHERE rolname='app_user' AND NOT rolsuper AND NOT rolbypassrls AND NOT rolcreaterole AND NOT rolcreatedb" "1"
check "app_user no es owner de tablas públicas" \
  "SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace JOIN pg_roles r ON r.oid=c.relowner WHERE n.nspname='public' AND c.relkind IN ('r','p') AND r.rolname='app_user'" "0"
check "app_user no puede borrar projection_outbox" \
  "SELECT has_table_privilege('app_user','public.projection_outbox','DELETE')::int" "0"
check "RLS activado en toda tabla operacional con tenant_id" \
  "SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relkind IN ('r','p') AND EXISTS (SELECT 1 FROM information_schema.columns col WHERE col.table_schema=n.nspname AND col.table_name=c.relname AND col.column_name='tenant_id') AND c.relname NOT LIKE 'flyway_%' AND NOT c.relrowsecurity" "0"
for version in 17 18 19 20 21; do
  check "Flyway V${version} registrada como exitosa" \
    "SELECT count(*) FROM public.flyway_schema_history WHERE version='${version}' AND success" "1"
done
check "Esquema camunda existe" \
  "SELECT count(*) FROM information_schema.schemata WHERE schema_name='camunda'" "1"
check "app_user no puede crear objetos en public" \
  "SELECT has_schema_privilege('app_user','public','CREATE')::int" "0"
check "app_user tiene USAGE en camunda" \
  "SELECT has_schema_privilege('app_user','camunda','USAGE')::int" "1"
check "RLS y FORCE RLS en payment_approval_decision" \
  "SELECT count(*) FROM pg_class c JOIN pg_namespace n ON n.oid=c.relnamespace WHERE n.nspname='public' AND c.relname='payment_approval_decision' AND c.relrowsecurity AND c.relforcerowsecurity" "1"
check "outbox_worker existe, LOGIN y sin SUPERUSER/BYPASSRLS" \
  "SELECT count(*) FROM pg_roles WHERE rolname='outbox_worker' AND rolcanlogin AND NOT rolsuper AND NOT rolbypassrls AND NOT rolcreaterole AND NOT rolcreatedb" "1"
check "Outbox global claim no concedido a app_user (least-privilege)" \
  "SELECT has_function_privilege('app_user','public.claim_projection_outbox(integer)','EXECUTE')::int" "0"
check "Outbox global claim concedido al worker dedicado" \
  "SELECT has_function_privilege('outbox_worker','public.claim_projection_outbox(integer)','EXECUTE')::int" "1"

for table in compliance_subcontractor_head invoice payment_application payment three_way_match_result safety_incident rfi change_order submittal permit_application bid_package bid contract; do
  check "tabla public.$table existe" \
    "SELECT count(*) FROM information_schema.tables WHERE table_schema='public' AND table_name='$table'" "1"
done

check "BPMN paymentApprovalProcess desplegado en camunda" \
  "SELECT count(*) FROM camunda.act_re_procdef WHERE key_='paymentApprovalProcess'" "1"
check "BPMN rfiProcess desplegado en camunda" \
  "SELECT count(*) FROM camunda.act_re_procdef WHERE key_='rfiProcess'" "1"
check "DMN complianceVigente desplegada en camunda" \
  "SELECT count(*) FROM camunda.act_re_decision_def WHERE key_='complianceVigente'" "1"
check "DMN nivelAprobacionPago desplegada en camunda" \
  "SELECT count(*) FROM camunda.act_re_decision_def WHERE key_='nivelAprobacionPago'" "1"

if (( fail )); then
  echo "RESULT: BLOCKED — uno o más gates de release fallaron."
  exit 1
fi
echo "RESULT: gates verificables de BD pasaron. Esto no sustituye build ni pruebas de integración."
