#!/usr/bin/env bash
# Verifica invariantes en una BD existente; sin conexión no afirma éxito.
set -euo pipefail

PGHOST="${PGHOST:-localhost}"
PGPORT="${PGPORT:-5432}"
PGUSER="${PGUSER:-postgres}"
PGDATABASE="${PGDATABASE:-construction}"
TENANT="${1:-}"
PSQL=(psql -X -v ON_ERROR_STOP=1 -h "$PGHOST" -p "$PGPORT" -U "$PGUSER" -d "$PGDATABASE" -t -A)

if ! command -v psql >/dev/null 2>&1; then
  echo "BLOCKED: psql no está instalado; invariantes NO verificados."
  exit 2
fi
if ! "${PSQL[@]}" -c 'SELECT 1' >/dev/null 2>&1; then
  echo "BLOCKED: no se pudo conectar a $PGHOST:$PGPORT/$PGDATABASE como $PGUSER."
  exit 2
fi
fail=0
check_zero() {
  local name="$1" query="$2" actual
  if actual=$("${PSQL[@]}" -c "$query" 2>/dev/null); then :; else actual="ERR"; fi
  actual="$(printf '%s' "$actual" | tr -d '[:space:]')"
  if [[ "$actual" == "0" ]]; then echo "PASS | $name"; else echo "FAIL | $name | esperado=0 obtenido=$actual"; fail=1; fi
}

echo "Invariantes DB=$PGDATABASE tenant=${TENANT:-no especificado}"
if [[ -n "$TENANT" ]]; then
  if ! [[ "$TENANT" =~ ^[0-9a-fA-F-]{36}$ ]]; then echo "Tenant UUID inválido"; exit 2; fi
  check_zero "audit_chain_broken tenant" "SELECT count(*) FROM public.verify_audit_chain('$TENANT')"
fi
check_zero "outbox dead-letter" "SELECT count(*) FROM public.projection_outbox WHERE status='DEAD_LETTERED'"
check_zero "recovery_account saldo negativo" "SELECT count(*) FROM public.recovery_account WHERE saldo_pendiente < 0"
check_zero "progress certificado bajo threshold" "SELECT count(*) FROM public.progress_observation WHERE status='CERTIFIED' AND progress_ratio_lower < contractual_threshold"
check_zero "incidente no-recordable sin justificación" "SELECT count(*) FROM public.safety_incident WHERE osha_recordability='NOT_RECORDABLE_WITH_JUSTIFICATION' AND osha_justification IS NULL"
check_zero "match incoherente" "SELECT count(*) FROM public.three_way_match_result WHERE estado='MATCH' AND jsonb_array_length(diferencias) > 0"
check_zero "payment marcados EXECUTED sin executed_at" "SELECT count(*) FROM public.payment WHERE status='EXECUTED' AND executed_at IS NULL"

if (( fail )); then echo "RESULT: invariantes fallaron o una consulta no pudo ejecutarse."; exit 1; fi
echo "RESULT: invariantes consultados pasaron; no demuestra aislamiento RLS ni comportamiento no cubierto."
