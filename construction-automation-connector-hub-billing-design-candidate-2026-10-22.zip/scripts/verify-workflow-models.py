#!/usr/bin/env python3
"""Static BPMN/DMN structural checks; this does not replace Camunda deployment tests."""
from pathlib import Path
import sys
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
checks = []
def check(name, ok, detail): checks.append((name, bool(ok), detail))
def parse(rel):
    try: return ET.parse(ROOT / rel).getroot()
    except Exception as exc:
        check(f"XML parse: {rel}", False, str(exc))
        return None

bpmn_path = "src/main/resources/bpmn/paymentApprovalProcess.bpmn"
dmn_path = "src/main/resources/dmn/nivelAprobacionPago.dmn"
bpmn = parse(bpmn_path)
dmn = parse(dmn_path)
if bpmn is not None:
    ns = {"b": "http://www.omg.org/spec/BPMN/20100524/MODEL"}
    ids = [el.attrib.get("id") for el in bpmn.iter() if el.attrib.get("id")]
    idset = set(ids)
    refs_ok = True
    missing = []
    for el in bpmn.iter():
        for attr in ("sourceRef", "targetRef", "attachedToRef", "processRef", "messageRef"):
            ref = el.attrib.get(attr)
            if ref and ref not in idset:
                refs_ok = False; missing.append(f"{el.tag}:{attr}={ref}")
    check("BPMN IDs unique", len(ids) == len(idset), "Los IDs del modelo deben ser únicos.")
    check("BPMN referencias resolubles", refs_ok, "; ".join(missing) or "Todas las referencias estáticas resuelven.")
    gateways = [el for el in bpmn.iter() if el.tag.endswith("exclusiveGateway")]
    match_gate = next((g for g in gateways if g.attrib.get("id") == "GW_Match"), None)
    check("Match gateway fail-closed", match_gate is not None and match_gate.attrib.get("default") == "F_Match_Fail",
          "Una salida ausente o no válida no debe alcanzar el registro de pago.")
    flows = [el for el in bpmn.iter() if el.tag.endswith("sequenceFlow")]
    success = next((f for f in flows if f.attrib.get("id") == "F_Match_OK"), None)
    condition = "".join(success.itertext()) if success is not None else ""
    check("Match requiere estado MATCH y matchId", "matchResult.estado == 'MATCH'" in condition and "matchResult.matchId != null" in condition,
          "Solo evidencia persistida explícita puede continuar.")
    camunda_ns = "{http://camunda.org/schema/1.0/bpmn}"
    decision_task = next((el for el in bpmn.iter() if el.attrib.get("id") == "Task_EvaluatePaymentApproval"), None)
    check("Payment BPMN invokes approval DMN", decision_task is not None
          and decision_task.tag.endswith("businessRuleTask")
          and decision_task.attrib.get(camunda_ns + "decisionRef") == "nivelAprobacionPago"
          and decision_task.attrib.get(camunda_ns + "resultVariable") == "approvalDecision",
          "La policy DMN debe ejecutarse y su salida debe quedar en una variable explícita.")
    approval_gateway = next((g for g in gateways if g.attrib.get("id") == "GW_ApprovalPolicy"), None)
    check("Approval gateway fails closed to manual review", approval_gateway is not None
          and approval_gateway.attrib.get("default") == "F_Approval_Manual",
          "La rama por defecto y cualquier salida no automática deben detener el pago.")
    approval_auto = next((f for f in flows if f.attrib.get("id") == "F_Approval_Auto"), None)
    auto_condition = "".join(approval_auto.itertext()) if approval_auto is not None else ""
    check("Only no-manual-review decision reaches approval-evidence delegate", approval_auto is not None
          and approval_auto.attrib.get("targetRef") == "Task_PersistPolicyApproval"
          and "approvalDecision.requiereRevisionManual == false" in auto_condition,
          "Solo la salida explícita de política automática puede persistirse como aprobación.")
    policy_persist_task = next((el for el in bpmn.iter() if el.attrib.get("id") == "Task_PersistPolicyApproval"), None)
    check("Durable policy approval precedes payment registration", policy_persist_task is not None
          and policy_persist_task.attrib.get("{http://camunda.org/schema/1.0/bpmn}delegateExpression") == "${persistAutomaticPaymentApprovalDelegate}"
          and any(f.attrib.get("id") == "F_Persist_Approval" and f.attrib.get("sourceRef") == "Task_PersistPolicyApproval" and f.attrib.get("targetRef") == "Task_RegistrarPago" for f in flows),
          "El resultado DMN debe tener evidencia durable antes del delegate que crea la instrucción.")
    approval_manual = next((f for f in flows if f.attrib.get("id") == "F_Approval_Manual"), None)
    check("Manual approval route cannot create payment", approval_manual is not None
          and approval_manual.attrib.get("targetRef") == "End_ApprovalRequired"
          and approval_manual.attrib.get("targetRef") != "Task_RegistrarPago",
          "Sin servicio autenticado de aprobación durable, la ruta manual termina sin pago.")
    flow_by_id = {f.attrib.get("id"): f for f in flows}
    register_task = next((el for el in bpmn.iter() if el.attrib.get("id") == "Task_RegistrarPago"), None)
    incoming_payment = [e.text for e in register_task.findall("b:incoming", ns)] if register_task is not None else []
    check("Payment registration only receives persisted-policy approval flow", incoming_payment == ["F_Persist_Approval"]
          and flow_by_id.get("F_Approval_Auto", ET.Element("dummy")).attrib.get("targetRef") == "Task_PersistPolicyApproval"
          and flow_by_id.get("F_Persist_Approval", ET.Element("dummy")).attrib.get("targetRef") == "Task_RegistrarPago",
          "No debe existir una conexión alternativa desde los gates de match/política al registro de pago.")
if dmn is not None:
    ns = {"d": "https://www.omg.org/spec/DMN/20191111/MODEL/"}
    rules = dmn.findall(".//d:rule", ns)
    check("DMN tiene reglas de aprobación", len(rules) >= 4, f"Reglas detectadas: {len(rules)}")
    check("DMN requires currency input and emits policy version",
          dmn.find(".//d:input[@id='input_moneda']", ns) is not None
          and dmn.find(".//d:output[@name='policyVersion']", ns) is not None,
          "Los umbrales son específicos de moneda y la evidencia conserva la versión exacta de política.")
    automatic = next((r for r in rules if r.attrib.get("id") == "rule_automatica"), None)
    automatic_inputs = automatic.findall("d:inputEntry/d:text", ns) if automatic is not None else []
    automatic_outputs = automatic.findall("d:outputEntry/d:text", ns) if automatic is not None else []
    check("Automatic rule only accepts MXN and policy version is explicit",
          len(automatic_inputs) == 2 and automatic_inputs[1].text.strip() == '"MXN"'
          and len(automatic_outputs) == 3 and automatic_outputs[2].text.strip() == '"nivelAprobacionPago-v2-MXN"',
          "No se da aprobación automática a otra moneda ni se deja la decisión sin versión.")
    gerente = next((r for r in rules if r.attrib.get("id") == "rule_gerente"), None)
    outputs = gerente.findall("d:outputEntry/d:text", ns) if gerente is not None else []
    manual_review = outputs[1] if len(outputs) > 1 else None
    check("Ruta GERENTE exige revisión manual", manual_review is not None and manual_review.text.strip() == "true",
          "La salida de la ruta GERENTE no puede declarar revisión manual falsa.")

errors = 0
for name, ok, detail in checks:
    print(f"{'PASS' if ok else 'FAIL'} | {name} | {detail}")
    errors += not ok
print(f"RESULT: {len(checks)-errors}/{len(checks)} workflow-model static checks passed")
print("LIMIT: XML structure only; Camunda runtime deployment and expression execution remain unverified.")
sys.exit(1 if errors else 0)
