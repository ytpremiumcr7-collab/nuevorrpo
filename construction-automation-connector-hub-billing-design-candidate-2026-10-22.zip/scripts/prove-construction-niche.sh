#!/usr/bin/env bash
# Prueba estructural: cada capacidad de las capturas (nicho construcción)
# debe existir en código con implementación no-stub.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
FAIL=0
pass() { echo "  ✅ $1"; }
fail() { echo "  ❌ $1"; FAIL=$((FAIL+1)); }

check_file() {
  local f="$1" msg="$2"
  if [[ -f "$ROOT/$f" ]]; then pass "$msg → $f"; else fail "$msg → FALTA $f"; fi
}
check_grep() {
  local pattern="$1" path="$2" msg="$3"
  if grep -Rql --include='*.java' --include='*.sql' --include='*.bpmn' --include='*.dmn' --include='*.html' --include='*.js' "$pattern" "$ROOT/$path" 2>/dev/null; then
    pass "$msg"
  else
    fail "$msg (no match: $pattern in $path)"
  fi
}

echo "=============================================="
echo "PRUEBA DE COBERTURA — Nicho construcción"
echo "=============================================="

echo ""
echo "1) Cumplimiento de subcontratistas (certificados, vencimientos, recordatorios)"
check_file "src/main/java/com/tuempresa/compliance/service/ComplianceService.java" "ComplianceService"
check_file "src/main/java/com/tuempresa/compliance/job/ComplianceExpirationSweepJob.java" "Sweep vencimientos 30d/7d/vencido"
check_grep "expiry_alert_level" "src" "Alertas de nivel de vencimiento"
check_grep "notification_outbox" "src/main" "Cola de notificaciones de renovación"
check_file "src/main/java/com/tuempresa/billing/delegate/ThreeWayMatchDelegate.java" "Three-way match (no pagar a ciegas)"
check_file "src/test/java/com/tuempresa/billing/VersionFencingTest.java" "Version fencing test"

echo ""
echo "2) Documentación de proyecto (RFI, CO, submittals, daily reports)"
check_file "src/main/java/com/tuempresa/documents/service/ProjectDocumentsService.java" "RFI + Change Orders"
check_file "src/main/java/com/tuempresa/documents/service/SubmittalService.java" "Submittals"
check_file "src/main/java/com/tuempresa/documents/service/DailyReportService.java" "Informes diarios"
check_grep "rfi_routing_policy" "src/main/resources/db" "Enrutamiento RFI determinista en BD"
check_file "src/main/resources/bpmn/rfiProcess.bpmn" "BPMN RFI"

echo ""
echo "3) Pagos / compensación / seguridad"
check_file "src/main/java/com/tuempresa/billing/service/PaymentApplicationService.java" "Payment application"
check_file "src/main/java/com/tuempresa/compensation/service/CompensationService.java" "Compensación + recovery_account"
check_file "src/main/java/com/tuempresa/safety/job/OshaDeadlineSweepJob.java" "OSHA deadlines"
check_file "src/main/resources/bpmn/paymentApprovalProcess.bpmn" "BPMN aprobación pago"

echo ""
echo "4) Identity por obra"
check_file "src/main/java/com/tuempresa/identity/security/AuthFilter.java" "AuthFilter"
check_grep "SAFETY_LEAD" "src/main" "Rol SAFETY_LEAD"
check_grep "PROJECT_ENGINEER" "src/main" "Rol PROJECT_ENGINEER"
check_grep "FINANCE" "src/main" "Rol FINANCE"
check_file "src/main/resources/db/migration/V16__identity_templates_integration.sql" "Migración identity"

echo ""
echo "5) Front operativo"
check_file "src/main/resources/static/index.html" "Shell front"
check_file "src/main/resources/static/js/ops-app.js" "App JS colas"
check_file "src/main/resources/static/js/api.js" "Cliente API"
check_grep "/api/ops" "src/main/resources/static" "Front consume /api/ops"

echo ""
echo "6) Integración Procore (puente, no rewrite)"
check_file "src/main/java/com/tuempresa/integration/procore/ProcoreClient.java" "Cliente HTTP Procore"
check_file "src/main/java/com/tuempresa/integration/procore/ProcoreBridgeService.java" "Bridge"
check_grep "DRY-RUN\|DRY_RUN\|dryRun\|isEnabled" "src/main/java/com/tuempresa/integration" "DRY-RUN explícito"

echo ""
echo "7) Plantillas documentales"
check_file "src/main/java/com/tuempresa/templates/DocumentTemplateService.java" "Assembler"
check_grep "Variable de plantilla requerida ausente" "src/main/java" "Fail-loud variables"

echo ""
echo "8) Anti-stub / anti-silencio"
if grep -Rql "NotImplementedException\|TODO implement\|pass\s*$" "$ROOT/src/main/java" 2>/dev/null; then
  fail "Hay stubs NotImplemented en main"
else
  pass "Sin NotImplementedException en main"
fi
check_file "src/main/java/com/tuempresa/platform/web/ApiExceptionHandler.java" "Errores estructurados"

echo ""
echo "9) Inventario"
echo "  Java:     $(find "$ROOT/src" -name '*.java' | wc -l)"
echo "  SQL:      $(find "$ROOT" -name '*.sql' | wc -l)"
echo "  BPMN/DMN: $(find "$ROOT" -name '*.bpmn' -o -name '*.dmn' | wc -l)"
echo "  Tests:    $(find "$ROOT/src/test" -name '*.java' | wc -l)"
echo "  Static:   $(find "$ROOT/src/main/resources/static" -type f | wc -l)"

echo ""
if [[ $FAIL -eq 0 ]]; then
  echo "RESULTADO: TODAS LAS PRUEBAS ESTRUCTURALES OK"
  exit 0
else
  echo "RESULTADO: $FAIL fallos"
  exit 1
fi
