# Operación end-to-end con curl

Todas las llamadas requieren `X-Tenant-Id`. El tenant default se siembra
en V1 con UUID `00000000-0000-0000-0000-000000000001`.

```bash
export BASE=http://localhost:8080
export TENANT=00000000-0000-0000-0000-000000000001
export H1="X-Tenant-Id: $TENANT"
export H2="Content-Type: application/json"
```

## 1. Setup mínimo (una vez)

```bash
PROJECT=$(uuidgen)
PARTY=$(uuidgen)
CONTRACT=$(uuidgen)

psql -h localhost -U postgres -d construction <<EOF
INSERT INTO project (tenant_id, project_id, name, timezone, status)
VALUES ('$TENANT', '$PROJECT', 'Piloto', 'America/Mexico_City', 'ACTIVE');

INSERT INTO party (tenant_id, party_id, legal_name)
VALUES ('$TENANT', '$PARTY', 'Subcontratista SA de CV');

INSERT INTO contract (tenant_id, contract_id, project_id, amount, currency,
                      contract_type, effective_from)
VALUES ('$TENANT', '$CONTRACT', '$PROJECT', 100000, 'USD', 'AIA_A201', CURRENT_DATE);
EOF
```

## 2. Alta y verificación de compliance

```bash
# Crear requisito (queda PENDIENTE)
REQ=$(curl -s -X POST $BASE/api/compliance/requirements           -H "$H1" -H "$H2"           -d "{\"subcontractorId\":\"$PARTY\",\"projectId\":\"$PROJECT\",\
       \"tipoRequisito\":\"SEGURO_RC\",\"fechaVencimiento\":\"2025-12-31\"}"           | jq -r .requisitoId)

# Verificar (SUBIR DOCUMENTO PRIMERO; aquí solo verificamos)
curl -s -X POST $BASE/api/compliance/requirements/$REQ/verify           -H "$H1" -H "$H2"           -d '{"documentoId":"00000000-0000-0000-0000-000000000099"}'

# Verificar head VIGENTE
psql -h localhost -U postgres -d construction -c           "SELECT estado_global, version_actual FROM compliance_subcontractor_head \
   WHERE subcontractor_id = '$PARTY';"
```

## 3. PO + recepción + factura

```bash
psql -h localhost -U postgres -d construction <<EOF
INSERT INTO purchase_order (tenant_id, po_id, project_id, po_number, status)
VALUES ('$TENANT', gen_random_uuid(), '$PROJECT', 'PO-1', 'OPEN');

INSERT INTO purchase_order_line (tenant_id, po_line_id, po_id, line_number,
                                 description, quantity, unit_price)
VALUES ('$TENANT', gen_random_uuid(),
        (SELECT po_id FROM purchase_order WHERE po_number='PO-1' AND tenant_id='$TENANT'),
        1, 'Item', 10, 100);

INSERT INTO goods_receipt (tenant_id, receipt_id, po_id, received_at, received_by)
VALUES ('$TENANT', gen_random_uuid(),
        (SELECT po_id FROM purchase_order WHERE po_number='PO-1' AND tenant_id='$TENANT'),
        now(), '$PARTY');

INSERT INTO goods_receipt_line (tenant_id, receipt_line_id, receipt_id, po_line_id, quantity_received)
VALUES ('$TENANT', gen_random_uuid(),
        (SELECT receipt_id FROM goods_receipt WHERE tenant_id='$TENANT' LIMIT 1),
        (SELECT po_line_id FROM purchase_order_line WHERE tenant_id='$TENANT' LIMIT 1),
        10);

INSERT INTO invoice (tenant_id, invoice_id, project_id, contract_id, subcontractor_id,
                     invoice_number, amount, currency, invoice_date, received_at, status, po_reference)
VALUES ('$TENANT', gen_random_uuid(), '$PROJECT', '$CONTRACT', '$PARTY',
        'INV-1', 1000, 'USD', CURRENT_DATE, now(), 'RECEIVED', 'PO-1');

INSERT INTO invoice_line (tenant_id, invoice_line_id, invoice_id, line_number,
                          description, quantity, unit_price)
VALUES ('$TENANT', gen_random_uuid(),
        (SELECT invoice_id FROM invoice WHERE invoice_number='INV-1' AND tenant_id='$TENANT'),
        1, 'Item', 10, 100);
EOF
```

## 4. Someter pago -> proceso BPMN

```bash
INVOICE=$(psql -h localhost -U postgres -d construction -t -A -c           "SELECT invoice_id FROM invoice WHERE invoice_number='INV-1' AND tenant_id='$TENANT'")

curl -s -X POST $BASE/api/payments/applications           -H "$H1" -H "$H2"           -d "{\"invoiceId\":\"$INVOICE\",\"subcontractorId\":\"$PARTY\",\
       \"projectId\":\"$PROJECT\",\"monto\":1000,\"contractId\":\"$CONTRACT\"}"           | jq
```

Respuesta: `{"processInstanceId": "..."}`. El proceso `paymentApprovalProcess`
corre en Camunda (`http://localhost:8080/camunda/`).

## 5. Revocación en vuelo (bloqueo estructural)

Repite los pasos 2 y 4 para tener una factura en vuelo, luego:

```bash
curl -s -X POST $BASE/api/compliance/requirements/$REQ/revoke           -H "$H1" -H "$H2"           -d '{"motivo":"Incumplimiento OSHA 1926.501","effectiveDate":"2025-01-15"}'
```

La revocación correlaciona `ComplianceRevokedMessage` a cualquier instancia
activa. El `boundaryEvent` cancela el subproceso. El pago NO se ejecuta.

## 6. Invalidación + compensación

```bash
PAYMENT=$(psql -h localhost -U postgres -d construction -t -A -c           "SELECT payment_id FROM payment WHERE invoice_id='$INVOICE'")

curl -s -X POST $BASE/api/payments/$PAYMENT/invalidate           -H "$H1" -H "$H2"           -d "{\"invalidityType\":\"CERTIFICADO_VENCIDO_RETROACTIVO\",\
       \"evidenceId\":\"$(uuidgen)\",\"amount\":1000,\
       \"contractualBasis\":\"Cláusula 15.2\",\
       \"effectiveDate\":\"2024-12-01\",\
       \"detectedBy\":\"$PARTY\"}"
```

Cadena de eventos:
1. `payment_invalidation` insertada
2. `PaymentInvalidatedEvent` publicado
3. `PaymentInvalidatedEventHandler.on()` -> `CompensationService.open()`
4. `compensation_case` creada (si no existía)
5. `CompensationCaseCreatedEvent` publicado
6. `CompensationCaseCreatedHandler.on()` -> message correlation BPMN
7. `compensationCaseProcess` arranca, aplica deducción, marca `RECOVERED`

## 7. Health y verificación de invariantes

```bash
# Estado del sistema
curl -s $BASE/actuator/health | jq

# Métricas clave
curl -s $BASE/actuator/metrics/billing.payments.executed | jq
curl -s $BASE/actuator/metrics/outbox_dlq_count | jq

# Invariantes en BD
psql -h localhost -U postgres -d construction <<'EOF'
-- Cadena de auditoría no rota
SELECT count(*) AS broken FROM (
  SELECT a.sequence_number FROM audit_event a
    LEFT JOIN audit_event prev ON prev.tenant_id = a.tenant_id
         AND prev.sequence_number = a.sequence_number - 1
   WHERE a.prev_hash IS DISTINCT FROM coalesce(prev.event_hash, '')
) x;

-- Sin outbox DLQ
SELECT count(*) FROM projection_outbox WHERE status = 'DEAD_LETTERED';

-- Sin recovery_account negativo (constraint CHECK ya lo impide)
SELECT count(*) FROM recovery_account WHERE saldo_pendiente < 0;

-- Sin progress CERTIFIED bajo threshold
SELECT count(*) FROM progress_observation
  WHERE status = 'CERTIFIED' AND progress_ratio_lower < contractual_threshold;
EOF
```

## 8. Órdenes de fallo esperados (fail-loud)

| Acción | Fallo esperado |
|--------|----------------|
| `POST /api/payments/applications` con `subcontractorId` sin compliance head | `500 IllegalStateException: Sin proyección de compliance` |
| `POST /api/bids/packages/{id}/award` sin `justification` | `400 IllegalArgumentException: Adjudicación sin justificación` |
| `POST /api/permits` con jurisdicción sin config | `500 IllegalStateException: Sin configuración de plazo` |
| `POST /api/safety/incidents` con `occurredAt` futuro | `400 IllegalArgumentException: occurredAt no puede ser futuro` |
| Cualquier request sin `X-Tenant-Id` | `400 Falta header X-Tenant-Id` |
| Cualquier request con `X-Tenant-Id` que no es UUID | `400 X-Tenant-Id no es UUID` |

Esto es el contrato de operación. Si algo falla silencioso, es un bug.

## Revisión de hardening (candidata, no certificación)

Antes de cambios de código ejecuta:

```bash
python scripts/verify-hardening-static.py
bash scripts/prove-construction-niche.sh
bash scripts/verify-invariants.sh <tenant-uuid>
bash scripts/verify-gates.sh
```

Los dos primeros comandos son verificaciones estáticas/estructurales. Los dos últimos requieren `psql`, conexión a la base correcta y credenciales con permisos suficientes; sin conexión no hay prueba de RLS, invariantes ni despliegue BPMN. Para levantar cualquier ambiente real se necesita `mvn clean verify` y las pruebas de PostgreSQL/Testcontainers. Consultar `HARDENING_NOTES.md` y no aprobar GO-LIVE mientras existan los bloqueadores P0/P1 ahí descritos.
