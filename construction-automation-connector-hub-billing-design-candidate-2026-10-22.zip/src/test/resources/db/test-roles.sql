-- Test-only login roles exist before Spring creates its application/worker pools.
CREATE ROLE app_user LOGIN PASSWORD 'app_user_test'
  NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
CREATE ROLE outbox_worker LOGIN PASSWORD 'outbox_worker_test'
  NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
