package com.tuempresa.platform;

import com.tuempresa.testsupport.PostgresTestBase;
import com.tuempresa.testsupport.SeedHelpers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.math.BigDecimal;
import java.util.UUID;
import java.util.function.Supplier;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Verifica que RLS aplica cuando la sesión es app_user
 * (NOSUPERUSER NOBYPASSRLS). Como postgres bypassea RLS,
 * forzamos el rol dentro de una transacción.
 *
 * Sin esto, la promesa de multi-tenancy no es ejecutable.
 */
class RlsIsolationTest extends PostgresTestBase {

    @Autowired @Qualifier("testAdminJdbcTemplate") JdbcTemplate jdbc;

    private TransactionTemplate tx;

    @org.junit.jupiter.api.BeforeEach
    void setup(@Autowired PlatformTransactionManager txManager) {
        tx = new TransactionTemplate(txManager);
    }

    @Test
    void tenant_a_cannot_see_tenant_b_projects() {
        UUID tenantA = SeedHelpers.seedTenant(jdbc);
        UUID tenantB = SeedHelpers.seedTenant(jdbc);
        SeedHelpers.seedProject(jdbc, tenantA);
        SeedHelpers.seedProject(jdbc, tenantB);
        SeedHelpers.seedProject(jdbc, tenantB);  // 2 proyectos en B

        Long countA = queryAsTenant(tenantA, () ->
            jdbc.queryForObject("SELECT count(*) FROM project", Long.class));
        Long countB = queryAsTenant(tenantB, () ->
            jdbc.queryForObject("SELECT count(*) FROM project", Long.class));

        assertThat(countA).as("tenantA solo ve sus proyectos").isEqualTo(1);
        assertThat(countB).as("tenantB ve 2 proyectos").isEqualTo(2);
    }

    @Test
    void approval_evidence_is_isolated_by_tenant_and_hidden_without_context() {
        UUID tenantA = SeedHelpers.seedTenant(jdbc);
        UUID tenantB = SeedHelpers.seedTenant(jdbc);
        seedPolicyApproval(tenantA);
        seedPolicyApproval(tenantB);

        Long visibleA = queryAsTenant(tenantA, () ->
            jdbc.queryForObject("SELECT count(*) FROM payment_approval_decision", Long.class));
        Long visibleB = queryAsTenant(tenantB, () ->
            jdbc.queryForObject("SELECT count(*) FROM payment_approval_decision", Long.class));
        Long visibleWithoutTenant = tx.execute(status -> {
            jdbc.execute("SET LOCAL ROLE app_user");
            return jdbc.queryForObject("SELECT count(*) FROM payment_approval_decision", Long.class);
        });

        assertThat(visibleA).as("tenant A only sees its approval evidence").isEqualTo(1L);
        assertThat(visibleB).as("tenant B only sees its approval evidence").isEqualTo(1L);
        assertThat(visibleWithoutTenant).as("missing tenant context sees no approval evidence").isZero();
    }

    private void seedPolicyApproval(UUID tenant) {
        UUID project = SeedHelpers.seedProject(jdbc, tenant);
        UUID party = SeedHelpers.seedParty(jdbc, tenant);
        UUID contract = SeedHelpers.seedContract(jdbc, tenant, project);
        UUID invoice = SeedHelpers.seedInvoiceWithPoAndReceipt(
            jdbc, tenant, project, party, contract, new BigDecimal("250.00"));
        UUID application = UUID.randomUUID();
        jdbc.update("INSERT INTO payment_application " +
            "(tenant_id, payment_application_id, invoice_id, project_id, contract_id, subcontractor_id, " +
            "amount_requested, amount_approved, status, approval_route, approval_policy_version) " +
            "VALUES (?, ?, ?, ?, ?, ?, 250.00, 250.00, 'APPROVED', 'AUTOMATICA', 'test-policy-v1')",
            tenant, application, invoice, project, contract, party);
        jdbc.update("INSERT INTO payment_approval_decision " +
            "(tenant_id, approval_id, payment_application_id, project_id, approval_route, decision_source, " +
            "decision, approved_amount, policy_version, decision_reason) " +
            "VALUES (?, ?, ?, ?, 'AUTOMATICA', 'POLICY', 'APPROVED', 250.00, 'test-policy-v1', 'RLS test decision')",
            tenant, UUID.randomUUID(), application, project);
    }

    @Test
    void unknown_tenant_sees_nothing() {
        UUID tenant = SeedHelpers.seedTenant(jdbc);
        SeedHelpers.seedProject(jdbc, tenant);

        UUID randomTenant = UUID.randomUUID();
        Long count = queryAsTenant(randomTenant, () ->
            jdbc.queryForObject("SELECT count(*) FROM project", Long.class));
        assertThat(count).isZero();
    }

    private <T> T queryAsTenant(UUID tenant, Supplier<T> query) {
        return tx.execute(status -> {
            jdbc.execute("SET LOCAL ROLE app_user");
            jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
            return query.get();
        });
    }
}
