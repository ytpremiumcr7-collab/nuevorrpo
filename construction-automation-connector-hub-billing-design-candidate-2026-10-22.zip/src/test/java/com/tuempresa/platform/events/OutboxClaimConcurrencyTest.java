package com.tuempresa.platform.events;

import com.tuempresa.testsupport.PostgresTestBase;
import com.tuempresa.testsupport.SeedHelpers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.*;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Propiedad crítica: dos pollers concurrentes nunca reclaman la misma
 * fila. Si dos reclaman, el mismo evento se procesa dos veces y las
 * proyecciones duplican (o peor: dos payments).
 *
 * Test directo sobre el SQL de claim (SKIP LOCKED).
 */
class OutboxClaimConcurrencyTest extends PostgresTestBase {

    @Autowired @Qualifier("testAdminJdbcTemplate") JdbcTemplate jdbc;

    @Test
    void two_claimers_never_get_same_row() throws Exception {
        UUID tenant = SeedHelpers.seedTenant(jdbc);
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        int total = 100;
        for (int i = 0; i < total; i++) {
            jdbc.update(
                "INSERT INTO projection_outbox (tenant_id, event_id, aggregate_type, " +
                "aggregate_id, aggregate_version, event_type, payload) " +
                "VALUES (?, ?, 'Test', ?, 1, 'TestEvent', '{}'::jsonb)",
                tenant, UUID.randomUUID(), UUID.randomUUID());
        }

        // Dos claimers en paralelo, cada uno reclama 100 filas
        ExecutorService pool = Executors.newFixedThreadPool(2);
        CountDownLatch start = new CountDownLatch(1);
        Set<UUID> claimedByA = ConcurrentHashMap.newKeySet();
        Set<UUID> claimedByB = ConcurrentHashMap.newKeySet();

        Future<?> a = pool.submit(() -> claimAll(tenant, claimedByA, start));
        Future<?> b = pool.submit(() -> claimAll(tenant, claimedByB, start));
        start.countDown();
        a.get(20, TimeUnit.SECONDS);
        b.get(20, TimeUnit.SECONDS);
        pool.shutdown();

        // Intersección debe ser vacía
        Set<UUID> intersection = new HashSet<>(claimedByA);
        intersection.retainAll(claimedByB);
        assertThat(intersection)
            .as("Ninguna fila debe ser reclamada por ambos pollers")
            .isEmpty();

        // Unión debe ser exactamente las 100
        Set<UUID> union = new HashSet<>(claimedByA);
        union.addAll(claimedByB);
        assertThat(union).hasSize(total);
    }

    private void claimAll(UUID tenant, Set<UUID> claimed, CountDownLatch start) {
        try {
            start.await();
        } catch (InterruptedException e) { return; }

        while (true) {
            jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
            List<UUID> ids = jdbc.query(
                "UPDATE projection_outbox SET status = 'PROCESSING', " +
                "next_retry_at = now() + interval '5 minutes' " +
                "WHERE id IN ( " +
                "  SELECT id FROM projection_outbox " +
                "   WHERE status = 'PENDING' AND next_retry_at <= now() " +
                "   ORDER BY next_retry_at LIMIT 20 FOR UPDATE SKIP LOCKED " +
                ") RETURNING id",
                (rs, i) -> rs.getObject("id", UUID.class));

            if (ids.isEmpty()) return;
            claimed.addAll(ids);
        }
    }
}
