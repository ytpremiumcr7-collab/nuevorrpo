package com.tuempresa.dispute;

import com.tuempresa.testsupport.PostgresTestBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Qualifier;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Propiedad que no puede fallar: si se agrega un festivo antes del plazo
 * de respuesta de una disputa abierta, el job diario DEBE extender el
 * plazo en 1 día hábil. Con timers BPMN esto hubiera sido imposible.
 *
 * (El job corre a las 6am; en el test invocamos add_business_days
 * directamente para verificar la semántica determinista.)
 */
class DisputeCalendarChangeTest extends PostgresTestBase {

    @Autowired @Qualifier("testAdminJdbcTemplate") JdbcTemplate jdbc;

    @Test
    void holiday_added_to_calendar_extends_business_days_deadline() {
        // Marcar el 2025-04-17 como festivo (Jueves Santo, ejemplar)
        jdbc.update(
            "INSERT INTO business_calendar " +
            "(jurisdiction_id, calendar_date, is_business_day, holiday_name, source) " +
            "VALUES ('MX_CDMX', '2025-04-17', false, 'Jueves Santo', 'DOF 2025') " +
            "ON CONFLICT (jurisdiction_id, calendar_date) " +
            "DO UPDATE SET is_business_day = false, holiday_name = 'Jueves Santo'");

        LocalDate deadline = jdbc.queryForObject(
            "SELECT add_business_days('MX_CDMX', '2025-04-14'::date, 3)",
            LocalDate.class);

        // 3 días hábiles desde lunes 14, con jueves 17 festivo:
        // mar 15 (1), mié 16 (2), jue 17 festivo, vie 18 (3) => 2025-04-18
        assertThat(deadline).isEqualTo(LocalDate.of(2025, 4, 18));
    }

    @Test
    void adding_holiday_shifts_deadline_forward() {
        // Antes de marcar el festivo
        jdbc.update("UPDATE business_calendar SET is_business_day = true, holiday_name = NULL " +
            "WHERE jurisdiction_id = 'MX_CDMX' AND calendar_date = '2025-04-17'");
        LocalDate before = jdbc.queryForObject(
            "SELECT add_business_days('MX_CDMX', '2025-04-14'::date, 3)", LocalDate.class);

        // Marcar el festivo
        jdbc.update("UPDATE business_calendar SET is_business_day = false, " +
            "holiday_name = 'Festivo nuevo' " +
            "WHERE jurisdiction_id = 'MX_CDMX' AND calendar_date = '2025-04-17'");
        LocalDate after = jdbc.queryForObject(
            "SELECT add_business_days('MX_CDMX', '2025-04-14'::date, 3)", LocalDate.class);

        assertThat(after).isAfter(before);
        assertThat(after).isEqualTo(before.plusDays(1));
    }
}
