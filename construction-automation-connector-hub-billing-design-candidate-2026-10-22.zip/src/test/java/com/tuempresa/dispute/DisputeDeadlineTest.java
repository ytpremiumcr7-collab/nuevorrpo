package com.tuempresa.dispute;

import com.tuempresa.testsupport.PostgresTestBase;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Qualifier;

import java.time.LocalDate;

import static org.assertj.core.api.Assertions.assertThat;

class DisputeDeadlineTest extends PostgresTestBase {

    @Autowired @Qualifier("testAdminJdbcTemplate") JdbcTemplate jdbc;

    @Test
    void fidic_uses_calendar_days() {
        String timeUnit = jdbc.queryForObject(
            "SELECT time_unit FROM dispute_phase_config " +
            "WHERE contract_type = 'FIDIC_RED_2017' AND phase = 'NOTICE' " +
            "AND jurisdiction = '*'", String.class);
        assertThat(timeUnit).isEqualTo("CALENDAR_DAYS");
    }

    @Test
    void business_calendar_holiday_extends_deadline() {
        // Semana Santa 2025 (MX_CDMX): 2025-04-17 Jueves Santo, 2025-04-18 Viernes Santo
        jdbc.update("UPDATE business_calendar SET is_business_day = false, " +
            "holiday_name = 'Jueves Santo' " +
            "WHERE jurisdiction_id = 'MX_CDMX' AND calendar_date = '2025-04-17'");
        jdbc.update("UPDATE business_calendar SET is_business_day = false, " +
            "holiday_name = 'Viernes Santo' " +
            "WHERE jurisdiction_id = 'MX_CDMX' AND calendar_date = '2025-04-18'");

        LocalDate deadline = jdbc.queryForObject(
            "SELECT add_business_days('MX_CDMX', '2025-04-14'::date, 5)",
            LocalDate.class);

        // 5 días hábiles desde lunes 14 con Jueves y Viernes Santo no hábiles:
        // lun 14, mar 15, mié 16, (jue 17 festivo), (vie 18 festivo),
        // lun 21 (3), mar 22 (4), mié 23 (5) => 2025-04-23
        assertThat(deadline).isEqualTo(LocalDate.of(2025, 4, 23));
    }
}
