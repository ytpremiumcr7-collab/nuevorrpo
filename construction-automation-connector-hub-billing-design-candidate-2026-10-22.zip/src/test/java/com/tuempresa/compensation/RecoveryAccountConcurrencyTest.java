package com.tuempresa.compensation;

import com.tuempresa.testsupport.PostgresTestBase;
import com.tuempresa.testsupport.SeedHelpers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Qualifier;

import java.math.BigDecimal;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

class RecoveryAccountConcurrencyTest extends PostgresTestBase {

    @Autowired @Qualifier("testAdminJdbcTemplate") JdbcTemplate jdbc;

    @Test
    void two_concurrent_deductions_only_one_wins() throws Exception {
        UUID tenant = SeedHelpers.seedTenant(jdbc);
        UUID project = SeedHelpers.seedProject(jdbc, tenant);
        UUID sub = SeedHelpers.seedParty(jdbc, tenant);

        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        jdbc.update("INSERT INTO recovery_account " +
            "(tenant_id, subcontractor_id, project_id, saldo_pendiente, version) " +
            "VALUES (?, ?, ?, 100, 0)", tenant, sub, project);

        int threads = 8;
        CountDownLatch start = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(threads);
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        AtomicInteger successes = new AtomicInteger();
        AtomicInteger failures = new AtomicInteger();

        for (int i = 0; i < threads; i++) {
            pool.submit(() -> {
                try {
                    start.await();
                    int updated = jdbc.update(
                        "UPDATE recovery_account " +
                        "SET saldo_pendiente = saldo_pendiente - 60, version = version + 1 " +
                        "WHERE tenant_id = ? AND subcontractor_id = ? AND project_id = ? " +
                        "AND version = 0 AND saldo_pendiente >= 60",
                        tenant, sub, project);
                    if (updated == 1) successes.incrementAndGet();
                    else failures.incrementAndGet();
                } catch (Exception e) {
                    failures.incrementAndGet();
                } finally {
                    done.countDown();
                }
            });
        }
        start.countDown();
        done.await(10, TimeUnit.SECONDS);
        pool.shutdown();

        // Solo un thread puede haber ganado el UPDATE con version=0
        assertThat(successes.get()).isEqualTo(1);
        assertThat(failures.get()).isEqualTo(threads - 1);

        // Saldo final = 100 - 60 = 40, no negativo
        BigDecimal saldo = jdbc.queryForObject(
            "SELECT saldo_pendiente FROM recovery_account " +
            "WHERE tenant_id = ? AND subcontractor_id = ? AND project_id = ?",
            BigDecimal.class, tenant, sub, project);
        assertThat(saldo).isEqualByComparingTo(new BigDecimal("40"));
    }
}
