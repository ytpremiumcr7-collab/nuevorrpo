package com.tuempresa.testsupport;

import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.DynamicPropertyRegistry;
import org.springframework.test.context.DynamicPropertySource;
import org.testcontainers.containers.PostgreSQLContainer;
import org.testcontainers.junit.jupiter.Container;
import org.testcontainers.junit.jupiter.Testcontainers;

@Testcontainers
@ActiveProfiles("test")
@Import(TestAdminJdbcConfiguration.class)
@SpringBootTest
public abstract class PostgresTestBase {

    @Container
    static final PostgreSQLContainer<?> PG = new PostgreSQLContainer<>("postgres:16-alpine")
        .withDatabaseName("construction")
        .withUsername("postgres")
        .withPassword("postgres")
        .withInitScript("db/test-roles.sql");

    @DynamicPropertySource
    static void props(DynamicPropertyRegistry r) {
        r.add("spring.datasource.url", PG::getJdbcUrl);
        r.add("spring.datasource.username", () -> "app_user");
        r.add("spring.datasource.password", () -> "app_user_test");
        r.add("test.admin.jdbc-url", PG::getJdbcUrl);
        r.add("test.admin.username", PG::getUsername);
        r.add("test.admin.password", PG::getPassword);
        r.add("spring.flyway.url", PG::getJdbcUrl);
        r.add("spring.flyway.user", PG::getUsername);
        r.add("spring.flyway.password", PG::getPassword);
        r.add("construction.outbox.worker.enabled", () -> "true");
        r.add("construction.outbox.datasource.url", PG::getJdbcUrl);
        r.add("construction.outbox.datasource.username", () -> "outbox_worker");
        r.add("construction.outbox.datasource.password", () -> "outbox_worker_test");
    }
}
