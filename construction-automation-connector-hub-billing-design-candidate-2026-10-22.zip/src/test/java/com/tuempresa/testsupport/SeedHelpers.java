package com.tuempresa.testsupport;

import org.springframework.jdbc.core.JdbcTemplate;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;

public final class SeedHelpers {

    public static UUID seedTenant(JdbcTemplate jdbc) {
        UUID t = UUID.randomUUID();
        jdbc.update("INSERT INTO tenant (tenant_id, name, active) VALUES (?, 'test', true)", t);
        return t;
    }

    public static UUID seedProject(JdbcTemplate jdbc, UUID tenant) {
        UUID p = UUID.randomUUID();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        jdbc.update("INSERT INTO project (tenant_id, project_id, name, timezone, status) " +
            "VALUES (?, ?, 'P', 'America/Mexico_City', 'ACTIVE')", tenant, p);
        return p;
    }

    public static UUID seedParty(JdbcTemplate jdbc, UUID tenant) {
        UUID s = UUID.randomUUID();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        jdbc.update("INSERT INTO party (tenant_id, party_id, legal_name) " +
            "VALUES (?, ?, 'Sub')", tenant, s);
        return s;
    }

    public static UUID seedContract(JdbcTemplate jdbc, UUID tenant, UUID project) {
        UUID c = UUID.randomUUID();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        jdbc.update("INSERT INTO contract (tenant_id, contract_id, project_id, amount, " +
            "currency, contract_type, effective_from) " +
            "VALUES (?, ?, ?, 100000, 'MXN', 'AIA_A201', CURRENT_DATE)", tenant, c, project);
        return c;
    }

    public static UUID seedInvoiceWithPoAndReceipt(
        JdbcTemplate jdbc, UUID tenant, UUID project, UUID sub, UUID contract,
        BigDecimal amount) {
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        BigDecimal quantity = new BigDecimal("10.0000");
        BigDecimal unitPrice = amount.divide(quantity, 4, RoundingMode.UNNECESSARY);
        UUID po = UUID.randomUUID();
        jdbc.update("INSERT INTO purchase_order (tenant_id, po_id, project_id, po_number, status) " +
            "VALUES (?, ?, ?, 'PO-1', 'OPEN')", tenant, po, project);

        UUID poLine = UUID.randomUUID();
        jdbc.update("INSERT INTO purchase_order_line " +
            "(tenant_id, po_line_id, po_id, line_number, description, quantity, unit_price) " +
            "VALUES (?, ?, ?, 1, 'Item', ?, ?)", tenant, poLine, po, quantity, unitPrice);

        UUID receipt = UUID.randomUUID();
        jdbc.update("INSERT INTO goods_receipt (tenant_id, receipt_id, po_id, received_at, received_by) " +
            "VALUES (?, ?, ?, now(), ?)", tenant, receipt, po, sub);

        jdbc.update("INSERT INTO goods_receipt_line " +
            "(tenant_id, receipt_line_id, receipt_id, po_line_id, quantity_received) " +
            "VALUES (?, ?, ?, ?, 10)", tenant, UUID.randomUUID(), receipt, poLine);

        UUID invoice = UUID.randomUUID();
        jdbc.update("INSERT INTO invoice " +
            "(tenant_id, invoice_id, project_id, contract_id, subcontractor_id, " +
            " invoice_number, amount, currency, invoice_date, received_at, status, po_reference) " +
            "VALUES (?, ?, ?, ?, ?, 'INV-1', ?, 'MXN', CURRENT_DATE, now(), 'RECEIVED', 'PO-1')",
            tenant, invoice, project, contract, sub, amount);

        jdbc.update("INSERT INTO invoice_line " +
            "(tenant_id, invoice_line_id, invoice_id, line_number, description, quantity, unit_price) " +
            "VALUES (?, ?, ?, 1, 'Item', ?, ?)", tenant, UUID.randomUUID(), invoice, quantity, unitPrice);

        return invoice;
    }

    public static UUID seedComplianceHead(JdbcTemplate jdbc, UUID tenant, UUID sub,
                                            UUID project, String estadoGlobal, long version) {
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        UUID reqId = UUID.randomUUID();
        jdbc.update("INSERT INTO compliance_subcontractor_head " +
            "(tenant_id, subcontractor_id, project_id, estado_global, version_actual, " +
            " requisito_critico_id, requisito_critico_tipo, requisito_critico_estado, " +
            " requisito_critico_vencimiento, requisitos_total, requisitos_vigentes, " +
            " requisitos_bloqueados, ultimo_evento_id) " +
            "VALUES (?, ?, ?, ?::compliance_estado_global, ?, ?, 'SEGURO_RC', " +
            "  'VERIFICADO'::compliance_estado, CURRENT_DATE + 30, 1, 1, 0, ?)",
            tenant, sub, project, estadoGlobal, version, reqId, UUID.randomUUID());
        return reqId;
    }
}
