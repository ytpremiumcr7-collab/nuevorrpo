package com.tuempresa.testsupport;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DriverManagerDataSource;

import javax.sql.DataSource;

/** Administrative connection reserved for fixtures and schema/RLS test setup only. */
@TestConfiguration(proxyBeanMethods = false)
public class TestAdminJdbcConfiguration {
    @Bean(name = "testAdminDataSource")
    DataSource testAdminDataSource(
            @Value("${test.admin.jdbc-url}") String url,
            @Value("${test.admin.username}") String username,
            @Value("${test.admin.password}") String password) {
        DriverManagerDataSource ds = new DriverManagerDataSource();
        ds.setUrl(url);
        ds.setUsername(username);
        ds.setPassword(password);
        ds.setDriverClassName("org.postgresql.Driver");
        return ds;
    }

    @Bean(name = "testAdminJdbcTemplate")
    JdbcTemplate testAdminJdbcTemplate(@Qualifier("testAdminDataSource") DataSource testAdminDataSource) {
        return new JdbcTemplate(testAdminDataSource);
    }
}
