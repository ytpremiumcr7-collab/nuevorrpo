package com.tuempresa.billing;

import com.tuempresa.testsupport.PostgresTestBase;
import com.tuempresa.testsupport.SeedHelpers;
import org.junit.jupiter.api.Test;
import org.camunda.bpm.engine.HistoryService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.history.HistoricProcessInstance;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Qualifier;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.doAnswer;

/**
 * Los 4 tests que sostienen la promesa central del sistema:
 * un pago no se ejecuta con compliance obsoleto.
 *
 * Cada test falla por UNA razón específica.
 */
class VersionFencingTest extends PostgresTestBase {

    @Autowired @Qualifier("testAdminJdbcTemplate") JdbcTemplate jdbc;
    @Autowired RuntimeService runtimeService;
    @Autowired HistoryService historyService;

    @SpyBean com.tuempresa.compliance.delegate.VerificarComplianceDelegate complianceDelegate;

    // -----------------------------------------------------------------
    // Test 1: revocación ANTES de la evaluación -> gate de compliance bloquea
    // -----------------------------------------------------------------
    @Test
    void revocation_before_evaluation_blocks_at_compliance_gate() throws Exception {
        var ctx = seedFullPaymentContext("VIGENTE", 1L);

        // Revocar ANTES de arrancar el proceso
        jdbc.execute("SET LOCAL app.tenant_id = '" + ctx.tenant + "'");
        jdbc.update(
            "UPDATE compliance_subcontractor_head SET estado_global = 'BLOQUEADO', " +
            "requisito_critico_estado = 'REVOCADO', version_actual = 2 " +
            "WHERE tenant_id = ? AND subcontractor_id = ? AND project_id = ?",
            ctx.tenant, ctx.sub, ctx.project);

        startPaymentProcess(ctx);
        HistoricProcessInstance hi = awaitEnd(ctx.invoice.toString(), Duration.ofSeconds(20));

        // El flujo termina en el end event explícito del gate de compliance.
        assertThat(hi.getEndActivityId()).isIn(
            "End_ComplianceBlocked", "Task_ResolveComp", "End_Blocked_Ext");

        // No se generó instrucción de pago
        Long payments = jdbc.queryForObject(
            "SELECT count(*) FROM payment WHERE tenant_id = ? AND invoice_id = ?",
            Long.class, ctx.tenant, ctx.invoice);
        assertThat(payments).isZero();
    }

    // -----------------------------------------------------------------
    // Test 2: revocación EN VUELO durante el delegate -> boundary cancela
    // -----------------------------------------------------------------
    @Test
    void revocation_racing_with_delegate_read_never_pays() throws Exception {
        var ctx = seedFullPaymentContext("VIGENTE", 1L);
        CountDownLatch delegateRead = new CountDownLatch(1);
        CountDownLatch allowReturn = new CountDownLatch(1);

        // Pausa el delegate JUSTO después de que lee la cabeza
        doAnswer(inv -> {
            inv.callRealMethod();
            delegateRead.countDown();
            allowReturn.await(15, TimeUnit.SECONDS);
            return null;
        }).when(complianceDelegate).execute(any());

        startPaymentProcess(ctx);
        assertThat(delegateRead.await(20, TimeUnit.SECONDS))
            .as("El delegate de compliance no fue invocado").isTrue();

        // Correlacionar revocación mientras el delegate está pausado
        runtimeService.createMessageCorrelation("ComplianceRevokedMessage")
            .processInstanceVariableEquals("subcontractorId", ctx.sub)
            .setVariable("motivoCancelacion", "Revocación concurrente")
            .correlateAllWithResult();

        // Liberar al delegate
        allowReturn.countDown();

        // El boundary cancela el subproceso
        HistoricProcessInstance hi = awaitEnd(ctx.invoice.toString(), Duration.ofSeconds(20));
        assertThat(hi.getEndActivityId()).isIn(
            "End_Blocked_Ext", "Task_Blocked");

        // No se generó instrucción de pago
        Long payments = jdbc.queryForObject(
            "SELECT count(*) FROM payment WHERE tenant_id = ? AND invoice_id = ?",
            Long.class, ctx.tenant, ctx.invoice);
        assertThat(payments).isZero();
    }

    // -----------------------------------------------------------------
    // Test 3: revocación DESPUÉS del pago -> sin efecto retroactivo
    // -----------------------------------------------------------------
    @Test
    void revocation_after_payment_does_not_retroactively_block() throws Exception {
        var ctx = seedFullPaymentContext("VIGENTE", 1L);
        startPaymentProcess(ctx);

        HistoricProcessInstance hi = awaitEnd(ctx.invoice.toString(), Duration.ofSeconds(20));
        assertThat(hi.getEndActivityId())
            .as("El proceso debe haber completado normalmente").isEqualTo("End_Process_OK");

        Long payments = jdbc.queryForObject(
            "SELECT count(*) FROM payment WHERE tenant_id = ? AND invoice_id = ?",
            Long.class, ctx.tenant, ctx.invoice);
        assertThat(payments).as("Debe existir una instrucción PENDING tras pasar los gates").isEqualTo(1L);

        // Revocación posterior: 0 correlaciones activas
        int correlated = runtimeService.createMessageCorrelation("ComplianceRevokedMessage")
            .processInstanceVariableEquals("subcontractorId", ctx.sub)
            .correlateAllWithResult().size();
        assertThat(correlated).isZero();

        // La instrucción sigue pendiente; no existe transferencia bancaria ejecutada
        Long still = jdbc.queryForObject(
            "SELECT count(*) FROM payment WHERE tenant_id = ? AND invoice_id = ? " +
            "AND status = 'PENDING'::payment_status",
            Long.class, ctx.tenant, ctx.invoice);
        assertThat(still).isEqualTo(1L);
    }

    // -----------------------------------------------------------------
    // Test 4: doble correlación -> no-op idempotente
    // -----------------------------------------------------------------
    @Test
    void double_correlation_is_noop() throws Exception {
        var ctx = seedFullPaymentContext("VIGENTE", 1L);
        CountDownLatch delegateRead = new CountDownLatch(1);
        CountDownLatch allowReturn = new CountDownLatch(1);

        doAnswer(inv -> {
            inv.callRealMethod();
            delegateRead.countDown();
            allowReturn.await(15, TimeUnit.SECONDS);
            return null;
        }).when(complianceDelegate).execute(any());

        startPaymentProcess(ctx);
        assertThat(delegateRead.await(20, TimeUnit.SECONDS)).isTrue();

        int first = runtimeService.createMessageCorrelation("ComplianceRevokedMessage")
            .processInstanceVariableEquals("subcontractorId", ctx.sub)
            .correlateAllWithResult().size();
        int second = runtimeService.createMessageCorrelation("ComplianceRevokedMessage")
            .processInstanceVariableEquals("subcontractorId", ctx.sub)
            .correlateAllWithResult().size();

        allowReturn.countDown();

        assertThat(first).isEqualTo(1);
        assertThat(second).as("Doble correlación debe ser no-op").isZero();

        Long payments = jdbc.queryForObject(
            "SELECT count(*) FROM payment WHERE tenant_id = ? AND invoice_id = ?",
            Long.class, ctx.tenant, ctx.invoice);
        assertThat(payments).isZero();
    }

    // -----------------------------------------------------------------
    // Helpers
    // -----------------------------------------------------------------
    private record PaymentContext(
        UUID tenant, UUID project, UUID sub, UUID contract,
        UUID po, UUID invoice, UUID applicationId) {}

    private PaymentContext seedFullPaymentContext(String estadoGlobal, long version) {
        UUID tenant = SeedHelpers.seedTenant(jdbc);
        UUID project = SeedHelpers.seedProject(jdbc, tenant);
        UUID sub = SeedHelpers.seedParty(jdbc, tenant);
        UUID contract = SeedHelpers.seedContract(jdbc, tenant, project);

        // Fixture controlado: la prueba verifica el gate de compliance y el registro pendiente.
        UUID invoice = SeedHelpers.seedInvoiceWithPoAndReceipt(
            jdbc, tenant, project, sub, contract, new BigDecimal("500.00"));
        UUID applicationId = UUID.randomUUID();
        jdbc.update("INSERT INTO payment_application (tenant_id, payment_application_id, invoice_id, " +
            "project_id, contract_id, subcontractor_id, amount_requested, status) " +
            "VALUES (?, ?, ?, ?, ?, ?, 500.00, 'PENDING_APPROVAL')",
            tenant, applicationId, invoice, project, contract, sub);

        SeedHelpers.seedComplianceHead(jdbc, tenant, sub, project, estadoGlobal, version);

        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        jdbc.update(
            "INSERT INTO compliance_requirement " +
            "(tenant_id, requisito_id, subcontractor_id, project_id, tipo_requisito, " +
            " estado_verificacion, fecha_vencimiento, fuente_evento_id, version_fila) " +
            "VALUES (?, ?, ?, ?, 'SEGURO_RC', 'VERIFICADO'::compliance_estado, " +
            "        CURRENT_DATE + 30, ?, ?)",
            tenant, UUID.randomUUID(), sub, project, UUID.randomUUID(), version);

        return new PaymentContext(tenant, project, sub, contract, null, invoice, applicationId);
    }

    private void startPaymentProcess(PaymentContext ctx) {
        Map<String, Object> vars = new HashMap<>();
        vars.put("tenantId", ctx.tenant);
        vars.put("invoiceId", ctx.invoice);
        vars.put("subcontractorId", ctx.sub);
        vars.put("projectId", ctx.project);
        vars.put("montoFactura", new BigDecimal("500.00"));
        vars.put("monedaFactura", "MXN");
        vars.put("invoiceCurrency", "MXN");
        vars.put("contractId", ctx.contract);
        vars.put("paymentApplicationId", ctx.applicationId);

        runtimeService.startProcessInstanceByKey(
            "paymentApprovalProcess", ctx.invoice.toString(), vars);
    }

    private HistoricProcessInstance awaitEnd(String businessKey, Duration timeout)
        throws InterruptedException {
        Instant until = Instant.now().plus(timeout);
        while (Instant.now().isBefore(until)) {
            var list = historyService.createHistoricProcessInstanceQuery()
                .processInstanceBusinessKey(businessKey)
                .finished()
                .list();
            if (!list.isEmpty()) return list.get(0);
            Thread.sleep(300);
        }
        throw new AssertionError(
            "Proceso no terminó en " + timeout + " para businessKey=" + businessKey);
    }
}
