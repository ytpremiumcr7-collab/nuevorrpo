package com.tuempresa.billing;

import com.tuempresa.testsupport.PostgresTestBase;
import com.tuempresa.testsupport.SeedHelpers;
import org.camunda.bpm.engine.HistoryService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Qualifier;

import java.math.BigDecimal;
import java.util.Map;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Test end-to-end: HTTP -> servicio -> BPMN -> delegates -> BD.
 * Verifica que el stack completo funciona para el happy path.
 * Falla si falta cualquier eslabón (DMN, delegate, controller, tabla).
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class EndToEndHappyPathTest extends PostgresTestBase {

    @Autowired @Qualifier("testAdminJdbcTemplate") JdbcTemplate jdbc;
    @Autowired TestRestTemplate rest;
    @Autowired HistoryService historyService;

    @Test
    void full_payment_request_via_rest_creates_pending_instruction_and_audits() throws Exception {
        UUID tenant = SeedHelpers.seedTenant(jdbc);
        UUID project = SeedHelpers.seedProject(jdbc, tenant);
        UUID sub = SeedHelpers.seedParty(jdbc, tenant);
        UUID contract = SeedHelpers.seedContract(jdbc, tenant, project);
        SeedHelpers.seedComplianceHead(jdbc, tenant, sub, project, "VIGENTE", 1);

        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        jdbc.update(
            "INSERT INTO compliance_requirement " +
            "(tenant_id, requisito_id, subcontractor_id, project_id, tipo_requisito, " +
            " estado_verificacion, fecha_vencimiento, fuente_evento_id, version_fila) " +
            "VALUES (?, ?, ?, ?, 'SEGURO_RC', 'VERIFICADO'::compliance_estado, " +
            "        CURRENT_DATE + 30, ?, 1)",
            tenant, UUID.randomUUID(), sub, project, UUID.randomUUID());

        UUID invoice = SeedHelpers.seedInvoiceWithPoAndReceipt(
            jdbc, tenant, project, sub, contract, new BigDecimal("500.00"));

        UUID operatorId = UUID.randomUUID();
        jdbc.update("INSERT INTO app_user (tenant_id, user_id, email, display_name) VALUES (?, ?, ?, ?)",
            tenant, operatorId, "owner@example.test", "Owner de prueba");
        jdbc.update("INSERT INTO project_membership (tenant_id, project_id, user_id, role) " +
            "VALUES (?, ?, ?, 'OWNER'::project_role)", tenant, project, operatorId);

        HttpHeaders headers = new HttpHeaders();
        headers.set("X-Tenant-Id", tenant.toString());
        headers.set("X-User-Id", operatorId.toString());
        headers.set("Idempotency-Key", "e2e-payment-" + UUID.randomUUID());
        headers.setContentType(MediaType.APPLICATION_JSON);

        Map<String, Object> body = Map.of(
            "invoiceId", invoice.toString(),
            "subcontractorId", sub.toString(),
            "projectId", project.toString(),
            "monto", "500.00",
            "contractId", contract.toString());

        ResponseEntity<Map> resp = rest.postForEntity(
            "/api/payments/applications",
            new HttpEntity<>(body, headers),
            Map.class);

        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.OK);
        assertThat(resp.getBody()).containsKey("processInstanceId");

        // Esperar fin del proceso
        long until = System.currentTimeMillis() + 20_000;
        Long paymentCount = 0L;
        while (System.currentTimeMillis() < until) {
            paymentCount = jdbc.queryForObject(
                "SELECT count(*) FROM payment WHERE tenant_id = ? AND invoice_id = ? " +
                "AND status = 'PENDING'::payment_status",
                Long.class, tenant, invoice);
            if (paymentCount > 0) break;
            Thread.sleep(300);
        }
        assertThat(paymentCount).as("Debe existir una instrucción pendiente; no una transferencia inventada").isEqualTo(1L);

        Map<String, Object> durableDecision = jdbc.queryForMap(
            "SELECT d.approval_route, d.decision_source, d.decision, d.approved_amount, d.policy_version, pa.status " +
            "FROM payment_approval_decision d JOIN payment_application pa " +
            "ON pa.tenant_id = d.tenant_id AND pa.payment_application_id = d.payment_application_id " +
            "WHERE d.tenant_id = ? AND d.payment_application_id = (SELECT payment_application_id FROM payment WHERE tenant_id = ? AND invoice_id = ?)",
            tenant, tenant, invoice);
        assertThat(durableDecision.get("approval_route")).isEqualTo("AUTOMATICA");
        assertThat(durableDecision.get("decision_source")).isEqualTo("POLICY");
        assertThat(durableDecision.get("decision")).isEqualTo("APPROVED");
        assertThat((BigDecimal) durableDecision.get("approved_amount")).isEqualByComparingTo("500.00");
        assertThat(durableDecision.get("policy_version")).isEqualTo("nivelAprobacionPago-v2-MXN");
        assertThat(durableDecision.get("status")).isEqualTo("PAYMENT_PENDING");

        // Audit chain intacta
        Long broken = jdbc.queryForObject(
            "SELECT count(*) FROM verify_audit_chain(?)", Long.class, tenant);
        assertThat(broken).as("Cadena de auditoría debe estar intacta").isZero();
    }


    @Test
    void manual_review_policy_finishes_without_creating_payment_or_approval() throws Exception {
        UUID tenant = SeedHelpers.seedTenant(jdbc);
        UUID project = SeedHelpers.seedProject(jdbc, tenant);
        UUID sub = SeedHelpers.seedParty(jdbc, tenant);
        UUID contract = SeedHelpers.seedContract(jdbc, tenant, project);
        SeedHelpers.seedComplianceHead(jdbc, tenant, sub, project, "VIGENTE", 1);
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        jdbc.update("INSERT INTO compliance_requirement " +
            "(tenant_id, requisito_id, subcontractor_id, project_id, tipo_requisito, estado_verificacion, fecha_vencimiento, fuente_evento_id, version_fila) " +
            "VALUES (?, ?, ?, ?, 'SEGURO_RC', 'VERIFICADO'::compliance_estado, CURRENT_DATE + 30, ?, 1)",
            tenant, UUID.randomUUID(), sub, project, UUID.randomUUID());
        UUID invoice = SeedHelpers.seedInvoiceWithPoAndReceipt(jdbc, tenant, project, sub, contract, new BigDecimal("1500.00"));
        UUID operatorId = UUID.randomUUID();
        jdbc.update("INSERT INTO app_user (tenant_id, user_id, email, display_name) VALUES (?, ?, ?, ?)",
            tenant, operatorId, "review-owner@example.test", "Owner revisión");
        jdbc.update("INSERT INTO project_membership (tenant_id, project_id, user_id, role) " +
            "VALUES (?, ?, ?, 'OWNER'::project_role)", tenant, project, operatorId);
        HttpHeaders headers = new HttpHeaders();
        headers.set("X-Tenant-Id", tenant.toString());
        headers.set("X-User-Id", operatorId.toString());
        headers.set("Idempotency-Key", "e2e-payment-" + UUID.randomUUID());
        headers.setContentType(MediaType.APPLICATION_JSON);
        Map<String, Object> body = Map.of(
            "invoiceId", invoice.toString(), "subcontractorId", sub.toString(),
            "projectId", project.toString(), "monto", "1500.00", "contractId", contract.toString());
        ResponseEntity<Map> resp = rest.postForEntity("/api/payments/applications", new HttpEntity<>(body, headers), Map.class);
        assertThat(resp.getStatusCode()).isEqualTo(HttpStatus.OK);
        String processId = String.valueOf(resp.getBody().get("processInstanceId"));
        long until = System.currentTimeMillis() + 20_000;
        org.camunda.bpm.engine.history.HistoricProcessInstance process = null;
        while (System.currentTimeMillis() < until) {
            process = historyService.createHistoricProcessInstanceQuery().processInstanceId(processId).finished().singleResult();
            if (process != null) break;
            Thread.sleep(300);
        }
        assertThat(process).as("La ruta de revisión manual debe terminar de forma controlada").isNotNull();
        assertThat(process.getEndActivityId()).isEqualTo("End_ApprovalRequired");
        assertThat(jdbc.queryForObject("SELECT count(*) FROM payment WHERE tenant_id = ? AND invoice_id = ?", Long.class, tenant, invoice)).isZero();
        assertThat(jdbc.queryForObject("SELECT count(*) FROM payment_approval_decision WHERE tenant_id = ? AND project_id = ?", Long.class, tenant, project)).isZero();
        assertThat(jdbc.queryForObject("SELECT status FROM payment_application WHERE tenant_id = ? AND invoice_id = ?", String.class, tenant, invoice)).isEqualTo("PENDING_APPROVAL");
    }
}
