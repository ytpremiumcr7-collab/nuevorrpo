package com.tuempresa.billing;

import com.tuempresa.billing.delegate.ThreeWayMatchDelegate;
import com.tuempresa.testsupport.PostgresTestBase;
import com.tuempresa.testsupport.SeedHelpers;
import org.junit.jupiter.api.Test;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Qualifier;

import java.math.BigDecimal;
import java.util.UUID;

import static org.assertj.core.api.Assertions.assertThatThrownBy;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

class ThreeWayMatchFailLoudTest extends PostgresTestBase {

    @Autowired @Qualifier("testAdminJdbcTemplate") JdbcTemplate jdbc;
    @Autowired ThreeWayMatchDelegate delegate;

    @Test
    void invoice_without_po_fails_loudly() {
        UUID tenant = SeedHelpers.seedTenant(jdbc);
        UUID project = SeedHelpers.seedProject(jdbc, tenant);
        UUID sub = SeedHelpers.seedParty(jdbc, tenant);
        UUID contract = SeedHelpers.seedContract(jdbc, tenant, project);

        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        UUID invoice = UUID.randomUUID();
        jdbc.update("INSERT INTO invoice (tenant_id, invoice_id, project_id, contract_id, " +
            "subcontractor_id, invoice_number, amount, currency, invoice_date, received_at, " +
            "status) VALUES (?, ?, ?, ?, ?, 'X', 1000, 'USD', CURRENT_DATE, now(), 'RECEIVED')",
            tenant, invoice, project, contract, sub);

        DelegateExecution exec = mock(DelegateExecution.class);
        when(exec.getVariable("tenantId")).thenReturn(tenant);
        when(exec.getVariable("invoiceId")).thenReturn(invoice);

        assertThatThrownBy(() -> delegate.execute(exec))
            .isInstanceOf(IllegalStateException.class)
            .hasMessageContaining("po_reference");
    }

    @Test
    void happy_path_returns_match() {
        UUID tenant = SeedHelpers.seedTenant(jdbc);
        UUID project = SeedHelpers.seedProject(jdbc, tenant);
        UUID sub = SeedHelpers.seedParty(jdbc, tenant);
        UUID contract = SeedHelpers.seedContract(jdbc, tenant, project);
        UUID invoice = SeedHelpers.seedInvoiceWithPoAndReceipt(
            jdbc, tenant, project, sub, contract, new BigDecimal("1000.00"));

        DelegateExecution exec = mock(DelegateExecution.class);
        when(exec.getVariable("tenantId")).thenReturn(tenant);
        when(exec.getVariable("invoiceId")).thenReturn(invoice);

        delegate.execute(exec);

        org.mockito.Mockito.verify(exec).setVariable(
            org.mockito.ArgumentMatchers.eq("matchResult"),
            org.mockito.ArgumentMatchers.argThat(arg -> {
                var map = (java.util.Map<?,?>) arg;
                return "MATCH".equals(map.get("estado"));
            }));
    }
}
