package com.tuempresa.bidding;

import com.tuempresa.testsupport.PostgresTestBase;
import com.tuempresa.testsupport.SeedHelpers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Qualifier;

import java.util.UUID;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Propiedad crítica: bajo N threads concurrentes sobre la misma
 * bid_package, solo uno gana el UPDATE atómico (status IN OPEN/RECEIVING).
 * Si dos ganaran, dos contratos se crearían para el mismo paquete.
 */
class BiddingAwardConcurrencyTest extends PostgresTestBase {

    @Autowired @Qualifier("testAdminJdbcTemplate") JdbcTemplate jdbc;

    @Test
    void concurrent_awards_only_one_wins() throws Exception {
        UUID tenant = SeedHelpers.seedTenant(jdbc);
        UUID project = SeedHelpers.seedProject(jdbc, tenant);
        UUID bidder1 = SeedHelpers.seedParty(jdbc, tenant);
        UUID bidder2 = SeedHelpers.seedParty(jdbc, tenant);

        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        UUID packageId = UUID.randomUUID();
        jdbc.update(
            "INSERT INTO bid_package (tenant_id, bid_package_id, project_id, name, " +
            "status, created_by) VALUES (?, ?, ?, 'Test', 'OPEN'::bid_package_status, ?)",
            tenant, packageId, project, bidder1);

        UUID bid1 = UUID.randomUUID();
        UUID bid2 = UUID.randomUUID();
        jdbc.update(
            "INSERT INTO bid (tenant_id, bid_id, bid_package_id, bidder_id, amount, status) " +
            "VALUES (?, ?, ?, ?, 5000, 'RECEIVED'::bid_status)",
            tenant, bid1, packageId, bidder1);
        jdbc.update(
            "INSERT INTO bid (tenant_id, bid_id, bid_package_id, bidder_id, amount, status) " +
            "VALUES (?, ?, ?, ?, 6000, 'RECEIVED'::bid_status)",
            tenant, bid2, packageId, bidder2);

        int threads = 8;
        CountDownLatch start = new CountDownLatch(1);
        CountDownLatch done = new CountDownLatch(threads);
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        AtomicInteger successes = new AtomicInteger();

        for (int i = 0; i < threads; i++) {
            final UUID bid = (i % 2 == 0) ? bid1 : bid2;
            pool.submit(() -> {
                try {
                    start.await();
                    jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
                    int updated = jdbc.update(
                        "UPDATE bid_package SET status = 'AWARDED'::bid_package_status, " +
                        "awarded_bid_id = ?, awarded_at = now() " +
                        "WHERE tenant_id = ? AND bid_package_id = ? " +
                        "AND status IN ('OPEN','RECEIVING','EVALUATING')",
                        bid, tenant, packageId);
                    if (updated == 1) successes.incrementAndGet();
                } catch (Exception e) {
                    // loser lanza o recibe 0; cualquiera de los dos es correcto
                } finally {
                    done.countDown();
                }
            });
        }
        start.countDown();
        done.await(15, TimeUnit.SECONDS);
        pool.shutdown();

        assertThat(successes.get())
            .as("Exactamente un award debe ganar bajo concurrencia")
            .isEqualTo(1);

        String status = jdbc.queryForObject(
            "SELECT status FROM bid_package WHERE tenant_id = ? AND bid_package_id = ?",
            String.class, tenant, packageId);
        assertThat(status).isEqualTo("AWARDED");
    }
}
