import { api, getCreds, saveCreds } from './api.js';

const views = ['dashboard', 'compliance', 'rfis', 'payments', 'submittals', 'identity', 'templates', 'integrations'];
let current = 'dashboard';

function $(id) { return document.getElementById(id); }
function toast(msg, isError) {
  const t = $('toast');
  t.textContent = msg;
  t.classList.toggle('error', !!isError);
  t.style.display = 'block';
  setTimeout(() => { t.style.display = 'none'; }, 4500);
}

function showView(name) {
  current = name;
  views.forEach(v => {
    const el = $('view-' + v);
    if (el) el.classList.toggle('hidden', v !== name);
    const btn = document.querySelector(`nav button[data-view="${v}"]`);
    if (btn) btn.classList.toggle('active', v === name);
  });
  loadView(name);
}

function tableHTML(rows, cols) {
  if (!rows || !rows.length) return '<p style="color:var(--muted)">Sin registros</p>';
  let h = '<table><thead><tr>' + cols.map(c => `<th>${c.l}</th>`).join('') + '</tr></thead><tbody>';
  for (const r of rows) {
    h += '<tr>' + cols.map(c => {
      let val = r[c.k];
      if (c.badge && val) {
        const cls = c.badge(val) || '';
        val = `<span class="badge ${cls}">${val}</span>`;
      }
      return `<td>${val ?? ''}</td>`;
    }).join('') + '</tr>';
  }
  return h + '</tbody></table>';
}

async function loadDashboard() {
  const s = await api('/api/ops/summary');
  $('kpi').innerHTML = `
    <div class="kpi danger"><div class="v">${s.complianceBlocked}</div><div class="l">Compliance bloqueado</div></div>
    <div class="kpi warn"><div class="v">${s.openRfis}</div><div class="l">RFIs abiertos</div></div>
    <div class="kpi"><div class="v">${s.pendingPayments}</div><div class="l">Pagos pendientes</div></div>
    <div class="kpi"><div class="v">${s.openSubmittals}</div><div class="l">Submittals abiertos</div></div>`;
}

async function loadCompliance() {
  const rows = await api('/api/ops/compliance-queue');
  $('compliance-table').innerHTML = tableHTML(rows, [
    { k: 'project_id', l: 'Proyecto' },
    { k: 'subcontractor_id', l: 'Subcontratista' },
    { k: 'requisito_critico_tipo', l: 'Requisito crítico' },
    { k: 'requisito_critico_vencimiento', l: 'Vence' },
    { k: 'requisitos_bloqueados', l: 'Bloqueados' },
    { k: 'estado_global', l: 'Estado', badge: () => 'red' },
  ]);
}

async function loadRfis() {
  const rows = await api('/api/ops/rfis');
  $('rfis-table').innerHTML = tableHTML(rows, [
    { k: 'rfi_number', l: 'Nº' },
    { k: 'title', l: 'Título' },
    { k: 'status', l: 'Estado', badge: () => '' },
    { k: 'deadline', l: 'Deadline' },
    { k: 'project_id', l: 'Proyecto' },
  ]);
}

async function loadPayments() {
  const rows = await api('/api/ops/payments/pending');
  $('payments-table').innerHTML = tableHTML(rows, [
    { k: 'payment_application_id', l: 'Solicitud' },
    { k: 'amount_requested', l: 'Monto' },
    { k: 'status', l: 'Estado' },
    { k: 'project_id', l: 'Proyecto' },
    { k: 'subcontractor_id', l: 'Sub' },
  ]);
}

async function loadSubmittals() {
  const rows = await api('/api/ops/submittals/open');
  $('submittals-table').innerHTML = tableHTML(rows, [
    { k: 'submittal_number', l: 'Nº' },
    { k: 'title', l: 'Título' },
    { k: 'status', l: 'Estado' },
    { k: 'project_id', l: 'Proyecto' },
  ]);
}

async function loadIdentity() {
  try {
    const me = await api('/api/identity/me');
    $('identity-me').textContent = JSON.stringify(me, null, 2);
  } catch (e) {
    $('identity-me').textContent = 'No autenticado: ' + e.message;
  }
}

async function loadIntegrations() {
  const st = await api('/api/integrations/procore/status');
  $('procore-status').innerHTML = `<span class="badge ${st.enabled ? 'green' : ''}">${st.mode}</span>
    <p style="color:var(--muted);margin:.5rem 0 0">enabled=${st.enabled}. Sin PROCORE_TOKEN el puente opera en DRY-RUN (explícito).</p>`;
}

async function loadView(name) {
  try {
    if (name === 'dashboard') await loadDashboard();
    if (name === 'compliance') await loadCompliance();
    if (name === 'rfis') await loadRfis();
    if (name === 'payments') await loadPayments();
    if (name === 'submittals') await loadSubmittals();
    if (name === 'identity') await loadIdentity();
    if (name === 'integrations') await loadIntegrations();
  } catch (e) {
    toast(e.message || String(e), true);
  }
}

function wire() {
  const c = getCreds();
  $('tenantId').value = c.tenantId;
  $('userId').value = c.userId;
  $('apiKey').value = c.apiKey;

  $('btnSaveCreds').onclick = () => {
    saveCreds({
      tenantId: $('tenantId').value.trim(),
      userId: $('userId').value.trim(),
      apiKey: $('apiKey').value.trim(),
    });
    toast('Credenciales guardadas');
    loadView(current);
  };

  $('btnBootstrap').onclick = async () => {
    try {
      const tenantId = $('tenantId').value.trim();
      if (!tenantId) throw new Error('Indica tenant');
      saveCreds({ tenantId, userId: '', apiKey: '' });
      const body = {
        email: $('bootEmail').value.trim() || 'ops@local.dev',
        displayName: $('bootName').value.trim() || 'Operador',
        projectId: $('bootProject').value.trim() || undefined,
      };
      const res = await api('/api/auth/bootstrap', {
        method: 'POST',
        headers: { 'X-Bootstrap-Token': $('bootToken').value },
        body: JSON.stringify(body),
      });
      saveCreds({ tenantId, userId: res.userId, apiKey: res.apiKey });
      $('userId').value = res.userId;
      $('apiKey').value = res.apiKey;
      $('bootToken').value = '';
      if (res.projectId) $('bootProject').value = res.projectId;
      toast('OWNER creado. Guarda la API key; solo se muestra una vez.');
      loadView('identity');
    } catch (e) {
      toast(e.message, true);
    }
  };

  $('btnAssemble').onclick = async () => {
    try {
      const code = $('tplCode').value.trim() || 'RFI_STANDARD';
      const variables = JSON.parse($('tplVars').value || '{}');
      const projectId = $('tplProject').value.trim() || null;
      const res = await api('/api/templates/' + encodeURIComponent(code) + '/assemble', {
        method: 'POST',
        body: JSON.stringify({ projectId, variables }),
      });
      $('tplOut').textContent = res.markdown || JSON.stringify(res, null, 2);
      toast('Documento ensamblado');
    } catch (e) {
      toast(e.message, true);
    }
  };

  document.querySelectorAll('nav button[data-view]').forEach(btn => {
    btn.onclick = () => showView(btn.dataset.view);
  });
}

wire();
showView('dashboard');
