/** Cliente HTTP del front operativo — siempre envía tenant + user. */
export function getCreds() {
  return {
    tenantId: localStorage.getItem('tenantId') || '',
    userId: localStorage.getItem('userId') || '',
    apiKey: localStorage.getItem('apiKey') || '',
  };
}

export function saveCreds({ tenantId, userId, apiKey }) {
  if (tenantId != null) localStorage.setItem('tenantId', tenantId);
  if (userId != null) localStorage.setItem('userId', userId);
  if (apiKey != null) localStorage.setItem('apiKey', apiKey);
}

export async function api(path, options = {}) {
  const c = getCreds();
  const headers = Object.assign({
    'Accept': 'application/json',
    'Content-Type': 'application/json',
    'X-Tenant-Id': c.tenantId,
  }, options.headers || {});
  if (c.apiKey) headers['X-Api-Key'] = c.apiKey;
  else if (c.userId) headers['X-User-Id'] = c.userId;

  const res = await fetch(path, { ...options, headers });
  const text = await res.text();
  let body = null;
  try { body = text ? JSON.parse(text) : null; } catch { body = text; }
  if (!res.ok) {
    const msg = (body && body.message) ? body.message : (res.status + ' ' + res.statusText);
    const err = new Error(msg);
    err.status = res.status;
    err.body = body;
    throw err;
  }
  return body;
}
