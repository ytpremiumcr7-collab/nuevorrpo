-- V19: monetary reservations are serialized by locking the invoice row in application code.
-- These constraints protect against duplicate workflow attempts and invalid negative reservations.
ALTER TABLE payment_application
  ADD CONSTRAINT ck_payment_application_amount_requested_positive CHECK (amount_requested > 0),
  ADD CONSTRAINT ck_payment_application_amount_approved_positive CHECK (amount_approved IS NULL OR amount_approved > 0);
ALTER TABLE payment
  ADD CONSTRAINT ck_payment_amount_positive CHECK (amount > 0);
CREATE UNIQUE INDEX IF NOT EXISTS ux_payment_one_per_application
  ON payment (tenant_id, payment_application_id);
CREATE INDEX IF NOT EXISTS ix_payment_application_invoice_status
  ON payment_application (tenant_id, invoice_id, status);
CREATE INDEX IF NOT EXISTS ix_payment_invoice_status
  ON payment (tenant_id, invoice_id, status);
