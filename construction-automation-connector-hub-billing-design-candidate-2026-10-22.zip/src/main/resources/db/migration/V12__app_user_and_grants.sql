-- =====================================================================
-- V12: crear app_user (NOSUPERUSER NOBYPASSRLS) para que RLS aplique
--      en runtime y en Testcontainers (que no monta el init script).
-- =====================================================================

DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'app_user') THEN
    CREATE ROLE app_user WITH NOLOGIN
      NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
  END IF;
END $$;

-- Permisos sobre BD y schema (idempotente)
DO $$
BEGIN
  EXECUTE 'GRANT CONNECT ON DATABASE ' || current_database() || ' TO app_user';
EXCEPTION WHEN OTHERS THEN
  -- si el usuario no tiene permisos, no fallar; se configura en deploy
  NULL;
END $$;

GRANT USAGE ON SCHEMA public TO app_user;

-- Grants sobre tablas/funciones existentes
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO app_user;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO app_user;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO app_user;

-- Default privileges para tablas futuras creadas por el usuario de migración
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO app_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT USAGE, SELECT ON SEQUENCES TO app_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public
  GRANT EXECUTE ON FUNCTIONS TO app_user;
