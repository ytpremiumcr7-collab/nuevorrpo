CREATE TYPE outbox_status AS ENUM ('PENDING', 'PROCESSING', 'PROCESSED', 'DEAD_LETTERED');

CREATE TABLE projection_outbox (
  id                uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id         uuid NOT NULL,
  event_id          uuid NOT NULL,
  aggregate_type    varchar(40) NOT NULL,
  aggregate_id      uuid NOT NULL,
  aggregate_version bigint NOT NULL,
  event_type        varchar(60) NOT NULL,
  payload           jsonb NOT NULL,
  status            outbox_status NOT NULL DEFAULT 'PENDING',
  attempts          smallint NOT NULL DEFAULT 0,
  next_retry_at     timestamptz NOT NULL DEFAULT now(),
  last_error        text,
  created_at        timestamptz NOT NULL DEFAULT now(),
  processed_at      timestamptz,
  dead_lettered_at  timestamptz,
  UNIQUE (tenant_id, event_id)
);
CREATE INDEX idx_outbox_claimable ON projection_outbox (next_retry_at)
  WHERE status IN ('PENDING', 'PROCESSING');
CREATE INDEX idx_outbox_dlq ON projection_outbox (dead_lettered_at)
  WHERE status = 'DEAD_LETTERED';

-- RLS en shared kernel + outbox + audit
ALTER TABLE tenant        ENABLE ROW LEVEL SECURITY;
ALTER TABLE project       ENABLE ROW LEVEL SECURITY;
ALTER TABLE party         ENABLE ROW LEVEL SECURITY;
ALTER TABLE party_role    ENABLE ROW LEVEL SECURITY;
ALTER TABLE site          ENABLE ROW LEVEL SECURITY;
ALTER TABLE contract      ENABLE ROW LEVEL SECURITY;
ALTER TABLE contract_party ENABLE ROW LEVEL SECURITY;
ALTER TABLE work_package  ENABLE ROW LEVEL SECURITY;
ALTER TABLE document      ENABLE ROW LEVEL SECURITY;
ALTER TABLE projection_outbox ENABLE ROW LEVEL SECURITY;
ALTER TABLE audit_event   ENABLE ROW LEVEL SECURITY;

-- Políticas: por tenant. Nota: cuando app_user está conectado
-- (NOSUPERUSER NOBYPASSRLS), se aplican. El init script creó app_user.
-- Estas políticas se aplican a PUBLIC por default; ok.
DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'project','party','party_role','site','contract','contract_party',
    'work_package','document','projection_outbox','audit_event'
  ]) LOOP
    EXECUTE format(
      'CREATE POLICY ti_%I ON %I USING (tenant_id = current_setting(''app.tenant_id'')::uuid)',
      t, t);
  END LOOP;
END $$;

-- En la tabla tenant solo exponemos el row del propio tenant
CREATE POLICY ti_tenant ON tenant
  USING (tenant_id = current_setting('app.tenant_id')::uuid);
