-- V18: durable payment context, policy decision evidence, and idempotent submissions.
-- Fail closed if legacy applications cannot be tied to an authoritative invoice/contract.
ALTER TABLE payment_application ADD COLUMN contract_id uuid;
UPDATE payment_application pa
   SET contract_id = i.contract_id
  FROM invoice i
 WHERE i.tenant_id = pa.tenant_id
   AND i.invoice_id = pa.invoice_id
   AND pa.contract_id IS NULL;
DO $$
BEGIN
  IF EXISTS (SELECT 1 FROM payment_application WHERE contract_id IS NULL) THEN
    RAISE EXCEPTION 'V18 blocked: payment_application contains rows without a resolvable invoice contract';
  END IF;
END $$;
ALTER TABLE payment_application ALTER COLUMN contract_id SET NOT NULL;
-- Composite uniqueness lets the database enforce that the application context matches its invoice.
CREATE UNIQUE INDEX ux_invoice_payment_context
  ON invoice (tenant_id, invoice_id, project_id, contract_id, subcontractor_id);
CREATE UNIQUE INDEX ux_contract_project_context
  ON contract (tenant_id, contract_id, project_id);
ALTER TABLE payment_application
  ADD CONSTRAINT fk_payment_application_invoice_context
    FOREIGN KEY (tenant_id, invoice_id, project_id, contract_id, subcontractor_id)
    REFERENCES invoice (tenant_id, invoice_id, project_id, contract_id, subcontractor_id),
  ADD CONSTRAINT fk_payment_application_contract_project
    FOREIGN KEY (tenant_id, contract_id, project_id)
    REFERENCES contract (tenant_id, contract_id, project_id),
  ADD CONSTRAINT fk_payment_application_subcontractor
    FOREIGN KEY (tenant_id, subcontractor_id) REFERENCES party (tenant_id, party_id);

ALTER TABLE payment_application
  ADD COLUMN approval_policy_version varchar(80),
  ADD COLUMN submission_idempotency_key varchar(200),
  ADD COLUMN submission_request_hash char(64),
  ADD COLUMN process_instance_id varchar(64);
CREATE UNIQUE INDEX ux_payment_application_idempotency
  ON payment_application (tenant_id, submission_idempotency_key)
  WHERE submission_idempotency_key IS NOT NULL;

CREATE TABLE payment_approval_decision (
  tenant_id uuid NOT NULL,
  approval_id uuid NOT NULL,
  payment_application_id uuid NOT NULL,
  project_id uuid NOT NULL,
  approval_route varchar(30) NOT NULL,
  decision_source varchar(20) NOT NULL CHECK (decision_source IN ('POLICY','HUMAN')),
  decision varchar(20) NOT NULL CHECK (decision IN ('APPROVED','REJECTED')),
  approved_amount numeric(18,2) NOT NULL CHECK (approved_amount > 0),
  policy_version varchar(80) NOT NULL,
  decision_reason text NOT NULL CHECK (length(trim(decision_reason)) > 0),
  decided_by uuid,
  decided_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, approval_id),
  FOREIGN KEY (tenant_id, payment_application_id)
    REFERENCES payment_application (tenant_id, payment_application_id),
  FOREIGN KEY (tenant_id, project_id) REFERENCES project (tenant_id, project_id)
);
ALTER TABLE payment_approval_decision ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_approval_decision FORCE ROW LEVEL SECURITY;
CREATE POLICY payment_approval_decision_tenant_isolation ON payment_approval_decision
  USING (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid)
  WITH CHECK (tenant_id = NULLIF(current_setting('app.tenant_id', true), '')::uuid);
GRANT SELECT, INSERT ON payment_approval_decision TO app_user;
REVOKE UPDATE, DELETE ON payment_approval_decision FROM app_user;
