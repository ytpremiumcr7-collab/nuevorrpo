CREATE TYPE compliance_estado AS ENUM
  ('PENDIENTE','VERIFICADO','RECHAZADO','REVOCADO','EXPIRADO');
CREATE TYPE compliance_estado_global AS ENUM
  ('VIGENTE','BLOQUEADO','PARCIAL','SIN_DATOS');

CREATE TABLE compliance_subcontractor_head (
  tenant_id                     uuid NOT NULL,
  subcontractor_id              uuid NOT NULL,
  project_id                    uuid NOT NULL,
  estado_global                 compliance_estado_global NOT NULL,
  version_actual                bigint NOT NULL,
  requisito_critico_id          uuid NOT NULL,
  requisito_critico_tipo        varchar(40) NOT NULL,
  requisito_critico_estado      compliance_estado NOT NULL,
  requisito_critico_vencimiento date NOT NULL,
  requisitos_total              int NOT NULL,
  requisitos_vigentes           int NOT NULL,
  requisitos_bloqueados         int NOT NULL,
  ultimo_evento_id              uuid NOT NULL,
  actualizado_en                timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, subcontractor_id, project_id)
);

CREATE TABLE compliance_requirement (
  tenant_id            uuid NOT NULL,
  requisito_id         uuid NOT NULL,
  subcontractor_id     uuid NOT NULL,
  project_id           uuid NOT NULL,
  tipo_requisito       varchar(40) NOT NULL,
  estado_verificacion  compliance_estado NOT NULL DEFAULT 'PENDIENTE',
  fecha_vencimiento    date NOT NULL,
  documento_id         uuid,
  aseguradora_o_emisor varchar(200),
  fuente_evento_id     uuid NOT NULL,
  version_fila         bigint NOT NULL,
  actualizado_en       timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, requisito_id)
);
CREATE INDEX idx_cr_lookup ON compliance_requirement
  (tenant_id, subcontractor_id, project_id);

ALTER TABLE compliance_subcontractor_head ENABLE ROW LEVEL SECURITY;
ALTER TABLE compliance_requirement         ENABLE ROW LEVEL SECURITY;
CREATE POLICY ti_csh ON compliance_subcontractor_head
  USING (tenant_id = current_setting('app.tenant_id')::uuid);
CREATE POLICY ti_cr ON compliance_requirement
  USING (tenant_id = current_setting('app.tenant_id')::uuid);
