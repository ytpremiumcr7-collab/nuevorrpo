CREATE TABLE permit_phase_config (
  jurisdiction varchar(40) NOT NULL,
  permit_type  varchar(60) NOT NULL,
  phase        varchar(30) NOT NULL,
  time_unit    varchar(15) NOT NULL CHECK (time_unit IN ('CALENDAR_DAYS','BUSINESS_DAYS')),
  duration     int NOT NULL CHECK (duration > 0),
  PRIMARY KEY (jurisdiction, permit_type, phase)
);
INSERT INTO permit_phase_config VALUES
  ('MX_CDMX','CONSTRUCCION_NUEVA','REVIEW','BUSINESS_DAYS',30),
  ('MX_CDMX','CONSTRUCCION_NUEVA','OBSERVED','BUSINESS_DAYS',15),
  ('ES_MADRID','LICENCIA_OBRA','REVIEW','CALENDAR_DAYS',60),
  ('US_TX','BUILDING_PERMIT','REVIEW','CALENDAR_DAYS',45);

CREATE TYPE observation_state AS ENUM ('NOT_STARTED','IN_PROGRESS','COMPLETE');
CREATE TYPE observation_validity AS ENUM (
  'VALID','INVALID_OCCLUSION','INVALID_MODEL_DEGRADED',
  'INVALID_MANUAL_CORRECTION','PENDING_REVIEW'
);
CREATE TYPE progress_status AS ENUM ('DRAFT','READY_FOR_REVIEW','CERTIFIED','REJECTED');

CREATE TABLE bim_element_observation (
  tenant_id             uuid NOT NULL,
  observation_id        uuid NOT NULL,
  project_id            uuid NOT NULL,
  work_package_id       uuid NOT NULL,
  ifc_guid              varchar(80) NOT NULL,
  ifc_class             varchar(80) NOT NULL,
  observed_state        observation_state NOT NULL,
  observed_quantity     numeric(18,4) NOT NULL CHECK (observed_quantity >= 0),
  planned_quantity      numeric(18,4) NOT NULL CHECK (planned_quantity > 0),
  visibility_ratio      numeric(6,4) NOT NULL CHECK (visibility_ratio BETWEEN 0 AND 1),
  confidence_calibrated numeric(6,4) NOT NULL CHECK (confidence_calibrated BETWEEN 0 AND 1),
  reprojection_error    numeric(10,4) NOT NULL,
  coverage              numeric(6,4) NOT NULL CHECK (coverage BETWEEN 0 AND 1),
  evidence_refs         jsonb NOT NULL,
  model_id              varchar(80) NOT NULL,
  model_version         varchar(40) NOT NULL,
  training_dataset_hash varchar(64) NOT NULL,
  calibration_params    jsonb NOT NULL,
  observed_at           timestamptz NOT NULL,
  recorded_by           uuid NOT NULL,
  validity              observation_validity NOT NULL DEFAULT 'VALID',
  invalidation_reason   text,
  aggregate_version     bigint NOT NULL DEFAULT 1,
  created_at            timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, observation_id),
  CHECK (jsonb_array_length(evidence_refs) > 0),
  CHECK (validity = 'VALID' OR invalidation_reason IS NOT NULL),
  CHECK (observed_state <> 'COMPLETE' OR visibility_ratio >= 0.7)
);

CREATE TABLE progress_observation (
  tenant_id               uuid NOT NULL,
  progress_observation_id uuid NOT NULL,
  project_id              uuid NOT NULL,
  work_package_id         uuid NOT NULL,
  period_start            date NOT NULL,
  period_end              date NOT NULL,
  observation_refs        jsonb NOT NULL,
  progress_ratio_point    numeric(6,4) NOT NULL,
  progress_ratio_lower    numeric(6,4) NOT NULL,
  progress_ratio_upper    numeric(6,4) NOT NULL,
  confidence_level        numeric(4,3) NOT NULL CHECK (confidence_level > 0 AND confidence_level <= 1),
  status                  progress_status NOT NULL DEFAULT 'DRAFT',
  certified_at            timestamptz,
  certified_by            uuid,
  rejection_reason        text,
  evidence_manifest_id    uuid,
  model_versions_used     jsonb NOT NULL,
  contractual_threshold   numeric(6,4) NOT NULL,
  aggregate_version       bigint NOT NULL DEFAULT 1,
  PRIMARY KEY (tenant_id, progress_observation_id),
  CHECK (progress_ratio_lower <= progress_ratio_point),
  CHECK (progress_ratio_point <= progress_ratio_upper),
  CHECK (progress_ratio_lower >= 0 AND progress_ratio_upper <= 1),
  CHECK (period_start <= period_end),
  CHECK (status <> 'CERTIFIED' OR progress_ratio_lower >= contractual_threshold)
);

CREATE TABLE progress_certified_read_model (
  tenant_id               uuid NOT NULL,
  progress_observation_id uuid NOT NULL,
  project_id              uuid NOT NULL,
  work_package_id         uuid NOT NULL,
  period_start            date NOT NULL,
  period_end              date NOT NULL,
  progress_ratio_point    numeric(6,4) NOT NULL,
  progress_ratio_lower    numeric(6,4) NOT NULL,
  progress_ratio_upper    numeric(6,4) NOT NULL,
  certified_at            timestamptz NOT NULL,
  certified_by            uuid NOT NULL,
  evidence_manifest_id    uuid NOT NULL,
  PRIMARY KEY (tenant_id, progress_observation_id)
);

-- permit_phase_config es configuración global (sin tenant_id): sin RLS por tenant
ALTER TABLE bim_element_observation    ENABLE ROW LEVEL SECURITY;
ALTER TABLE progress_observation       ENABLE ROW LEVEL SECURITY;
ALTER TABLE progress_certified_read_model ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'bim_element_observation','progress_observation',
    'progress_certified_read_model'
  ]) LOOP
    EXECUTE format('CREATE POLICY ti_%I ON %I USING (tenant_id = current_setting(''app.tenant_id'')::uuid)', t, t);
  END LOOP;
END $$;
