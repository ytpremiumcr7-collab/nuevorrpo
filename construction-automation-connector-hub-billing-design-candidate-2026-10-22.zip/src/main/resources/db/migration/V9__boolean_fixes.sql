-- =========================================================================
-- V9: reemplazar booleanos y varchar-libres que enmascaraban estado
-- =========================================================================

-- 1) Añadir 'NONE' al enum compensation_state (para pagos sin compensación)
ALTER TYPE compensation_state ADD VALUE IF NOT EXISTS 'NONE' BEFORE 'OPEN';

-- 2) payment.compensation_state varchar(30) -> enum
--    Sanear valores inválidos antes del cast (defensivo)
UPDATE payment SET compensation_state = 'NONE'
 WHERE compensation_state NOT IN (
   'NONE','OPEN','EVIDENCE_VALIDATED','NOTIFIED','PLAN_SELECTED',
   'EXECUTING','RECOVERED','DISPUTED','WRITTEN_OFF','REVERSED'
 ) OR compensation_state IS NULL;
ALTER TABLE payment
  ALTER COLUMN compensation_state DROP DEFAULT,
  ALTER COLUMN compensation_state TYPE compensation_state
    USING compensation_state::compensation_state,
  ALTER COLUMN compensation_state SET DEFAULT 'NONE';

-- 3) payment_read_model.compensation_state varchar(30) -> enum
UPDATE payment_read_model SET compensation_state = 'NONE'
 WHERE compensation_state NOT IN (
   'NONE','OPEN','EVIDENCE_VALIDATED','NOTIFIED','PLAN_SELECTED',
   'EXECUTING','RECOVERED','DISPUTED','WRITTEN_OFF','REVERSED'
 ) OR compensation_state IS NULL;
ALTER TABLE payment_read_model
  ALTER COLUMN compensation_state DROP DEFAULT,
  ALTER COLUMN compensation_state TYPE compensation_state
    USING compensation_state::compensation_state,
  ALTER COLUMN compensation_state SET DEFAULT 'NONE';

-- 4) dispute_case_current.evidence_complete boolean -> enum evidence_status
CREATE TYPE evidence_status AS ENUM (
  'MISSING',              -- sin ningún documento
  'PARTIAL',              -- faltan documentos del set mínimo
  'PENDING_VERIFICATION', -- todos subidos, en revisión
  'COMPLETE'              -- completos y verificados
);

ALTER TABLE dispute_case_current
  ADD COLUMN evidence_status evidence_status NOT NULL DEFAULT 'MISSING';

-- Migración del valor booleano antiguo (best-effort: complete -> COMPLETE)
UPDATE dispute_case_current
   SET evidence_status = CASE
     WHEN evidence_complete THEN 'COMPLETE'::evidence_status
     ELSE 'MISSING'::evidence_status
   END;
ALTER TABLE dispute_case_current DROP COLUMN evidence_complete;

-- 5) deduction_log.reversed boolean -> enum deduction_status + reason
CREATE TYPE deduction_status AS ENUM ('ACTIVE', 'REVERSED');

ALTER TABLE deduction_log
  ADD COLUMN status deduction_status NOT NULL DEFAULT 'ACTIVE',
  ADD COLUMN reversal_reason varchar(200);

UPDATE deduction_log SET status = 'REVERSED' WHERE reversed = true;
ALTER TABLE deduction_log DROP COLUMN reversed;

-- 6) finance_approval_status enum en dispute_case_current
--    Reemplaza el booleano "requiresFinanceApproval" del DMN
CREATE TYPE finance_approval_status AS ENUM (
  'NOT_REQUIRED','REQUIRED','APPROVED','REJECTED'
);

ALTER TABLE dispute_case_current
  ADD COLUMN finance_approval_status finance_approval_status
        NOT NULL DEFAULT 'NOT_REQUIRED',
  ADD COLUMN finance_approval_reason varchar(200);

-- =========================================================================
-- Correcciones adicionales (bugs y gaps de la emisión anterior)
-- =========================================================================

-- a) Columnas que faltaban en compensation_case para el ciclo de vida completo
ALTER TABLE compensation_case
  ADD COLUMN notified_at timestamptz,
  ADD COLUMN plan_selected_at timestamptz,
  ADD COLUMN executing_at timestamptz,
  ADD COLUMN closed_at timestamptz,
  ADD COLUMN contractual_basis text;

-- b) Columnas para recovery_account: faltaba el "id del último evento aplicado"
ALTER TABLE recovery_account
  ADD COLUMN last_event_id uuid,
  ADD COLUMN last_event_version bigint;

-- c) Columnas de auditoría que los servicios necesitan
ALTER TABLE dispute_case
  ADD COLUMN created_by uuid;

-- d) Asegurar que business_calendar tiene índices para la función
CREATE INDEX IF NOT EXISTS idx_bc_lookup
  ON business_calendar (jurisdiction_id, calendar_date, is_business_day);

-- e) Semilla de tasas de interés legales para que el cálculo no falle
INSERT INTO legal_interest_rate
  (jurisdiction_id, effective_from, effective_to, annual_rate, source_reference)
VALUES
  ('MX_CDMX', '2025-01-01', NULL, 0.113100, 'DOF 2025'),
  ('ES_MADRID', '2025-01-01', NULL, 0.032500, 'BOE 2025'),
  ('US_TX', '2025-01-01', NULL, 0.075000, 'TX Finance Code 304')
ON CONFLICT DO NOTHING;
