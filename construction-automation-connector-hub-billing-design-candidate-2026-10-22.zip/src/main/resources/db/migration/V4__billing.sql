CREATE TYPE invoice_status AS ENUM (
  'RECEIVED','MATCHING','MATCHED','MISMATCH','PENDING_APPROVAL',
  'APPROVED','REJECTED','PAID','CANCELLED');
CREATE TYPE payment_status AS ENUM ('PENDING','EXECUTED','FAILED','COMPENSATED');

CREATE TABLE purchase_order (
  tenant_id  uuid NOT NULL,
  po_id      uuid NOT NULL,
  project_id uuid NOT NULL,
  po_number  varchar(80) NOT NULL,
  status     varchar(30) NOT NULL,
  PRIMARY KEY (tenant_id, po_id)
);
CREATE TABLE purchase_order_line (
  tenant_id   uuid NOT NULL,
  po_line_id  uuid NOT NULL,
  po_id       uuid NOT NULL,
  line_number int NOT NULL,
  description varchar(300) NOT NULL,
  quantity    numeric(18,4) NOT NULL,
  unit_price  numeric(18,4) NOT NULL,
  PRIMARY KEY (tenant_id, po_line_id)
);
CREATE TABLE goods_receipt (
  tenant_id   uuid NOT NULL,
  receipt_id  uuid NOT NULL,
  po_id       uuid NOT NULL,
  received_at timestamptz NOT NULL,
  received_by uuid NOT NULL,
  PRIMARY KEY (tenant_id, receipt_id)
);
CREATE TABLE goods_receipt_line (
  tenant_id         uuid NOT NULL,
  receipt_line_id   uuid NOT NULL,
  receipt_id        uuid NOT NULL,
  po_line_id        uuid NOT NULL,
  quantity_received numeric(18,4) NOT NULL,
  PRIMARY KEY (tenant_id, receipt_line_id)
);

CREATE TABLE invoice (
  tenant_id         uuid NOT NULL,
  invoice_id        uuid NOT NULL,
  project_id        uuid NOT NULL,
  contract_id       uuid NOT NULL,
  subcontractor_id  uuid NOT NULL,
  invoice_number    varchar(80) NOT NULL,
  amount            numeric(18,2) NOT NULL,
  currency          char(3) NOT NULL,
  invoice_date      date NOT NULL,
  received_at       timestamptz NOT NULL,
  status            invoice_status NOT NULL,
  po_reference      varchar(80),
  work_package_id   uuid,
  aggregate_version bigint NOT NULL DEFAULT 1,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, invoice_id)
);
CREATE TABLE invoice_line (
  tenant_id       uuid NOT NULL,
  invoice_line_id uuid NOT NULL,
  invoice_id      uuid NOT NULL,
  line_number     int NOT NULL,
  description     varchar(300) NOT NULL,
  quantity        numeric(18,4) NOT NULL,
  unit_price      numeric(18,4) NOT NULL,
  PRIMARY KEY (tenant_id, invoice_line_id)
);

CREATE TABLE three_way_match_result (
  tenant_id            uuid NOT NULL,
  match_id             uuid NOT NULL,
  invoice_id           uuid NOT NULL,
  estado               varchar(30) NOT NULL,
  tolerancia_aplicada  numeric(8,4) NOT NULL,
  diferencias          jsonb NOT NULL,
  event_id             uuid NOT NULL,
  created_at           timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, match_id),
  CHECK ((estado = 'MATCH' AND jsonb_array_length(diferencias) = 0)
      OR (estado <> 'MATCH'))
);

CREATE TABLE payment_application (
  tenant_id               uuid NOT NULL,
  payment_application_id  uuid NOT NULL,
  invoice_id              uuid NOT NULL,
  project_id              uuid NOT NULL,
  subcontractor_id        uuid NOT NULL,
  amount_requested        numeric(18,2) NOT NULL,
  amount_approved         numeric(18,2),
  status                  varchar(30) NOT NULL,
  match_id                uuid,
  compliance_version_seen bigint,
  approval_route          varchar(30),
  aggregate_version       bigint NOT NULL DEFAULT 1,
  created_at              timestamptz NOT NULL DEFAULT now(),
  updated_at              timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, payment_application_id)
);

CREATE TABLE payment (
  tenant_id               uuid NOT NULL,
  payment_id              uuid NOT NULL,
  invoice_id              uuid NOT NULL,
  payment_application_id  uuid NOT NULL,
  project_id              uuid NOT NULL,
  subcontractor_id        uuid NOT NULL,
  amount                  numeric(18,2) NOT NULL,
  currency                char(3) NOT NULL,
  executed_at             timestamptz,
  status                  payment_status NOT NULL,
  compliance_version_seen bigint,
  compensation_case_id    uuid,
  compensation_state      varchar(30) NOT NULL DEFAULT 'NONE',
  aggregate_version       bigint NOT NULL DEFAULT 1,
  created_at              timestamptz NOT NULL DEFAULT now(),
  updated_at              timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, payment_id)
);

CREATE TABLE payment_read_model (
  tenant_id               uuid NOT NULL,
  payment_id              uuid NOT NULL,
  invoice_id              uuid NOT NULL,
  project_id              uuid NOT NULL,
  subcontractor_id        uuid NOT NULL,
  amount                  numeric(18,2) NOT NULL,
  status                  payment_status NOT NULL,
  executed_at             timestamptz,
  compliance_version_seen bigint,
  compensation_case_id    uuid,
  compensation_state      varchar(30) NOT NULL DEFAULT 'NONE',
  updated_at              timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, payment_id)
);

CREATE TYPE invalidity_type AS ENUM (
  'DOCUMENTO_FRAUDULENTO',
  'CERTIFICADO_VENCIDO_RETROACTIVO',
  'ERROR_ADMINISTRATIVO',
  'REVOCACION_POSTERIOR'
);
CREATE TABLE payment_invalidation (
  tenant_id         uuid NOT NULL,
  invalidation_id   uuid NOT NULL,
  payment_id        uuid NOT NULL,
  invalidity_type   invalidity_type NOT NULL,
  evidence_id       uuid NOT NULL,
  effective_date    date NOT NULL,
  amount            numeric(18,2) NOT NULL,
  contractual_basis text NOT NULL,
  detected_by       uuid NOT NULL,
  detected_at       timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, invalidation_id),
  UNIQUE (tenant_id, payment_id, invalidity_type, evidence_id)
);

ALTER TABLE purchase_order         ENABLE ROW LEVEL SECURITY;
ALTER TABLE purchase_order_line    ENABLE ROW LEVEL SECURITY;
ALTER TABLE goods_receipt          ENABLE ROW LEVEL SECURITY;
ALTER TABLE goods_receipt_line     ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice                ENABLE ROW LEVEL SECURITY;
ALTER TABLE invoice_line           ENABLE ROW LEVEL SECURITY;
ALTER TABLE three_way_match_result ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_application    ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment                ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_read_model     ENABLE ROW LEVEL SECURITY;
ALTER TABLE payment_invalidation   ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'purchase_order','purchase_order_line','goods_receipt','goods_receipt_line',
    'invoice','invoice_line','three_way_match_result','payment_application',
    'payment','payment_read_model','payment_invalidation'
  ]) LOOP
    EXECUTE format('CREATE POLICY ti_%I ON %I USING (tenant_id = current_setting(''app.tenant_id'')::uuid)', t, t);
  END LOOP;
END $$;
