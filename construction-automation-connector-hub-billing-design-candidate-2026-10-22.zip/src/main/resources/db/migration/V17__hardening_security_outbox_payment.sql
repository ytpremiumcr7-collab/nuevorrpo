-- V17: hardening de RLS, outbox y pagos pendientes.
-- El runtime no debe borrar tablas y el outbox necesita un claim transversal
-- acotado para que los workers no dependan de una conexión sin tenant.
REVOKE DELETE ON ALL TABLES IN SCHEMA public FROM app_user;
ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE DELETE ON TABLES FROM app_user;

CREATE OR REPLACE FUNCTION claim_projection_outbox(p_limit integer)
RETURNS TABLE (
  id uuid,
  tenant_id uuid,
  event_id uuid,
  aggregate_id uuid,
  aggregate_version bigint,
  event_type varchar,
  payload text,
  attempts smallint
)
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = pg_catalog, public
AS $$
DECLARE
  v_limit integer := LEAST(GREATEST(COALESCE(p_limit, 50), 1), 100);
BEGIN
  -- Si el worker murió al reclamar repetidamente el mismo evento, no se reintenta infinito.
  UPDATE public.projection_outbox o
     SET status = 'DEAD_LETTERED', dead_lettered_at = now(),
         last_error = COALESCE(o.last_error, 'Worker interrupted after retry limit')
   WHERE o.status IN ('PENDING', 'PROCESSING')
     AND o.next_retry_at <= now()
     AND o.attempts >= 8;

  RETURN QUERY
  WITH picked AS (
    SELECT o.id
      FROM public.projection_outbox o
     WHERE o.status IN ('PENDING', 'PROCESSING')
       AND o.next_retry_at <= now()
       AND o.attempts < 8
     ORDER BY o.next_retry_at, o.created_at
     LIMIT v_limit
     FOR UPDATE SKIP LOCKED
  )
  UPDATE public.projection_outbox o
     SET status = 'PROCESSING', attempts = (o.attempts + 1)::smallint,
         next_retry_at = now() + interval '5 minutes'
    FROM picked
   WHERE o.id = picked.id
  RETURNING o.id, o.tenant_id, o.event_id, o.aggregate_id,
            o.aggregate_version, o.event_type, o.payload::text, o.attempts;
END;
$$;
-- El worker es una credencial distinta de la que atiende HTTP.
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'outbox_worker') THEN
    CREATE ROLE outbox_worker WITH NOLOGIN NOSUPERUSER NOBYPASSRLS NOCREATEDB NOCREATEROLE;
  END IF;
END $$;
GRANT USAGE ON SCHEMA public TO outbox_worker;
GRANT SELECT, UPDATE ON public.projection_outbox TO outbox_worker;
REVOKE ALL ON FUNCTION claim_projection_outbox(integer) FROM PUBLIC;
REVOKE ALL ON FUNCTION claim_projection_outbox(integer) FROM app_user;
GRANT EXECUTE ON FUNCTION claim_projection_outbox(integer) TO outbox_worker;

-- Una solicitud de pago no puede generar pagos repetidos por reintentos del workflow.
CREATE UNIQUE INDEX IF NOT EXISTS ux_payment_one_per_application
  ON payment (tenant_id, payment_application_id);
