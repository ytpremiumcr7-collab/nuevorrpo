-- =====================================================================
-- V16: Identity por obra, plantillas documentales, puente integración
-- =====================================================================

CREATE TYPE project_role AS ENUM (
  'OWNER',
  'PROJECT_ENGINEER',
  'SAFETY_LEAD',
  'FINANCE',
  'COMPLIANCE_LEAD',
  'SUBCONTRACTOR_ADMIN',
  'VIEWER'
);

CREATE TABLE app_user (
  tenant_id   uuid NOT NULL,
  user_id     uuid NOT NULL,
  email       varchar(200) NOT NULL,
  display_name varchar(200) NOT NULL,
  password_hash varchar(200), -- bcrypt; null = solo SSO/API key
  active      boolean NOT NULL DEFAULT true,
  created_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, user_id),
  UNIQUE (tenant_id, email)
);
ALTER TABLE app_user ENABLE ROW LEVEL SECURITY;
CREATE POLICY ti_app_user ON app_user
  USING (tenant_id = current_setting('app.tenant_id')::uuid);

CREATE TABLE project_membership (
  tenant_id   uuid NOT NULL,
  project_id  uuid NOT NULL,
  user_id     uuid NOT NULL,
  role        project_role NOT NULL,
  active      boolean NOT NULL DEFAULT true,
  granted_at  timestamptz NOT NULL DEFAULT now(),
  granted_by  uuid,
  PRIMARY KEY (tenant_id, project_id, user_id, role)
);
ALTER TABLE project_membership ENABLE ROW LEVEL SECURITY;
CREATE POLICY ti_project_membership ON project_membership
  USING (tenant_id = current_setting('app.tenant_id')::uuid);

CREATE INDEX idx_membership_user ON project_membership (tenant_id, user_id)
  WHERE active = true;

-- API keys operativas (servicio a servicio / front)
CREATE TABLE api_credential (
  tenant_id     uuid NOT NULL,
  credential_id uuid NOT NULL,
  user_id       uuid NOT NULL,
  api_key_hash  varchar(128) NOT NULL,
  label         varchar(120) NOT NULL,
  active        boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  last_used_at  timestamptz,
  PRIMARY KEY (tenant_id, credential_id)
);
ALTER TABLE api_credential ENABLE ROW LEVEL SECURITY;
CREATE POLICY ti_api_credential ON api_credential
  USING (tenant_id = current_setting('app.tenant_id')::uuid);

-- Plantillas documentales (contratos, RFIs, cartas)
CREATE TABLE document_template (
  tenant_id     uuid NOT NULL,
  template_id   uuid NOT NULL,
  code          varchar(80) NOT NULL,
  name          varchar(200) NOT NULL,
  category      varchar(40) NOT NULL, -- CONTRACT, RFI, CO, LETTER, OSHA
  body_markdown text NOT NULL,
  variables_json jsonb NOT NULL DEFAULT '[]',
  version       int NOT NULL DEFAULT 1,
  active        boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, template_id),
  UNIQUE (tenant_id, code, version)
);
ALTER TABLE document_template ENABLE ROW LEVEL SECURITY;
CREATE POLICY ti_document_template ON document_template
  USING (tenant_id = current_setting('app.tenant_id')::uuid);

CREATE TABLE assembled_document (
  tenant_id     uuid NOT NULL,
  assembly_id   uuid NOT NULL,
  template_id   uuid NOT NULL,
  project_id    uuid,
  output_markdown text NOT NULL,
  variables_used  jsonb NOT NULL,
  assembled_by  uuid NOT NULL,
  assembled_at  timestamptz NOT NULL DEFAULT now(),
  document_id   uuid, -- si se materializó a storage
  PRIMARY KEY (tenant_id, assembly_id)
);
ALTER TABLE assembled_document ENABLE ROW LEVEL SECURITY;
CREATE POLICY ti_assembled_document ON assembled_document
  USING (tenant_id = current_setting('app.tenant_id')::uuid);

-- Puente integración (Procore / ERP) — outbox de sincronización
CREATE TYPE integration_system AS ENUM ('PROCORE', 'ERP_SAP', 'ERP_ORACLE', 'GENERIC_WEBHOOK');
CREATE TYPE integration_direction AS ENUM ('INBOUND', 'OUTBOUND');
CREATE TYPE integration_status AS ENUM ('PENDING', 'PROCESSING', 'SUCCEEDED', 'FAILED', 'DEAD');

CREATE TABLE integration_outbox (
  tenant_id     uuid NOT NULL,
  message_id    uuid NOT NULL,
  system        integration_system NOT NULL,
  direction     integration_direction NOT NULL,
  entity_type   varchar(60) NOT NULL,
  entity_id     uuid,
  payload       jsonb NOT NULL,
  status        integration_status NOT NULL DEFAULT 'PENDING',
  attempts      smallint NOT NULL DEFAULT 0,
  last_error    text,
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  created_at    timestamptz NOT NULL DEFAULT now(),
  processed_at  timestamptz,
  PRIMARY KEY (tenant_id, message_id)
);
ALTER TABLE integration_outbox ENABLE ROW LEVEL SECURITY;
CREATE POLICY ti_integration_outbox ON integration_outbox
  USING (tenant_id = current_setting('app.tenant_id')::uuid);

CREATE INDEX idx_integration_pending
  ON integration_outbox (next_attempt_at)
  WHERE status IN ('PENDING', 'FAILED') AND attempts < 8;

-- Mapeo IDs externos (Procore project id <-> our project_id)
CREATE TABLE external_id_map (
  tenant_id       uuid NOT NULL,
  system          integration_system NOT NULL,
  external_type   varchar(60) NOT NULL,
  external_id     varchar(120) NOT NULL,
  internal_type   varchar(60) NOT NULL,
  internal_id     uuid NOT NULL,
  synced_at       timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, system, external_type, external_id)
);
ALTER TABLE external_id_map ENABLE ROW LEVEL SECURITY;
CREATE POLICY ti_external_id_map ON external_id_map
  USING (tenant_id = current_setting('app.tenant_id')::uuid);

-- Seed plantillas mínimas (tenant-agnostic se inserta en runtime por seed service)
