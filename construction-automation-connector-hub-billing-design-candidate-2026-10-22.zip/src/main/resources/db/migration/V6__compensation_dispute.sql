CREATE TYPE compensation_state AS ENUM (
  'OPEN','EVIDENCE_VALIDATED','NOTIFIED','PLAN_SELECTED',
  'EXECUTING','RECOVERED','DISPUTED','WRITTEN_OFF','REVERSED'
);

CREATE TABLE compensation_case (
  tenant_id            uuid NOT NULL,
  compensation_case_id uuid NOT NULL,
  payment_id           uuid NOT NULL,
  invalidity_type      invalidity_type NOT NULL,
  evidence_id          uuid NOT NULL,
  subcontractor_id     uuid NOT NULL,
  project_id           uuid NOT NULL,
  amount_to_recover    numeric(18,2) NOT NULL,
  status               compensation_state NOT NULL DEFAULT 'OPEN',
  aggregate_version    bigint NOT NULL DEFAULT 1,
  created_at           timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, compensation_case_id),
  UNIQUE (tenant_id, payment_id, invalidity_type, evidence_id)
);

CREATE TABLE recovery_account (
  tenant_id        uuid NOT NULL,
  subcontractor_id uuid NOT NULL,
  project_id       uuid NOT NULL,
  saldo_pendiente  numeric(18,2) NOT NULL DEFAULT 0,
  version          bigint NOT NULL DEFAULT 0,
  PRIMARY KEY (tenant_id, subcontractor_id, project_id),
  CHECK (saldo_pendiente >= 0)
);

CREATE TABLE deduction_log (
  tenant_id        uuid NOT NULL,
  deduction_id     uuid NOT NULL,
  subcontractor_id uuid NOT NULL,
  project_id       uuid NOT NULL,
  amount           numeric(18,2) NOT NULL,
  applied_at       timestamptz NOT NULL DEFAULT now(),
  reversed         boolean NOT NULL DEFAULT false,
  reversed_at      timestamptz,
  PRIMARY KEY (tenant_id, deduction_id)
);

CREATE TYPE dispute_state AS ENUM (
  'NOTICE_PREPARED','NOTICE_SENT','AWAITING_ACKNOWLEDGMENT','ACKNOWLEDGED',
  'AWAITING_RESPONSE','NEGOTIATING','ESCALATED_TO_MEDIATION',
  'ESCALATED_TO_ARBITRATION','RESOLVED_CONTRACTOR','RESOLVED_SUBCONTRACTOR',
  'RESOLVED_PARTIAL','WITHDRAWN','LAPSED'
);
CREATE TYPE dispute_outcome AS ENUM (
  'CONTRACTOR_WINS_TOTAL','CONTRACTOR_WINS_PARTIAL',
  'SUBCONTRACTOR_WINS_TOTAL','SUBCONTRACTOR_WINS_PARTIAL',
  'WITHDRAWN','LAPSED'
);

CREATE TABLE dispute_case (
  tenant_id              uuid NOT NULL,
  dispute_case_id        uuid NOT NULL,
  compensation_case_id   uuid NOT NULL,
  payment_id             uuid NOT NULL,
  subcontractor_id       uuid NOT NULL,
  project_id             uuid NOT NULL,
  contract_id            uuid NOT NULL,
  estado                 dispute_state NOT NULL,
  version                bigint NOT NULL DEFAULT 1,
  jurisdiction           varchar(40) NOT NULL,
  contract_type          varchar(40) NOT NULL,
  notice_sent_at         timestamptz,
  acknowledgment_at      timestamptz,
  response_deadline      date NOT NULL,
  negotiation_deadline   date,
  arbitration_deadline   date,
  amount_claimed         numeric(18,2) NOT NULL,
  amount_in_dispute      numeric(18,2) NOT NULL,
  amount_recovered       numeric(18,2) NOT NULL DEFAULT 0,
  interest_accrued       numeric(18,2) NOT NULL DEFAULT 0,
  costs_allocated        numeric(18,2) NOT NULL DEFAULT 0,
  outcome                dispute_outcome,
  outcome_recorded_at    timestamptz,
  outcome_evidence_id    uuid,
  evidence_manifest_id   uuid NOT NULL,
  evidence_manifest_hash varchar(64) NOT NULL,
  created_at             timestamptz NOT NULL DEFAULT now(),
  updated_at             timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, dispute_case_id),
  UNIQUE (tenant_id, compensation_case_id)
);

CREATE TABLE business_calendar (
  jurisdiction_id varchar(40) NOT NULL,
  calendar_date   date NOT NULL,
  is_business_day boolean NOT NULL,
  holiday_name    varchar(120),
  source          varchar(80) NOT NULL,
  valid_from      timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (jurisdiction_id, calendar_date)
);

CREATE OR REPLACE FUNCTION add_business_days(p_jurisdiction varchar, p_start date, p_days int)
RETURNS date LANGUAGE plpgsql STABLE AS $$
DECLARE v date := p_start; v_added int := 0;
BEGIN
  WHILE NOT EXISTS (
    SELECT 1 FROM business_calendar WHERE jurisdiction_id = p_jurisdiction
      AND calendar_date = v AND is_business_day) LOOP
    v := v + 1;
  END LOOP;
  WHILE v_added < p_days LOOP
    v := v + 1;
    IF EXISTS (SELECT 1 FROM business_calendar WHERE jurisdiction_id = p_jurisdiction
               AND calendar_date = v AND is_business_day) THEN
      v_added := v_added + 1;
    END IF;
  END LOOP;
  RETURN v;
END;
$$;

CREATE OR REPLACE FUNCTION add_calendar_days(p_start date, p_days int)
RETURNS date LANGUAGE sql IMMUTABLE AS $$ SELECT p_start + p_days; $$;

CREATE TABLE legal_interest_rate (
  jurisdiction_id  varchar(40) NOT NULL,
  effective_from   date NOT NULL,
  effective_to     date,
  annual_rate      numeric(8,6) NOT NULL,
  source_reference varchar(200) NOT NULL,
  PRIMARY KEY (jurisdiction_id, effective_from)
);

CREATE TABLE evidence_manifest (
  tenant_id        uuid NOT NULL,
  manifest_id      uuid NOT NULL,
  dispute_case_id  uuid NOT NULL,
  manifest_version int NOT NULL DEFAULT 1,
  canonical_json   jsonb NOT NULL,
  hmac_sha256      varchar(88) NOT NULL,
  signing_key_id   varchar(80) NOT NULL,
  signed_at        timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, manifest_id)
);
CREATE TABLE evidence_manifest_document (
  tenant_id     uuid NOT NULL,
  manifest_id   uuid NOT NULL,
  document_id   uuid NOT NULL,
  document_type varchar(40) NOT NULL,
  sha256        varchar(64) NOT NULL,
  PRIMARY KEY (tenant_id, manifest_id, document_id)
);
CREATE TABLE evidence_manifest_chain_of_custody (
  tenant_id   uuid NOT NULL,
  access_id   bigserial PRIMARY KEY,
  manifest_id uuid NOT NULL,
  document_id uuid NOT NULL,
  accessed_by uuid NOT NULL,
  accessed_at timestamptz NOT NULL DEFAULT now(),
  purpose     varchar(60) NOT NULL,
  ip_address  inet
);

CREATE TABLE dispute_case_current (
  tenant_id                    uuid NOT NULL,
  dispute_case_id              uuid NOT NULL,
  compensation_case_id         uuid NOT NULL,
  payment_id                   uuid NOT NULL,
  subcontractor_id             uuid NOT NULL,
  project_id                   uuid NOT NULL,
  contract_id                  uuid NOT NULL,
  estado                       dispute_state NOT NULL,
  phase_started_at             timestamptz NOT NULL,
  outcome                      dispute_outcome,
  outcome_recorded_at          timestamptz,
  evidence_complete            boolean NOT NULL DEFAULT false,
  manifest_hash                varchar(64) NOT NULL DEFAULT '',
  last_evidence_access         timestamptz,
  amount_in_dispute_contract   numeric(18,2) NOT NULL,
  currency_code                char(3) NOT NULL DEFAULT 'USD',
  amount_in_dispute_functional numeric(18,2) NOT NULL,
  functional_fx_rate           numeric(12,6) NOT NULL DEFAULT 1,
  functional_fx_rate_date      date NOT NULL DEFAULT CURRENT_DATE,
  phase_deadline               date NOT NULL DEFAULT CURRENT_DATE,
  days_in_phase                int NOT NULL DEFAULT 0,
  business_days_remaining      int NOT NULL DEFAULT 0,
  sla_status                   varchar(15) NOT NULL DEFAULT 'ON_TRACK',
  next_action_type             varchar(40) NOT NULL DEFAULT 'NONE',
  next_action_owner_role       varchar(40) NOT NULL DEFAULT 'LEGAL',
  next_action_due_date         date,
  deadline_consequence         text,
  provision_functional         numeric(18,2) NOT NULL DEFAULT 0,
  provision_contract           numeric(18,2) NOT NULL DEFAULT 0,
  provision_dmn_version        varchar(20) NOT NULL DEFAULT 'v1',
  provision_reason             varchar(200) NOT NULL DEFAULT '',
  provision_as_of              date NOT NULL DEFAULT CURRENT_DATE,
  version                      bigint NOT NULL DEFAULT 1,
  created_at                   timestamptz NOT NULL DEFAULT now(),
  updated_at                   timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, dispute_case_id),
  UNIQUE (tenant_id, compensation_case_id)
);
CREATE INDEX idx_dc_priority ON dispute_case_current
  (tenant_id, next_action_owner_role, next_action_due_date, sla_status);

CREATE TABLE dispute_case_history (
  tenant_id        uuid NOT NULL,
  history_id       bigserial PRIMARY KEY,
  dispute_case_id  uuid NOT NULL,
  valid_from       timestamptz NOT NULL,
  estado           dispute_state NOT NULL,
  outcome          dispute_outcome,
  amount_in_dispute_contract numeric(18,2) NOT NULL,
  currency_code    char(3) NOT NULL,
  provision_functional numeric(18,2),
  version          bigint NOT NULL,
  source_event_id  uuid NOT NULL,
  source_event_type varchar(60) NOT NULL,
  projection_version varchar(20) NOT NULL
);
CREATE VIEW dispute_case_history_intervals AS
SELECT h.*, LEAD(h.valid_from) OVER (
  PARTITION BY h.tenant_id, h.dispute_case_id ORDER BY h.valid_from) AS valid_to
FROM dispute_case_history h;

CREATE TABLE dispute_provision_snapshot (
  tenant_id                  uuid NOT NULL,
  snapshot_date              date NOT NULL,
  dispute_case_id            uuid NOT NULL,
  snapshot_seq               smallint NOT NULL DEFAULT 0,
  is_adjustment              boolean NOT NULL DEFAULT false,
  adjustment_reason          varchar(200),
  project_id                 uuid NOT NULL,
  subcontractor_id           uuid NOT NULL,
  amount_in_dispute_contract numeric(18,2) NOT NULL,
  currency_code              char(3) NOT NULL,
  provision_contract         numeric(18,2) NOT NULL,
  provision_functional       numeric(18,2) NOT NULL,
  fx_rate                    numeric(12,6) NOT NULL,
  fx_rate_date               date NOT NULL,
  provision_dmn_version      varchar(20) NOT NULL,
  provision_reason           varchar(200) NOT NULL,
  prior_snapshot_date        date,
  revaluation_gain_loss      numeric(18,2),
  journal_entry_id           uuid,
  PRIMARY KEY (tenant_id, snapshot_date, dispute_case_id, snapshot_seq)
);

CREATE TABLE dispute_phase_config (
  contract_type varchar(40) NOT NULL,
  jurisdiction  varchar(40) NOT NULL,
  phase         varchar(30) NOT NULL,
  time_unit     varchar(15) NOT NULL CHECK (time_unit IN ('CALENDAR_DAYS','BUSINESS_DAYS')),
  duration      int NOT NULL CHECK (duration > 0),
  PRIMARY KEY (contract_type, jurisdiction, phase)
);
INSERT INTO dispute_phase_config VALUES
  ('FIDIC_RED_2017','*','NOTICE','CALENDAR_DAYS',28),
  ('FIDIC_RED_2017','*','RESPONSE','CALENDAR_DAYS',14),
  ('FIDIC_RED_2017','*','FULLY_DETAILED_CLAIM','CALENDAR_DAYS',84),
  ('FIDIC_RED_2017','*','DETERMINATION','CALENDAR_DAYS',42),
  ('FIDIC_RED_2017','*','DISSATISFACTION','CALENDAR_DAYS',28);

-- Tablas de configuración global (sin tenant_id): NO llevan RLS por tenant
-- business_calendar, legal_interest_rate, dispute_phase_config

ALTER TABLE compensation_case      ENABLE ROW LEVEL SECURITY;
ALTER TABLE recovery_account       ENABLE ROW LEVEL SECURITY;
ALTER TABLE deduction_log          ENABLE ROW LEVEL SECURITY;
ALTER TABLE dispute_case           ENABLE ROW LEVEL SECURITY;
ALTER TABLE evidence_manifest      ENABLE ROW LEVEL SECURITY;
ALTER TABLE evidence_manifest_document ENABLE ROW LEVEL SECURITY;
ALTER TABLE evidence_manifest_chain_of_custody ENABLE ROW LEVEL SECURITY;
ALTER TABLE dispute_case_current   ENABLE ROW LEVEL SECURITY;
ALTER TABLE dispute_case_history   ENABLE ROW LEVEL SECURITY;
ALTER TABLE dispute_provision_snapshot ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'compensation_case','recovery_account','deduction_log','dispute_case',
    'evidence_manifest','evidence_manifest_document',
    'evidence_manifest_chain_of_custody',
    'dispute_case_current','dispute_case_history','dispute_provision_snapshot'
  ]) LOOP
    EXECUTE format('CREATE POLICY ti_%I ON %I USING (tenant_id = current_setting(''app.tenant_id'')::uuid)', t, t);
  END LOOP;
END $$;
