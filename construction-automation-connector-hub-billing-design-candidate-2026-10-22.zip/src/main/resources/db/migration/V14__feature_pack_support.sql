-- =====================================================================
-- V14: Soporte para Document Storage, Notificaciones y Fase A Fixes
-- =====================================================================

-- ---------------------------------------------------------------------
-- Fix A1: Recovery Account (control de saldo)
-- Aseguramos que las cuentas se creen en 0 si no existen
-- (la lógica de incremento se maneja en el servicio).
-- ---------------------------------------------------------------------
-- (No requiere cambio de esquema, ya existe la tabla)

-- ---------------------------------------------------------------------
-- Fix A3: Change Orders -> Billing Projection
-- ---------------------------------------------------------------------
CREATE TABLE billing_contract_projection (
  tenant_id         uuid NOT NULL,
  contract_id       uuid NOT NULL,
  original_amount   numeric(18,2) NOT NULL,
  approved_co_amount numeric(18,2) NOT NULL DEFAULT 0,
  effective_amount  numeric(18,2) NOT NULL,
  updated_at        timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, contract_id)
);

ALTER TABLE billing_contract_projection ENABLE ROW LEVEL SECURITY;
CREATE POLICY ti_billing_contract ON billing_contract_projection
  USING (tenant_id = current_setting('app.tenant_id')::uuid);

-- ---------------------------------------------------------------------
-- Feature: Document Storage
-- ---------------------------------------------------------------------
ALTER TABLE document
  ADD COLUMN file_name varchar(300),
  ADD COLUMN content_type varchar(100),
  ADD COLUMN size_bytes bigint,
  ADD COLUMN storage_provider varchar(40) DEFAULT 'LOCAL',
  ADD COLUMN storage_key varchar(500);

-- ---------------------------------------------------------------------
-- Feature: Notification Worker (Retry & Errors)
-- ---------------------------------------------------------------------
ALTER TABLE notification_outbox
  ADD COLUMN retry_count smallint NOT NULL DEFAULT 0,
  ADD COLUMN last_error text,
  ADD COLUMN next_retry_at timestamptz NOT NULL DEFAULT now();

CREATE INDEX idx_notification_pending
  ON notification_outbox (next_retry_at)
  WHERE sent_at IS NULL AND retry_count < 5;
