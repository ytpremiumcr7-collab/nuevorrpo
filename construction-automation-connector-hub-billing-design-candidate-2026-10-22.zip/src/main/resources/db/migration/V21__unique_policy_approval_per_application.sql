-- V21: a retry must never create a second approved policy decision for one application.
CREATE UNIQUE INDEX ux_payment_approval_policy_once
  ON payment_approval_decision (tenant_id, payment_application_id)
  WHERE decision_source = 'POLICY' AND decision = 'APPROVED';
