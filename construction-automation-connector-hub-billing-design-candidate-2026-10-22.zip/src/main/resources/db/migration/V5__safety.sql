CREATE TYPE incident_severity AS ENUM
  ('NEAR_MISS','FIRST_AID','RECORDABLE','HOSPITALIZATION','AMPUTATION','FATALITY');
CREATE TYPE incident_status AS ENUM
  ('REPORTED','UNDER_INVESTIGATION','CORRECTIVE_ACTIONS_OPEN','CLOSED');
CREATE TYPE osha_recordability AS ENUM
  ('PENDING_CLASSIFICATION','RECORDABLE','NOT_RECORDABLE_WITH_JUSTIFICATION');

CREATE TABLE safety_incident (
  tenant_id          uuid NOT NULL,
  incident_id        uuid NOT NULL,
  project_id         uuid NOT NULL,
  site_id            uuid NOT NULL,
  reported_by        uuid NOT NULL,
  party_id           uuid,
  severity           incident_severity NOT NULL,
  status             incident_status NOT NULL DEFAULT 'REPORTED',
  occurred_at        timestamptz NOT NULL,
  reported_at        timestamptz NOT NULL,
  description        text NOT NULL,
  root_cause         text,
  osha_recordability osha_recordability NOT NULL DEFAULT 'PENDING_CLASSIFICATION',
  osha_justification text,
  osha_form_300_id   uuid,
  osha_form_301_id   uuid,
  aggregate_version  bigint NOT NULL DEFAULT 1,
  created_at         timestamptz NOT NULL DEFAULT now(),
  updated_at         timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, incident_id),
  CHECK (osha_recordability <> 'NOT_RECORDABLE_WITH_JUSTIFICATION'
         OR osha_justification IS NOT NULL)
);

CREATE TABLE corrective_action (
  tenant_id      uuid NOT NULL,
  action_id      uuid NOT NULL,
  incident_id    uuid NOT NULL,
  description    text NOT NULL,
  responsible_id uuid NOT NULL,
  due_date       date NOT NULL,
  completed_at   timestamptz,
  status         varchar(20) NOT NULL,
  PRIMARY KEY (tenant_id, action_id)
);

CREATE TABLE osha_300_log (
  tenant_id      uuid NOT NULL,
  log_id         uuid NOT NULL,
  project_id     uuid NOT NULL,
  calendar_year  int NOT NULL,
  entries        jsonb NOT NULL,
  retained_until date NOT NULL,
  PRIMARY KEY (tenant_id, log_id),
  UNIQUE (tenant_id, project_id, calendar_year)
);

CREATE TABLE osha_form_300 (
  tenant_id   uuid NOT NULL,
  form_id     uuid NOT NULL,
  incident_id uuid NOT NULL,
  payload     jsonb NOT NULL,
  PRIMARY KEY (tenant_id, form_id)
);
CREATE TABLE osha_form_301 (
  tenant_id   uuid NOT NULL,
  form_id     uuid NOT NULL,
  incident_id uuid NOT NULL,
  payload     jsonb NOT NULL,
  PRIMARY KEY (tenant_id, form_id)
);

CREATE TABLE notification_outbox (
  tenant_id       uuid NOT NULL,
  notification_id uuid NOT NULL,
  recipient_role  varchar(60) NOT NULL,
  subject         varchar(200) NOT NULL,
  body            text NOT NULL,
  created_at      timestamptz NOT NULL DEFAULT now(),
  sent_at         timestamptz,
  PRIMARY KEY (tenant_id, notification_id)
);

ALTER TABLE safety_incident   ENABLE ROW LEVEL SECURITY;
ALTER TABLE corrective_action ENABLE ROW LEVEL SECURITY;
ALTER TABLE osha_300_log      ENABLE ROW LEVEL SECURITY;
ALTER TABLE osha_form_300     ENABLE ROW LEVEL SECURITY;
ALTER TABLE osha_form_301     ENABLE ROW LEVEL SECURITY;
ALTER TABLE notification_outbox ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'safety_incident','corrective_action','osha_300_log',
    'osha_form_300','osha_form_301','notification_outbox'
  ]) LOOP
    EXECUTE format('CREATE POLICY ti_%I ON %I USING (tenant_id = current_setting(''app.tenant_id'')::uuid)', t, t);
  END LOOP;
END $$;
