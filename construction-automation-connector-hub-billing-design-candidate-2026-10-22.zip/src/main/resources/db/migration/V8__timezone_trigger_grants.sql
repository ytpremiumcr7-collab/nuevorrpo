CREATE OR REPLACE FUNCTION enforce_timezone_immutability()
RETURNS trigger AS $$
BEGIN
  IF OLD.timezone IS DISTINCT FROM NEW.timezone
     AND EXISTS (
       SELECT 1 FROM payment_read_model
        WHERE project_id = OLD.project_id AND status = 'EXECUTED')
  THEN
    RAISE EXCEPTION 'Timezone is immutable after first approved payment (project %)',
      OLD.project_id;
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_timezone_immutable
  BEFORE UPDATE OF timezone ON project
  FOR EACH ROW EXECUTE FUNCTION enforce_timezone_immutability();

-- Grants globales a app_user (no superuser, no bypassrls)
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO app_user;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO app_user;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA public TO app_user;

-- Semilla mínima de calendario (MX_CDMX 2025): lun-vie = business day (DOW 1-5)
INSERT INTO business_calendar (jurisdiction_id, calendar_date, is_business_day, source)
SELECT 'MX_CDMX', d::date,
       EXTRACT(DOW FROM d) BETWEEN 1 AND 5,
       'SEED'
  FROM generate_series('2025-01-01'::date, '2025-12-31'::date, '1 day') d
  ON CONFLICT DO NOTHING;
