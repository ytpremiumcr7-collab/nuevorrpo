-- =====================================================================
-- V10: tablas que los delegates de Partes 1-2 ya usaban
--      sin que existieran en Flyway. Sin esto, los BPMN fallan en runtime.
-- =====================================================================

-- ---------------------------------------------------------------------
-- ProjectDocuments: RFI / ChangeOrder / Submittal
-- ---------------------------------------------------------------------
CREATE TYPE rfi_status AS ENUM (
  'DRAFT','ROUTED','ASSIGNED','RESPONDED','ESCALATED','CLOSED','CANCELLED'
);

CREATE TABLE rfi (
  tenant_id        uuid NOT NULL,
  rfi_id           uuid NOT NULL,
  project_id       uuid NOT NULL,
  work_package_id  uuid,
  rfi_number       varchar(40) NOT NULL,
  title            varchar(300) NOT NULL,
  description      text NOT NULL,
  status           rfi_status NOT NULL DEFAULT 'DRAFT',
  assigned_to_role varchar(60),
  assigned_to      uuid,
  deadline         date,
  responded_at     timestamptz,
  responded_by     uuid,
  response_text    text,
  document_id      uuid,
  created_by       uuid NOT NULL,
  aggregate_version bigint NOT NULL DEFAULT 1,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, rfi_id),
  UNIQUE (tenant_id, project_id, rfi_number)
);
CREATE INDEX idx_rfi_status ON rfi (tenant_id, project_id, status);
CREATE INDEX idx_rfi_assigned ON rfi (tenant_id, assigned_to_role)
  WHERE status IN ('ROUTED','ASSIGNED');

-- Política determinista de asignación (no se inventa en runtime)
-- Surrogate PK: project_id/work_package_id pueden ser NULL (fallback)
CREATE TABLE rfi_routing_policy (
  tenant_id        uuid NOT NULL,
  policy_id        uuid NOT NULL DEFAULT gen_random_uuid(),
  project_id       uuid,
  work_package_id  uuid,
  assigned_to_role varchar(60) NOT NULL,
  priority         int NOT NULL DEFAULT 100,
  PRIMARY KEY (tenant_id, policy_id)
);
-- Unicidad lógica: un solo fallback global, uno por project, uno por WP
CREATE UNIQUE INDEX uq_rfi_routing_global
  ON rfi_routing_policy (tenant_id)
  WHERE project_id IS NULL AND work_package_id IS NULL;
CREATE UNIQUE INDEX uq_rfi_routing_project
  ON rfi_routing_policy (tenant_id, project_id)
  WHERE project_id IS NOT NULL AND work_package_id IS NULL;
CREATE UNIQUE INDEX uq_rfi_routing_wp
  ON rfi_routing_policy (tenant_id, project_id, work_package_id)
  WHERE work_package_id IS NOT NULL;

CREATE TYPE change_order_status AS ENUM (
  'DRAFT','SUBMITTED','UNDER_REVIEW','APPROVED','REJECTED','IMPLEMENTED','CANCELLED'
);

CREATE TABLE change_order (
  tenant_id         uuid NOT NULL,
  change_order_id   uuid NOT NULL,
  project_id        uuid NOT NULL,
  contract_id       uuid NOT NULL,
  work_package_id   uuid,
  co_number         varchar(40) NOT NULL,
  title             varchar(300) NOT NULL,
  justification     text NOT NULL,
  amount            numeric(18,2) NOT NULL,
  status            change_order_status NOT NULL DEFAULT 'DRAFT',
  approval_group    varchar(60),
  approved_by       uuid,
  approved_at       timestamptz,
  linked_rfi_id     uuid,
  created_by        uuid NOT NULL,
  aggregate_version bigint NOT NULL DEFAULT 1,
  created_at        timestamptz NOT NULL DEFAULT now(),
  updated_at        timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, change_order_id),
  UNIQUE (tenant_id, project_id, co_number)
);

CREATE TYPE submittal_status AS ENUM (
  'DRAFT','SUBMITTED','APPROVED','APPROVED_AS_NOTED','REVISE_AND_RESUBMIT','REJECTED'
);

CREATE TABLE submittal (
  tenant_id      uuid NOT NULL,
  submittal_id   uuid NOT NULL,
  project_id     uuid NOT NULL,
  work_package_id uuid,
  submittal_number varchar(40) NOT NULL,
  title          varchar(300) NOT NULL,
  status         submittal_status NOT NULL DEFAULT 'DRAFT',
  document_id    uuid NOT NULL,
  reviewer_role  varchar(60),
  reviewed_at    timestamptz,
  created_by     uuid NOT NULL,
  aggregate_version bigint NOT NULL DEFAULT 1,
  created_at     timestamptz NOT NULL DEFAULT now(),
  updated_at     timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, submittal_id),
  UNIQUE (tenant_id, project_id, submittal_number)
);

-- ---------------------------------------------------------------------
-- Bidding
-- ---------------------------------------------------------------------
CREATE TYPE bid_package_status AS ENUM (
  'DRAFT','OPEN','RECEIVING','EVALUATING','AWARDED','CANCELLED'
);
CREATE TYPE bid_status AS ENUM (
  'RECEIVED','DISQUALIFIED','SELECTED','NOT_SELECTED'
);

CREATE TABLE bid_package (
  tenant_id       uuid NOT NULL,
  bid_package_id  uuid NOT NULL,
  project_id      uuid NOT NULL,
  work_package_id uuid,
  name            varchar(300) NOT NULL,
  status          bid_package_status NOT NULL DEFAULT 'DRAFT',
  bid_deadline    timestamptz,
  awarded_bid_id  uuid,
  awarded_at      timestamptz,
  created_by      uuid NOT NULL,
  aggregate_version bigint NOT NULL DEFAULT 1,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, bid_package_id)
);

CREATE TABLE bid (
  tenant_id       uuid NOT NULL,
  bid_id          uuid NOT NULL,
  bid_package_id  uuid NOT NULL,
  bidder_id       uuid NOT NULL,
  amount          numeric(18,2) NOT NULL,
  currency        char(3) NOT NULL DEFAULT 'USD',
  status          bid_status NOT NULL DEFAULT 'RECEIVED',
  submitted_at    timestamptz NOT NULL DEFAULT now(),
  document_id     uuid,
  PRIMARY KEY (tenant_id, bid_id)
);
CREATE INDEX idx_bid_by_package ON bid (tenant_id, bid_package_id, amount);

-- ---------------------------------------------------------------------
-- Permits
-- ---------------------------------------------------------------------
CREATE TYPE permit_status AS ENUM (
  'DRAFT','SUBMITTED','IN_REVIEW','OBSERVED','APPROVED','DENIED','EXPIRED','CANCELLED'
);

CREATE TABLE permit_application (
  tenant_id       uuid NOT NULL,
  permit_id       uuid NOT NULL,
  project_id      uuid NOT NULL,
  site_id         uuid,
  jurisdiction    varchar(40) NOT NULL,
  permit_type     varchar(60) NOT NULL,
  permit_number   varchar(80),
  status          permit_status NOT NULL DEFAULT 'DRAFT',
  submitted_at    timestamptz,
  authority_ref   varchar(120),
  deadline        date,
  approved_at     timestamptz,
  valid_until     date,
  document_id     uuid,
  created_by      uuid NOT NULL,
  aggregate_version bigint NOT NULL DEFAULT 1,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, permit_id)
);
CREATE INDEX idx_permit_status ON permit_application (tenant_id, project_id, status);

-- ---------------------------------------------------------------------
-- RLS en todas las tablas nuevas
-- ---------------------------------------------------------------------
ALTER TABLE rfi                    ENABLE ROW LEVEL SECURITY;
ALTER TABLE rfi_routing_policy     ENABLE ROW LEVEL SECURITY;
ALTER TABLE change_order           ENABLE ROW LEVEL SECURITY;
ALTER TABLE submittal              ENABLE ROW LEVEL SECURITY;
ALTER TABLE bid_package            ENABLE ROW LEVEL SECURITY;
ALTER TABLE bid                    ENABLE ROW LEVEL SECURITY;
ALTER TABLE permit_application     ENABLE ROW LEVEL SECURITY;

DO $$
DECLARE t text;
BEGIN
  FOR t IN SELECT unnest(ARRAY[
    'rfi','rfi_routing_policy','change_order','submittal',
    'bid_package','bid','permit_application'
  ]) LOOP
    EXECUTE format(
      'CREATE POLICY ti_%I ON %I USING (tenant_id = current_setting(''app.tenant_id'')::uuid)',
      t, t);
  END LOOP;
END $$;

-- ---------------------------------------------------------------------
-- Semilla de política de asignación para el tenant default
-- ---------------------------------------------------------------------
INSERT INTO rfi_routing_policy
  (tenant_id, project_id, work_package_id, assigned_to_role, priority)
SELECT '00000000-0000-0000-0000-000000000001', NULL, NULL, 'PROJECT_ENGINEER', 100
WHERE NOT EXISTS (
  SELECT 1 FROM rfi_routing_policy
   WHERE tenant_id = '00000000-0000-0000-0000-000000000001'
     AND project_id IS NULL AND work_package_id IS NULL
);
