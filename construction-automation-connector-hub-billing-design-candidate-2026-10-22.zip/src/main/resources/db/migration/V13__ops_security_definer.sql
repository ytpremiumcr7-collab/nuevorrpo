-- Funciones operativas que bypasean RLS (SECURITY DEFINER) para health/metrics.
-- Solo lectura agregada; no exponen filas de tenant.

CREATE OR REPLACE FUNCTION ops_outbox_dlq_count()
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(*) FROM projection_outbox WHERE status = 'DEAD_LETTERED';
$$;

CREATE OR REPLACE FUNCTION ops_outbox_pending_count()
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(*) FROM projection_outbox WHERE status = 'PENDING';
$$;

CREATE OR REPLACE FUNCTION ops_outbox_stuck_count()
RETURNS bigint
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT count(*) FROM projection_outbox
   WHERE status IN ('PENDING','PROCESSING')
     AND created_at < now() - interval '5 minutes';
$$;

GRANT EXECUTE ON FUNCTION ops_outbox_dlq_count() TO app_user;
GRANT EXECUTE ON FUNCTION ops_outbox_pending_count() TO app_user;
GRANT EXECUTE ON FUNCTION ops_outbox_stuck_count() TO app_user;
