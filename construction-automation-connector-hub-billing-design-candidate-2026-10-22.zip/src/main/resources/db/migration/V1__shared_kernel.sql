CREATE TABLE tenant (
  tenant_id  uuid PRIMARY KEY,
  name       varchar(200) NOT NULL,
  active     boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO tenant VALUES ('00000000-0000-0000-0000-000000000001',
                           'default', true, now());

CREATE TABLE project (
  tenant_id   uuid NOT NULL,
  project_id  uuid NOT NULL,
  name        varchar(200) NOT NULL,
  timezone    varchar(60) NOT NULL,
  status      varchar(30) NOT NULL,
  start_date  date,
  end_date    date,
  created_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, project_id)
);

CREATE TABLE party (
  tenant_id  uuid NOT NULL,
  party_id   uuid NOT NULL,
  legal_name varchar(300) NOT NULL,
  tax_id     varchar(50),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, party_id)
);

CREATE TABLE party_role (
  tenant_id  uuid NOT NULL,
  party_id   uuid NOT NULL,
  role       varchar(50) NOT NULL,
  valid_from timestamptz NOT NULL DEFAULT now(),
  valid_to   timestamptz,
  PRIMARY KEY (tenant_id, party_id, role, valid_from)
);

CREATE TABLE site (
  tenant_id    uuid NOT NULL,
  site_id      uuid NOT NULL,
  project_id   uuid NOT NULL,
  jurisdiction varchar(40) NOT NULL,
  coordinates  point,
  PRIMARY KEY (tenant_id, site_id)
);

CREATE TABLE contract (
  tenant_id      uuid NOT NULL,
  contract_id    uuid NOT NULL,
  project_id     uuid NOT NULL,
  amount         numeric(18,2) NOT NULL,
  currency       char(3) NOT NULL,
  contract_type  varchar(40) NOT NULL,
  effective_from date NOT NULL,
  effective_to   date,
  PRIMARY KEY (tenant_id, contract_id)
);

CREATE TABLE contract_party (
  tenant_id        uuid NOT NULL,
  contract_id      uuid NOT NULL,
  party_id         uuid NOT NULL,
  role_in_contract varchar(40) NOT NULL,
  PRIMARY KEY (tenant_id, contract_id, party_id)
);

CREATE TABLE work_package (
  tenant_id       uuid NOT NULL,
  work_package_id uuid NOT NULL,
  project_id      uuid NOT NULL,
  contract_id     uuid NOT NULL,
  discipline      varchar(80),
  location        varchar(120),
  PRIMARY KEY (tenant_id, work_package_id)
);

CREATE TABLE document (
  tenant_id       uuid NOT NULL,
  document_id     uuid NOT NULL,
  project_id      uuid NOT NULL,
  work_package_id uuid,
  mime_type       varchar(100),
  sha256          varchar(64) NOT NULL,
  author_id       uuid,
  version         int NOT NULL DEFAULT 1,
  created_at      timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, document_id)
);
CREATE INDEX idx_doc_project ON document (tenant_id, project_id);

CREATE TABLE shared_kernel_party_map (
  tenant_id     uuid NOT NULL,
  legacy_system varchar(40) NOT NULL,
  legacy_id     varchar(80) NOT NULL,
  new_party_id  uuid NOT NULL,
  merged_at     timestamptz NOT NULL DEFAULT now(),
  merged_by     uuid NOT NULL,
  PRIMARY KEY (tenant_id, legacy_system, legacy_id)
);

-- Audit con hash chain verificable
CREATE TABLE audit_event (
  tenant_id       uuid NOT NULL,
  sequence_number bigserial NOT NULL,
  event_id        uuid NOT NULL,
  event_type      varchar(60) NOT NULL,
  aggregate_type  varchar(40) NOT NULL,
  aggregate_id    uuid NOT NULL,
  actor_id        uuid,
  correlation_id  uuid,
  payload         jsonb NOT NULL,
  prev_hash       varchar(64),
  event_hash      varchar(64) NOT NULL,
  recorded_at     timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, sequence_number)
);
CREATE INDEX idx_audit_aggregate ON audit_event (tenant_id, aggregate_type, aggregate_id);

CREATE OR REPLACE FUNCTION compute_event_hash(p_prev varchar, p_payload jsonb)
RETURNS varchar LANGUAGE sql IMMUTABLE AS $$
  SELECT encode(
    sha256(convert_to(coalesce(p_prev,'') || p_payload::text, 'UTF8')), 'hex');
$$;

CREATE OR REPLACE FUNCTION verify_audit_chain(p_tenant uuid)
RETURNS TABLE(broken_at bigint) LANGUAGE sql STABLE AS $$
  SELECT a.sequence_number FROM audit_event a
    LEFT JOIN audit_event prev
      ON prev.tenant_id = a.tenant_id
     AND prev.sequence_number = a.sequence_number - 1
   WHERE a.tenant_id = p_tenant
     AND a.prev_hash IS DISTINCT FROM coalesce(prev.event_hash, '')
   ORDER BY a.sequence_number;
$$;
