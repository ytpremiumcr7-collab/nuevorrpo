-- V20: isolate Camunda engine tables from application tables and public schema privileges.
-- Existing public-schema engine tables require an explicit, reviewed migration; never silently fork history.
DO $$
BEGIN
  IF EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_schema = 'public' AND table_name LIKE 'ACT\_%' ESCAPE '\'
  ) THEN
    RAISE EXCEPTION 'V20 blocked: Camunda tables exist in public; migrate them to schema camunda with a reviewed maintenance plan first';
  END IF;
END $$;
CREATE SCHEMA IF NOT EXISTS camunda;
REVOKE CREATE ON SCHEMA public FROM app_user;
GRANT USAGE, CREATE ON SCHEMA camunda TO app_user;
