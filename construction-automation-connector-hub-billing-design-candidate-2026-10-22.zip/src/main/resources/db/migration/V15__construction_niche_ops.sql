-- Operaciones del nicho construcción: alertas de vencimiento compliance + daily reports

ALTER TABLE compliance_requirement
  ADD COLUMN IF NOT EXISTS expiry_alerted_at timestamptz,
  ADD COLUMN IF NOT EXISTS expiry_alert_level smallint NOT NULL DEFAULT 0;
  -- 0=none, 1=30d, 2=7d, 3=expired

CREATE TYPE daily_report_status AS ENUM ('DRAFT','SUBMITTED','REVIEWED','ARCHIVED');

CREATE TABLE IF NOT EXISTS daily_report (
  tenant_id       uuid NOT NULL,
  report_id       uuid NOT NULL,
  project_id      uuid NOT NULL,
  site_id         uuid,
  report_date     date NOT NULL,
  weather         varchar(80),
  workforce_count int,
  summary         text NOT NULL,
  status          daily_report_status NOT NULL DEFAULT 'DRAFT',
  document_id     uuid,
  submitted_by    uuid NOT NULL,
  submitted_at    timestamptz,
  aggregate_version bigint NOT NULL DEFAULT 1,
  created_at      timestamptz NOT NULL DEFAULT now(),
  updated_at      timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, report_id),
  UNIQUE (tenant_id, project_id, report_date)
);

ALTER TABLE daily_report ENABLE ROW LEVEL SECURITY;
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_policies WHERE tablename = 'daily_report' AND policyname = 'ti_daily_report'
  ) THEN
    CREATE POLICY ti_daily_report ON daily_report
      USING (tenant_id = current_setting('app.tenant_id')::uuid);
  END IF;
END $$;

CREATE INDEX IF NOT EXISTS idx_compliance_expiring
  ON compliance_requirement (tenant_id, fecha_vencimiento)
  WHERE estado_verificacion = 'VERIFICADO';
