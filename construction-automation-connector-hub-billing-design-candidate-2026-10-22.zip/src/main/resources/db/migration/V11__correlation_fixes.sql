-- =====================================================================
-- V11: correcciones que la Parte 2 dejó pendientes
-- =====================================================================

-- 1) Índices que los jobs diarios usan y no existían
CREATE INDEX IF NOT EXISTS idx_dispute_lapsed
  ON dispute_case (tenant_id, estado, response_deadline)
  WHERE estado IN ('AWAITING_ACKNOWLEDGMENT','AWAITING_RESPONSE');

CREATE INDEX IF NOT EXISTS idx_safety_open_incidents
  ON safety_incident (tenant_id, status, occurred_at)
  WHERE status IN ('REPORTED','UNDER_INVESTIGATION','CORRECTIVE_ACTIONS_OPEN');

-- 2) Columna que el OshaDeadlineSweepJob necesita para no duplicar alertas
ALTER TABLE safety_incident
  ADD COLUMN IF NOT EXISTS osha_deadline_alerted_at timestamptz,
  ADD COLUMN IF NOT EXISTS osha_reported_at timestamptz;

-- 3) Comentario de negocio en la tabla de auditoría para que un DBA entienda
COMMENT ON TABLE audit_event IS
  'Append-only. La cadena se verifica con verify_audit_chain(tenant_id). '
  'No se permite UPDATE ni DELETE: los triggers lo bloquean en producción.';

-- 4) Trigger defensivo: audit_event append-only real
CREATE OR REPLACE FUNCTION block_audit_mutation()
RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'audit_event es append-only (%). No se permite % en producción.',
    TG_TABLE_NAME, TG_OP;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_audit_no_update ON audit_event;
CREATE TRIGGER trg_audit_no_update
  BEFORE UPDATE OR DELETE ON audit_event
  FOR EACH ROW EXECUTE FUNCTION block_audit_mutation();
