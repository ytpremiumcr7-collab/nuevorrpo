package com.tuempresa.safety.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Garantía OSHA real: barrido cada hora de incidentes abiertos cuyo
 * plazo regulatorio (8h fatalidad / 24h hospitalización) venció sin
 * haber sido reportados. Emite alerta única por incidente.
 *
 * Los timers BPMN son recordatorio dentro del proceso; este job es la
 * garantía operativa independiente del estado del proceso.
 */
@Component
public class OshaDeadlineSweepJob {

    private static final Logger log = LoggerFactory.getLogger(OshaDeadlineSweepJob.class);
    private final JdbcTemplate jdbc;

    public OshaDeadlineSweepJob(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Scheduled(cron = "0 0 * * * *", zone = "UTC")
    @Transactional
    public void sweep() {
        List<UUID> tenants = jdbc.queryForList(
            "SELECT tenant_id FROM tenant WHERE active = true", UUID.class);

        for (UUID tenant : tenants) {
            jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
            sweepForTenant(tenant);
        }
    }

    private void sweepForTenant(UUID tenant) {
        // Plazo desde occurred_at, no desde reported_at (corrección OSHA real)
        List<Map<String,Object>> overdue = jdbc.queryForList("""
            SELECT incident_id, severity, occurred_at,
                   EXTRACT(EPOCH FROM (now() - occurred_at)) / 3600.0 AS hours_elapsed
              FROM safety_incident
             WHERE tenant_id = ?
               AND status IN ('REPORTED','UNDER_INVESTIGATION')
               AND osha_reported_at IS NULL
               AND osha_deadline_alerted_at IS NULL
               AND (
                 (severity = 'FATALITY' AND occurred_at < now() - interval '8 hours')
                 OR (severity IN ('HOSPITALIZATION','AMPUTATION')
                     AND occurred_at < now() - interval '24 hours')
               )
            """, tenant);

        for (var row : overdue) {
            UUID id = (UUID) row.get("incident_id");
            jdbc.update(
                "INSERT INTO notification_outbox " +
                "(tenant_id, notification_id, recipient_role, subject, body) " +
                "VALUES (?, ?, 'SAFETY_LEAD', ?, ?)",
                tenant, UUID.randomUUID(),
                "OSHA deadline breached: " + row.get("severity"),
                "Incidente " + id + " con " + row.get("hours_elapsed") +
                " horas sin reportar a OSHA. Plazo máximo excedido.");
            jdbc.update(
                "UPDATE safety_incident SET osha_deadline_alerted_at = now(), " +
                "aggregate_version = aggregate_version + 1 " +
                "WHERE tenant_id = ? AND incident_id = ?",
                tenant, id);
            log.error("OSHA deadline breached: tenant={}, incident={}, severity={}, hours={}",
                tenant, id, row.get("severity"), row.get("hours_elapsed"));
        }
    }
}
