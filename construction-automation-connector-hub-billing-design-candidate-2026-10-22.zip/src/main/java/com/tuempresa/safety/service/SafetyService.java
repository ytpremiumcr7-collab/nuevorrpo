package com.tuempresa.safety.service;

import com.tuempresa.platform.tenant.TenantContext;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class SafetyService {

    private final JdbcTemplate jdbc;
    private final RuntimeService runtimeService;

    public SafetyService(JdbcTemplate jdbc, RuntimeService runtimeService) {
        this.jdbc = jdbc; this.runtimeService = runtimeService;
    }

    @Transactional
    public UUID report(UUID projectId, UUID siteId, UUID reportedBy, UUID partyId,
                       String severity, Instant occurredAt, String description) {
        if (occurredAt.isAfter(Instant.now())) {
            throw new IllegalArgumentException(
                "occurredAt no puede ser futuro: " + occurredAt);
        }
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        // Clasificación inicial determinista: recordable si severidad lo implica
        String recordability = switch (severity) {
            case "FATALITY", "HOSPITALIZATION", "AMPUTATION", "RECORDABLE"
                -> "RECORDABLE";
            case "FIRST_AID", "NEAR_MISS"
                -> "PENDING_CLASSIFICATION";
            default -> throw new IllegalArgumentException(
                "Severidad inválida: " + severity);
        };

        UUID incidentId = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO safety_incident
              (tenant_id, incident_id, project_id, site_id, reported_by, party_id,
               severity, status, occurred_at, reported_at, description, osha_recordability)
            VALUES (?, ?, ?, ?, ?, ?, ?::incident_severity, 'REPORTED'::incident_status,
                    ?, now(), ?, ?::osha_recordability)
            """,
            tenant, incidentId, projectId, siteId, reportedBy, partyId,
            severity, java.sql.Timestamp.from(occurredAt), description, recordability);

        Map<String, Object> vars = new HashMap<>();
        vars.put("tenantId", tenant);
        vars.put("incidentId", incidentId);
        vars.put("projectId", projectId);
        vars.put("severity", severity);
        vars.put("occurredAt", occurredAt.toString());

        runtimeService.startProcessInstanceByKey(
            "incidentReportProcess", incidentId.toString(), vars);
        return incidentId;
    }

    @Transactional
    public void markOshaReported(UUID incidentId) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        int updated = jdbc.update(
            "UPDATE safety_incident SET osha_reported_at = now(), " +
            "aggregate_version = aggregate_version + 1, updated_at = now() " +
            "WHERE tenant_id = ? AND incident_id = ?",
            tenant, incidentId);
        if (updated == 0) throw new IllegalStateException(
            "Incidente " + incidentId + " no encontrado");
    }
}
