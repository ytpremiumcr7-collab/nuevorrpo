package com.tuempresa.safety.web;

import com.tuempresa.identity.security.UserContext;
import com.tuempresa.identity.service.ProjectAuthorizationService;
import com.tuempresa.safety.service.SafetyService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/safety/incidents")
public class SafetyController {
    private final SafetyService service;
    private final ProjectAuthorizationService authorization;
    public SafetyController(SafetyService service, ProjectAuthorizationService authorization) {
        this.service = service; this.authorization = authorization;
    }

    @PostMapping
    public ResponseEntity<?> report(@RequestBody Map<String,Object> body) {
        UUID projectId = UUID.fromString((String) body.get("projectId"));
        authorization.requireProjectRole(projectId, UserContext.ProjectRole.OWNER, UserContext.ProjectRole.SAFETY_LEAD);
        UUID id = service.report(projectId, UUID.fromString((String) body.get("siteId")),
            UserContext.require().userId(), body.get("partyId") == null ? null : UUID.fromString((String) body.get("partyId")),
            (String) body.get("severity"), Instant.parse((String) body.get("occurredAt")), (String) body.get("description"));
        return ResponseEntity.ok(Map.of("incidentId", id));
    }

    @PostMapping("/{id}/osha-reported")
    public ResponseEntity<?> markOshaReported(@PathVariable UUID id) {
        authorization.requireEntityProject(ProjectAuthorizationService.Resource.INCIDENT, id,
            UserContext.ProjectRole.OWNER, UserContext.ProjectRole.SAFETY_LEAD);
        service.markOshaReported(id);
        return ResponseEntity.ok().build();
    }
}
