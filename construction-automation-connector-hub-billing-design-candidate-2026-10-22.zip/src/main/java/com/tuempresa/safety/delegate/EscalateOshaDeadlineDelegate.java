package com.tuempresa.safety.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component("escalateOshaDeadlineDelegate")
public class EscalateOshaDeadlineDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    public EscalateOshaDeadlineDelegate(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = (UUID) execution.getVariable("tenantId");
        UUID incidentId = (UUID) execution.getVariable("incidentId");
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        jdbc.update(
            "INSERT INTO notification_outbox " +
            "(tenant_id, notification_id, recipient_role, subject, body) " +
            "VALUES (?, ?, 'SAFETY_LEAD', ?, ?)",
            tenant, UUID.randomUUID(),
            "OSHA report deadline breached",
            "Incidente " + incidentId + " no reportado a OSHA en el plazo legal");
        // Marcar en el incidente para auditoría
        jdbc.update("UPDATE safety_incident SET aggregate_version = aggregate_version + 1, " +
            "updated_at = now() WHERE tenant_id = ? AND incident_id = ?",
            tenant, incidentId);
    }
}
