package com.tuempresa.safety.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.UUID;

/**
 * Corregido: ya no shadowea java.util.Set.
 * Fail-loud si la severidad no es una de las soportadas.
 */
@Component("classifyIncidentDelegate")
public class ClassifyIncidentDelegate implements JavaDelegate {

    private static final java.util.Set<String> VALID_SEVERITIES = java.util.Set.of(
        "NEAR_MISS","FIRST_AID","RECORDABLE","HOSPITALIZATION","AMPUTATION","FATALITY");

    private final JdbcTemplate jdbc;
    public ClassifyIncidentDelegate(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = (UUID) execution.getVariable("tenantId");
        UUID incidentId = (UUID) execution.getVariable("incidentId");
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        String severity = jdbc.queryForObject(
            "SELECT severity FROM safety_incident " +
            "WHERE tenant_id = ? AND incident_id = ?",
            String.class, tenant, incidentId);

        if (severity == null || !VALID_SEVERITIES.contains(severity)) {
            throw new IllegalStateException(
                "Severidad inválida: " + severity + " para incidente " + incidentId);
        }
        execution.setVariable("severity", severity);
    }
}
