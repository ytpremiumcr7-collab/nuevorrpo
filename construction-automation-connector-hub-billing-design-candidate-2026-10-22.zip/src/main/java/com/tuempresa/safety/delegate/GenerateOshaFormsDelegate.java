package com.tuempresa.safety.delegate;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Component("generateOshaFormsDelegate")
public class GenerateOshaFormsDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper = new ObjectMapper();

    public GenerateOshaFormsDelegate(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = (UUID) execution.getVariable("tenantId");
        UUID incidentId = (UUID) execution.getVariable("incidentId");
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        Map<String,Object> inc = jdbc.queryForMap(
            "SELECT * FROM safety_incident WHERE tenant_id = ? AND incident_id = ?",
            tenant, incidentId);

        if (inc.get("root_cause") == null) {
            throw new IllegalStateException(
                "Incidente " + incidentId + " sin root_cause. No se puede emitir form 301.");
        }

        Map<String,Object> form301 = new HashMap<>();
        form301.put("incident_id", incidentId.toString());
        form301.put("severity", inc.get("severity"));
        form301.put("description", inc.get("description"));
        form301.put("root_cause", inc.get("root_cause"));

        Map<String,Object> form300 = new HashMap<>();
        form300.put("incident_id", incidentId.toString());
        form300.put("recordability", inc.get("osha_recordability"));

        try {
            String form301Json = mapper.writeValueAsString(form301);
            String form300Json = mapper.writeValueAsString(form300);

            UUID form301Id = UUID.randomUUID();
            UUID form300Id = UUID.randomUUID();

            jdbc.update("INSERT INTO osha_form_301 (tenant_id, form_id, incident_id, payload) " +
                "VALUES (?, ?, ?, ?::jsonb)", tenant, form301Id, incidentId, form301Json);
            jdbc.update("INSERT INTO osha_form_300 (tenant_id, form_id, incident_id, payload) " +
                "VALUES (?, ?, ?, ?::jsonb)", tenant, form300Id, incidentId, form300Json);
            jdbc.update("UPDATE safety_incident SET osha_form_300_id = ?, " +
                "osha_form_301_id = ?, status = 'CLOSED'::incident_status, " +
                "aggregate_version = aggregate_version + 1, updated_at = now() " +
                "WHERE tenant_id = ? AND incident_id = ?",
                form300Id, form301Id, tenant, incidentId);
        } catch (Exception e) {
            throw new RuntimeException("No se pudieron generar formularios OSHA", e);
        }
    }
}
