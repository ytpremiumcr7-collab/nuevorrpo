package com.tuempresa.identity.security;

import java.util.EnumSet;
import java.util.Set;
import java.util.UUID;

public final class UserContext {
    private static final ThreadLocal<CurrentUser> CTX = new ThreadLocal<>();

    private UserContext() {}

    public static void set(CurrentUser user) { CTX.set(user); }
    public static CurrentUser get() { return CTX.get(); }
    public static CurrentUser require() {
        CurrentUser u = CTX.get();
        if (u == null) throw new UnauthorizedException("No hay usuario autenticado");
        return u;
    }
    public static void clear() { CTX.remove(); }

    public record CurrentUser(
        UUID tenantId,
        UUID userId,
        String email,
        Set<ProjectRole> globalRoles,
        Set<ProjectMembership> memberships
    ) {
        public boolean hasRoleOnProject(UUID projectId, ProjectRole role) {
            if (globalRoles.contains(ProjectRole.OWNER)) return true;
            return memberships.stream()
                .anyMatch(m -> m.projectId().equals(projectId) && m.role() == role && m.active());
        }
        public boolean hasAnyRoleOnProject(UUID projectId, ProjectRole... roles) {
            for (ProjectRole r : roles) {
                if (hasRoleOnProject(projectId, r)) return true;
            }
            return false;
        }
    }

    public record ProjectMembership(UUID projectId, ProjectRole role, boolean active) {}

    public enum ProjectRole {
        OWNER, PROJECT_ENGINEER, SAFETY_LEAD, FINANCE, COMPLIANCE_LEAD,
        SUBCONTRACTOR_ADMIN, VIEWER
    }

    public static class UnauthorizedException extends RuntimeException {
        public UnauthorizedException(String m) { super(m); }
    }

    public static class ForbiddenException extends RuntimeException {
        public ForbiddenException(String m) { super(m); }
    }
}
