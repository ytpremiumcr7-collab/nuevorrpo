package com.tuempresa.identity.security;

import com.tuempresa.platform.tenant.TenantContext;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.EnumSet;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * API authentication. API keys are the normal credential. X-User-Id is an
 * explicitly opt-in development/test mechanism and is disabled by default.
 * The complete credential and membership lookup uses one RLS-scoped TX.
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 20)
public class AuthFilter extends OncePerRequestFilter {
    private final JdbcTemplate jdbc;
    private final TransactionTemplate transaction;
    private final boolean allowUserIdHeader;

    public AuthFilter(JdbcTemplate jdbc,
                      PlatformTransactionManager transactionManager,
                      @Value("${construction.auth.allow-user-id:false}") boolean allowUserIdHeader) {
        this.jdbc = jdbc;
        this.transaction = new TransactionTemplate(transactionManager);
        this.allowUserIdHeader = allowUserIdHeader;
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();
        return path.startsWith("/actuator")
            || path.startsWith("/error")
            || path.equals("/")
            || path.startsWith("/index.html")
            || path.startsWith("/app/")
            || path.startsWith("/css/")
            || path.startsWith("/js/")
            || path.equals("/api/health")
            || path.equals("/api/auth/bootstrap");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res,
                                    FilterChain chain) throws ServletException, IOException {
        UUID tenant = TenantContext.get();
        if (tenant == null) {
            String header = req.getHeader("X-Tenant-Id");
            if (header == null || header.isBlank()) {
                res.sendError(400, "Falta X-Tenant-Id");
                return;
            }
            try {
                tenant = UUID.fromString(header.trim());
                TenantContext.set(tenant);
            } catch (IllegalArgumentException e) {
                res.sendError(400, "X-Tenant-Id inválido");
                return;
            }
        }

        final UUID authenticatedTenant = tenant;
        String apiKey = req.getHeader("X-Api-Key");
        String userHeader = req.getHeader("X-User-Id");
        if ((apiKey == null || apiKey.isBlank()) && !allowUserIdHeader) {
            res.sendError(401, "Falta X-Api-Key; X-User-Id está deshabilitado");
            return;
        }

        AuthenticatedUser auth = transaction.execute(status -> {
            jdbc.queryForObject("SELECT set_config('app.tenant_id', ?, true)",
                String.class, authenticatedTenant.toString());

            UUID userId;
            String email;
            if (apiKey != null && !apiKey.isBlank()) {
                String hash = sha256(apiKey);
                List<Map<String, Object>> rows = jdbc.queryForList(
                    "SELECT c.user_id, u.email FROM api_credential c " +
                    "JOIN app_user u ON u.tenant_id = c.tenant_id AND u.user_id = c.user_id " +
                    "WHERE c.tenant_id = ? AND c.api_key_hash = ? " +
                    "AND c.active = true AND u.active = true",
                    authenticatedTenant, hash);
                if (rows.isEmpty()) return null;
                userId = (UUID) rows.get(0).get("user_id");
                email = (String) rows.get(0).get("email");
                jdbc.update("UPDATE api_credential SET last_used_at = now() " +
                    "WHERE tenant_id = ? AND api_key_hash = ?", authenticatedTenant, hash);
            } else {
                if (!allowUserIdHeader || userHeader == null || userHeader.isBlank()) return null;
                try { userId = UUID.fromString(userHeader.trim()); }
                catch (IllegalArgumentException e) { return null; }
                List<Map<String, Object>> rows = jdbc.queryForList(
                    "SELECT email FROM app_user WHERE tenant_id = ? AND user_id = ? AND active = true",
                    authenticatedTenant, userId);
                if (rows.isEmpty()) return null;
                email = (String) rows.get(0).get("email");
            }

            List<Map<String, Object>> rows = jdbc.queryForList(
                "SELECT project_id, role, active FROM project_membership " +
                "WHERE tenant_id = ? AND user_id = ? AND active = true", authenticatedTenant, userId);
            Set<UserContext.ProjectMembership> memberships = new HashSet<>();
            for (var row : rows) {
                UserContext.ProjectRole role = UserContext.ProjectRole.valueOf((String) row.get("role"));
                UUID projectId = (UUID) row.get("project_id");
                memberships.add(new UserContext.ProjectMembership(projectId, role, true));
            }
            // Una membresía OWNER pertenece a un proyecto; nunca se eleva a OWNER global.
            return new AuthenticatedUser(userId, email, memberships);
        });

        if (auth == null) {
            res.sendError(401, "Credencial inválida o usuario no registrado en el tenant");
            return;
        }

        UserContext.set(new UserContext.CurrentUser(
            tenant, auth.userId(), auth.email(),
            EnumSet.noneOf(UserContext.ProjectRole.class), auth.memberships()));
        try {
            chain.doFilter(req, res);
        } finally {
            UserContext.clear();
        }
    }

    private record AuthenticatedUser(UUID userId, String email,
                                     Set<UserContext.ProjectMembership> memberships) {}

    private static String sha256(String value) {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] bytes = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            StringBuilder out = new StringBuilder(bytes.length * 2);
            for (byte b : bytes) out.append(String.format("%02x", b));
            return out.toString();
        } catch (Exception e) {
            throw new IllegalStateException("SHA-256 no está disponible", e);
        }
    }
}
