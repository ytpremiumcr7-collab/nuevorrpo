package com.tuempresa.identity.service;

import com.tuempresa.identity.security.UserContext;
import com.tuempresa.platform.tenant.TenantContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class IdentityService {

    private final JdbcTemplate jdbc;
    private final SecureRandom random = new SecureRandom();

    public IdentityService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Transactional
    public UUID createUser(String email, String displayName) {
        UUID tenant = TenantContext.require();
        if (email == null || email.isBlank() || email.length() > 200
                || !email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            throw new IllegalArgumentException("Email inválido");
        }
        if (displayName == null || displayName.isBlank() || displayName.length() > 200) {
            throw new IllegalArgumentException("Nombre inválido");
        }
        UUID userId = UUID.randomUUID();
        jdbc.update(
            "INSERT INTO app_user (tenant_id, user_id, email, display_name) VALUES (?, ?, ?, ?)",
            tenant, userId, email.toLowerCase(), displayName);
        return userId;
    }

    @Transactional
    public void grantRole(UUID projectId, UUID userId, UserContext.ProjectRole role, UUID grantedBy) {
        UUID tenant = TenantContext.require();
        Integer projectExists = jdbc.queryForObject(
            "SELECT count(*) FROM project WHERE tenant_id = ? AND project_id = ?", Integer.class, tenant, projectId);
        Integer userExists = jdbc.queryForObject(
            "SELECT count(*) FROM app_user WHERE tenant_id = ? AND user_id = ? AND active = true", Integer.class, tenant, userId);
        if (projectExists == null || projectExists != 1 || userExists == null || userExists != 1) {
            throw new IllegalArgumentException("Proyecto o usuario no válido para este tenant");
        }
        jdbc.update(
            "INSERT INTO project_membership (tenant_id, project_id, user_id, role, granted_by) " +
            "VALUES (?, ?, ?, ?::project_role, ?) " +
            "ON CONFLICT (tenant_id, project_id, user_id, role) DO UPDATE SET active = true, granted_at = now()",
            tenant, projectId, userId, role.name(), grantedBy);
    }

    @Transactional
    public String issueApiKey(UUID userId, String label) {
        UUID tenant = TenantContext.require();
        byte[] raw = new byte[32];
        random.nextBytes(raw);
        String key = "cak_" + HexFormat.of().formatHex(raw);
        String hash = sha256(key);
        jdbc.update(
            "INSERT INTO api_credential (tenant_id, credential_id, user_id, api_key_hash, label) " +
            "VALUES (?, ?, ?, ?, ?)",
            tenant, UUID.randomUUID(), userId, hash, label);
        return key; // solo se devuelve una vez
    }

    public void requireProjectRole(UUID projectId, UserContext.ProjectRole... roles) {
        UserContext.CurrentUser user = UserContext.require();
        if (!user.hasAnyRoleOnProject(projectId, roles)) {
            throw new UserContext.ForbiddenException(
                "Rol insuficiente en proyecto " + projectId);
        }
    }

    public List<Map<String, Object>> listMemberships(UUID userId) {
        UUID tenant = TenantContext.require();
        return jdbc.queryForList(
            "SELECT project_id, role, active, granted_at FROM project_membership " +
            "WHERE tenant_id = ? AND user_id = ?", tenant, userId);
    }

    private static String sha256(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(md.digest(s.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
