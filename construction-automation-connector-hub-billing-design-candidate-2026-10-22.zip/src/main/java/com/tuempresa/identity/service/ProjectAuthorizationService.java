package com.tuempresa.identity.service;

import com.tuempresa.identity.security.UserContext;
import com.tuempresa.platform.tenant.TenantContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;

/** Central, project-scoped authorization for REST operations. Entity/table names are fixed enum values. */
@Service
public class ProjectAuthorizationService {
    private final JdbcTemplate jdbc;
    public ProjectAuthorizationService(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Transactional(readOnly = true)
    public void requireProjectRole(UUID projectId, UserContext.ProjectRole... roles) {
        UserContext.CurrentUser user = UserContext.require();
        UUID tenant = TenantContext.require();
        if (projectId == null || !tenant.equals(user.tenantId())) {
            throw new UserContext.ForbiddenException("Proyecto fuera del contexto autenticado");
        }
        Integer exists = jdbc.queryForObject(
            "SELECT count(*) FROM project WHERE tenant_id = ? AND project_id = ?",
            Integer.class, tenant, projectId);
        if (exists == null || exists != 1) {
            throw new UserContext.ForbiddenException("Proyecto no accesible");
        }
        if (!user.hasAnyRoleOnProject(projectId, roles)) {
            throw new UserContext.ForbiddenException("Rol insuficiente para la obra " + projectId);
        }
    }

    @Transactional(readOnly = true)
    public void requireProjectMember(UUID projectId) {
        requireProjectRole(projectId, UserContext.ProjectRole.OWNER, UserContext.ProjectRole.PROJECT_ENGINEER,
            UserContext.ProjectRole.SAFETY_LEAD, UserContext.ProjectRole.FINANCE,
            UserContext.ProjectRole.COMPLIANCE_LEAD, UserContext.ProjectRole.SUBCONTRACTOR_ADMIN,
            UserContext.ProjectRole.VIEWER);
    }

    @Transactional(readOnly = true)
    public void requireOwnerOnAnyProject() {
        UserContext.CurrentUser user = UserContext.require();
        if (!user.globalRoles().contains(UserContext.ProjectRole.OWNER)
                && user.memberships().stream().noneMatch(m -> m.active() && m.role() == UserContext.ProjectRole.OWNER)) {
            throw new UserContext.ForbiddenException("Se requiere OWNER de obra");
        }
    }

    @Transactional(readOnly = true)
    public void requireEntityProject(Resource resource, UUID entityId, UserContext.ProjectRole... roles) {
        UUID tenant = TenantContext.require();
        UserContext.CurrentUser user = UserContext.require();
        if (!tenant.equals(user.tenantId())) throw new UserContext.ForbiddenException("Tenant no coincide");
        EntitySql entity = EntitySql.forResource(resource);
        List<UUID> projects = jdbc.query(entity.sql(),
            (rs, row) -> (UUID) rs.getObject(1), tenant, entityId);
        if (projects.isEmpty()) throw new UserContext.ForbiddenException("Recurso no accesible");
        UUID projectId = projects.get(0);
        if (projectId == null) {
            requireOwnerOnAnyProject();
        } else {
            requireProjectRole(projectId, roles);
        }
    }

    public enum Resource { RFI, CHANGE_ORDER, SUBMITTAL, INCIDENT, PERMIT, REQUIREMENT,
        BID_PACKAGE, BID, DOCUMENT, PAYMENT, PAYMENT_APPLICATION, ASSEMBLED_DOCUMENT }

    private record EntitySql(String sql) {
        static EntitySql forResource(Resource resource) {
            return switch (resource) {
                case RFI -> new EntitySql("SELECT project_id FROM rfi WHERE tenant_id = ? AND rfi_id = ?");
                case CHANGE_ORDER -> new EntitySql("SELECT project_id FROM change_order WHERE tenant_id = ? AND change_order_id = ?");
                case SUBMITTAL -> new EntitySql("SELECT project_id FROM submittal WHERE tenant_id = ? AND submittal_id = ?");
                case INCIDENT -> new EntitySql("SELECT project_id FROM safety_incident WHERE tenant_id = ? AND incident_id = ?");
                case PERMIT -> new EntitySql("SELECT project_id FROM permit_application WHERE tenant_id = ? AND permit_id = ?");
                case REQUIREMENT -> new EntitySql("SELECT project_id FROM compliance_requirement WHERE tenant_id = ? AND requisito_id = ?");
                case BID_PACKAGE -> new EntitySql("SELECT project_id FROM bid_package WHERE tenant_id = ? AND bid_package_id = ?");
                case BID -> new EntitySql("SELECT p.project_id FROM bid b JOIN bid_package p ON p.tenant_id = b.tenant_id AND p.bid_package_id = b.bid_package_id WHERE b.tenant_id = ? AND b.bid_id = ?");
                case DOCUMENT -> new EntitySql("SELECT project_id FROM document WHERE tenant_id = ? AND document_id = ?");
                case PAYMENT -> new EntitySql("SELECT project_id FROM payment WHERE tenant_id = ? AND payment_id = ?");
                case PAYMENT_APPLICATION -> new EntitySql("SELECT project_id FROM payment_application WHERE tenant_id = ? AND payment_application_id = ?");
                case ASSEMBLED_DOCUMENT -> new EntitySql("SELECT project_id FROM assembled_document WHERE tenant_id = ? AND assembly_id = ?");
            };
        }
    }
}
