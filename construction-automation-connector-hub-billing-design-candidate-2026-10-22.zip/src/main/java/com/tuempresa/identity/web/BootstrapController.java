package com.tuempresa.identity.web;

import com.tuempresa.platform.tenant.TenantContext;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.HexFormat;
import java.util.Map;
import java.util.UUID;

/** Publicly reachable bootstrap endpoint protected by a deployment-only secret. */
@RestController
@RequestMapping("/api/auth")
public class BootstrapController {
    private final JdbcTemplate jdbc;
    private final String expectedToken;
    private final SecureRandom random = new SecureRandom();

    public BootstrapController(JdbcTemplate jdbc,
            @Value("${construction.bootstrap-token:}") String expectedToken) {
        this.jdbc = jdbc;
        this.expectedToken = expectedToken == null ? "" : expectedToken.trim();
    }

    @PostMapping("/bootstrap")
    @Transactional
    public ResponseEntity<?> bootstrap(@RequestHeader(value = "X-Bootstrap-Token", required = false) String suppliedToken,
                                       @RequestBody Map<String, String> body) {
        if (expectedToken.isBlank()) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(
                Map.of("error", "Bootstrap deshabilitado: configure CONSTRUCTION_BOOTSTRAP_TOKEN"));
        }
        if (suppliedToken == null || !constantTimeEquals(expectedToken, suppliedToken)) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Token bootstrap inválido"));
        }

        UUID tenant = TenantContext.require();
        jdbc.queryForObject("SELECT set_config('app.tenant_id', ?, true)", String.class, tenant.toString());
        var tenantRows = jdbc.queryForList(
            "SELECT tenant_id FROM tenant WHERE tenant_id = ? AND active = true FOR UPDATE", tenant);
        if (tenantRows.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of("error", "Tenant inexistente o inactivo"));
        }

        Long count = jdbc.queryForObject(
            "SELECT count(*) FROM app_user WHERE tenant_id = ?", Long.class, tenant);
        if (count != null && count > 0) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(
                Map.of("error", "El tenant ya tiene usuarios; bootstrap de un solo uso"));
        }

        String email = body.getOrDefault("email", "").trim().toLowerCase();
        String displayName = body.getOrDefault("displayName", "").trim();
        if (email.isBlank() || email.length() > 200 || !email.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            return ResponseEntity.badRequest().body(Map.of("error", "Email inválido"));
        }
        if (displayName.isBlank() || displayName.length() > 200) {
            return ResponseEntity.badRequest().body(Map.of("error", "Nombre inválido"));
        }

        UUID projectId;
        String suppliedProjectId = body.get("projectId");
        if (suppliedProjectId != null && !suppliedProjectId.isBlank()) {
            try { projectId = UUID.fromString(suppliedProjectId.trim()); }
            catch (IllegalArgumentException e) {
                return ResponseEntity.badRequest().body(Map.of("error", "Project ID inválido"));
            }
            var projects = jdbc.queryForList(
                "SELECT project_id FROM project WHERE tenant_id = ? AND project_id = ? FOR UPDATE",
                tenant, projectId);
            if (projects.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("error", "El proyecto no pertenece al tenant"));
            }
        } else {
            projectId = UUID.randomUUID();
            jdbc.update("INSERT INTO project (tenant_id, project_id, name, timezone, status) " +
                "VALUES (?, ?, ?, ?, ?)", tenant, projectId, "Obra inicial", "America/Mexico_City", "ACTIVE");
        }

        UUID userId = UUID.randomUUID();
        jdbc.update("INSERT INTO app_user (tenant_id, user_id, email, display_name) VALUES (?, ?, ?, ?)",
            tenant, userId, email, displayName);
        jdbc.update("INSERT INTO project_membership (tenant_id, project_id, user_id, role) " +
            "VALUES (?, ?, ?, 'OWNER'::project_role)", tenant, projectId, userId);

        byte[] raw = new byte[32];
        random.nextBytes(raw);
        String apiKey = "cak_" + HexFormat.of().formatHex(raw);
        String apiKeyHash = sha256(apiKey);
        jdbc.update("INSERT INTO api_credential (tenant_id, credential_id, user_id, api_key_hash, label) " +
            "VALUES (?, ?, ?, ?, ?)", tenant, UUID.randomUUID(), userId, apiKeyHash, "bootstrap-initial-key");

        return ResponseEntity.ok(Map.of(
            "userId", userId, "tenantId", tenant, "projectId", projectId,
            "apiKey", apiKey, "note", "Guarde apiKey; solo se muestra una vez"));
    }

    private static boolean constantTimeEquals(String expected, String supplied) {
        return MessageDigest.isEqual(expected.getBytes(StandardCharsets.UTF_8),
            supplied.getBytes(StandardCharsets.UTF_8));
    }

    private static String sha256(String value) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                .digest(value.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new IllegalStateException("SHA-256 no está disponible", e);
        }
    }
}
