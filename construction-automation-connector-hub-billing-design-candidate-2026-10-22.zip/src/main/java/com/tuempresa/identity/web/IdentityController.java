package com.tuempresa.identity.web;

import com.tuempresa.identity.security.UserContext;
import com.tuempresa.identity.service.IdentityService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/identity")
public class IdentityController {
    private final IdentityService identity;

    public IdentityController(IdentityService identity) { this.identity = identity; }

    @PostMapping("/users")
    public ResponseEntity<?> createUser(@RequestBody Map<String, String> body) {
        UserContext.CurrentUser me = UserContext.require();
        boolean owner = me.globalRoles().contains(UserContext.ProjectRole.OWNER)
            || me.memberships().stream().anyMatch(m -> m.active() && m.role() == UserContext.ProjectRole.OWNER);
        if (!owner) throw new UserContext.ForbiddenException("Se requiere OWNER de una obra para crear usuarios");
        UUID id = identity.createUser(body.get("email"), body.get("displayName"));
        return ResponseEntity.ok(Map.of("userId", id));
    }

    @PostMapping("/projects/{projectId}/members")
    public ResponseEntity<?> grant(@PathVariable UUID projectId, @RequestBody Map<String, String> body) {
        UserContext.CurrentUser me = UserContext.require();
        identity.requireProjectRole(projectId, UserContext.ProjectRole.OWNER);
        UserContext.ProjectRole requestedRole;
        UUID targetUser;
        try {
            requestedRole = UserContext.ProjectRole.valueOf(body.get("role"));
            targetUser = UUID.fromString(body.get("userId"));
        } catch (RuntimeException e) {
            return ResponseEntity.badRequest().body(Map.of("error", "userId o role inválido"));
        }
        if (requestedRole == UserContext.ProjectRole.OWNER
                && !me.hasRoleOnProject(projectId, UserContext.ProjectRole.OWNER)) {
            throw new UserContext.ForbiddenException("Solo OWNER de esa obra puede asignar OWNER");
        }
        identity.grantRole(projectId, targetUser, requestedRole, me.userId());
        return ResponseEntity.ok().build();
    }

    @PostMapping("/users/{userId}/api-keys")
    public ResponseEntity<?> issueKey(@PathVariable UUID userId, @RequestBody Map<String, String> body) {
        UserContext.CurrentUser me = UserContext.require();
        if (!me.userId().equals(userId)) {
            throw new UserContext.ForbiddenException("Solo puedes emitir una API key para tu propio usuario");
        }
        String label = body.getOrDefault("label", "default").trim();
        if (label.isBlank() || label.length() > 120) {
            return ResponseEntity.badRequest().body(Map.of("error", "label inválido"));
        }
        String key = identity.issueApiKey(userId, label);
        return ResponseEntity.ok(Map.of("apiKey", key, "note", "Guarde la clave; no se vuelve a mostrar"));
    }

    @GetMapping("/me")
    public Map<String, Object> me() {
        UserContext.CurrentUser user = UserContext.require();
        return Map.of("userId", user.userId(), "email", user.email(), "tenantId", user.tenantId(),
            "memberships", identity.listMemberships(user.userId()));
    }

    @GetMapping("/users/{userId}/memberships")
    public List<Map<String, Object>> memberships(@PathVariable UUID userId) {
        UserContext.CurrentUser me = UserContext.require();
        if (!me.userId().equals(userId)) {
            throw new UserContext.ForbiddenException("Solo puedes consultar tus propias membresías");
        }
        return identity.listMemberships(userId);
    }
}
