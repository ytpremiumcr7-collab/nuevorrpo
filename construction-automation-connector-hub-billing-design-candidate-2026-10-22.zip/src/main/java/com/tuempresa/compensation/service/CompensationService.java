package com.tuempresa.compensation.service;

import com.tuempresa.compensation.event.CompensationCaseCreatedEvent;
import com.tuempresa.platform.tenant.TenantContext;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Map;
import java.util.UUID;

@Service
public class CompensationService {
    private final JdbcTemplate jdbc;
    private final ApplicationEventPublisher events;

    public CompensationService(JdbcTemplate jdbc, ApplicationEventPublisher events) {
        this.jdbc = jdbc; this.events = events;
    }

    @Transactional
    public UUID open(UUID paymentId, String invalidityType, UUID evidenceId,
                     BigDecimal amount, String contractualBasis) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        Map<String,Object> payment = jdbc.queryForMap(
            "SELECT subcontractor_id, project_id, executed_at FROM payment " +
            "WHERE tenant_id = ? AND payment_id = ?", tenant, paymentId);
        if (payment.get("executed_at") == null) throw new IllegalStateException("Pago no ejecutado");

        UUID caseId = UUID.randomUUID();
        UUID subId = (UUID) payment.get("subcontractor_id");
        UUID projId = (UUID) payment.get("project_id");

        var returned = jdbc.query(
            "INSERT INTO compensation_case " +
            "(tenant_id, compensation_case_id, payment_id, invalidity_type, " +
            " evidence_id, subcontractor_id, project_id, amount_to_recover, status, contractual_basis) " +
            "VALUES (?, ?, ?, ?::invalidity_type, ?, ?, ?, ?, 'OPEN'::compensation_state, ?) " +
            "ON CONFLICT (tenant_id, payment_id, invalidity_type, evidence_id) DO NOTHING " +
            "RETURNING compensation_case_id",
            (rs, i) -> rs.getObject(1, UUID.class),
            tenant, caseId, paymentId, invalidityType, evidenceId, subId, projId, amount, contractualBasis);

        if (returned.isEmpty()) {
            return jdbc.queryForObject(
                "SELECT compensation_case_id FROM compensation_case " +
                "WHERE tenant_id = ? AND payment_id = ? AND invalidity_type = ?::invalidity_type AND evidence_id = ?",
                UUID.class, tenant, paymentId, invalidityType, evidenceId);
        }

        // FIX A1: Incrementar el saldo de recuperación en la cuenta
        jdbc.update(
            "INSERT INTO recovery_account (tenant_id, subcontractor_id, project_id, saldo_pendiente, version) " +
            "VALUES (?, ?, ?, ?, 0) " +
            "ON CONFLICT (tenant_id, subcontractor_id, project_id) DO UPDATE " +
            "SET saldo_pendiente = recovery_account.saldo_pendiente + EXCLUDED.saldo_pendiente, " +
            "    version = recovery_account.version + 1",
            tenant, subId, projId, amount);

        events.publishEvent(new CompensationCaseCreatedEvent(
            tenant, caseId, paymentId, subId, projId, invalidityType, evidenceId, amount, contractualBasis));
        return caseId;
    }
}
