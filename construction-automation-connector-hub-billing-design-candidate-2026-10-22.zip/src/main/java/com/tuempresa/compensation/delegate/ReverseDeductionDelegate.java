package com.tuempresa.compensation.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Map;
import java.util.UUID;

@Component("reverseDeductionDelegate")
public class ReverseDeductionDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    public ReverseDeductionDelegate(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = (UUID) execution.getVariable("tenantId");
        UUID deductionId = (UUID) execution.getVariable("deductionId");
        String reason = (String) execution.getVariable("reversalReason");
        if (reason == null) reason = "Reversión por disputa";

        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        // Fail-loud: si no existe o ya fue revertida, no silenciar
        Map<String,Object> row;
        try {
            row = jdbc.queryForMap(
                "SELECT subcontractor_id, project_id, amount, status " +
                "FROM deduction_log WHERE tenant_id = ? AND deduction_id = ? " +
                "FOR UPDATE", tenant, deductionId);
        } catch (org.springframework.dao.EmptyResultDataAccessException e) {
            throw new IllegalStateException(
                "Deducción " + deductionId + " no encontrada");
        }

        if ("REVERSED".equals(row.get("status").toString())) {
            // Idempotente: log warning y salir sin error
            org.slf4j.LoggerFactory.getLogger(getClass())
                .warn("Deducción {} ya estaba revertida; no-op", deductionId);
            return;
        }

        BigDecimal monto = (BigDecimal) row.get("amount");

        jdbc.update(
            "UPDATE recovery_account " +
            "SET saldo_pendiente = saldo_pendiente + ?, version = version + 1 " +
            "WHERE tenant_id = ? AND subcontractor_id = ? AND project_id = ?",
            monto, tenant, row.get("subcontractor_id"), row.get("project_id"));

        jdbc.update(
            "UPDATE deduction_log SET status = 'REVERSED'::deduction_status, " +
            "reversed_at = now(), reversal_reason = ? " +
            "WHERE tenant_id = ? AND deduction_id = ?",
            reason, tenant, deductionId);

        execution.setVariable("reversedAmount", monto);
    }
}
