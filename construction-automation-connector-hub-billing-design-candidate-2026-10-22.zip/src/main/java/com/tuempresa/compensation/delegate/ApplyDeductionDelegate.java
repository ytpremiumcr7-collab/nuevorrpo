package com.tuempresa.compensation.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Map;
import java.util.UUID;

/**
 * Aplica deducción con control optimista + fail-loud.
 * Crea recovery_account si no existe (saldo inicial = amountToRecover).
 */
@Component("applyDeductionDelegate")
public class ApplyDeductionDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;

    public ApplyDeductionDelegate(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = asUuid(execution.getVariable("tenantId"));
        UUID sub = asUuid(execution.getVariable("subcontractorId"));
        UUID project = asUuid(execution.getVariable("projectId"));
        BigDecimal monto = (BigDecimal) execution.getVariable("amountToRecover");
        UUID caseId = asUuid(execution.getVariable("compensationCaseId"));
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        // Asegurar cuenta de recuperación
        jdbc.update("""
            INSERT INTO recovery_account
              (tenant_id, subcontractor_id, project_id, saldo_pendiente, version)
            VALUES (?, ?, ?, ?, 0)
            ON CONFLICT (tenant_id, subcontractor_id, project_id) DO NOTHING
            """, tenant, sub, project, monto);

        Map<String, Object> account = jdbc.queryForMap(
            "SELECT saldo_pendiente, version FROM recovery_account " +
            "WHERE tenant_id = ? AND subcontractor_id = ? AND project_id = ? " +
            "FOR UPDATE", tenant, sub, project);

        BigDecimal saldo = (BigDecimal) account.get("saldo_pendiente");
        long version = ((Number) account.get("version")).longValue();

        // Si la cuenta se acaba de crear con el monto, la deducción es "reservar"
        // Si ya tenía saldo insuficiente, fail-loud
        if (saldo.compareTo(monto) < 0) {
            throw new IllegalStateException(
                "Saldo insuficiente: disponible=" + saldo + ", requerido=" + monto +
                " (compensationCase=" + caseId + ")");
        }

        int updated = jdbc.update(
            "UPDATE recovery_account " +
            "SET saldo_pendiente = saldo_pendiente - ?, version = version + 1 " +
            "WHERE tenant_id = ? AND subcontractor_id = ? AND project_id = ? " +
            "AND version = ? AND saldo_pendiente >= ?",
            monto, tenant, sub, project, version, monto);

        if (updated == 0) {
            throw new IllegalStateException(
                "Deducción rechazada (concurrencia o saldo): version=" + version +
                ", monto=" + monto);
        }

        UUID deductionId = UUID.randomUUID();
        jdbc.update(
            "INSERT INTO deduction_log " +
            "(tenant_id, deduction_id, subcontractor_id, project_id, amount, status) " +
            "VALUES (?, ?, ?, ?, ?, 'ACTIVE'::deduction_status)",
            tenant, deductionId, sub, project, monto);

        execution.setVariable("deductionId", deductionId);
        execution.setVariable("appliedAmount", monto);
    }

    private static UUID asUuid(Object v) {
        if (v == null) throw new IllegalStateException("UUID variable null");
        if (v instanceof UUID u) return u;
        return UUID.fromString(v.toString());
    }
}
