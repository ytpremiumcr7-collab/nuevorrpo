package com.tuempresa.compensation.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component("markCompensationStateDelegate")
public class MarkCompensationStateDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    public MarkCompensationStateDelegate(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = asUuid(execution.getVariable("tenantId"));
        UUID caseId = asUuid(execution.getVariable("compensationCaseId"));
        String newStatus = (String) execution.getVariable("newStatus");
        if (newStatus == null) throw new IllegalStateException(
            "newStatus no seteado en markCompensationStateDelegate");
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        int updated = jdbc.update(
            "UPDATE compensation_case SET status = ?::compensation_state, " +
            "aggregate_version = aggregate_version + 1, closed_at = now() " +
            "WHERE tenant_id = ? AND compensation_case_id = ?",
            newStatus, tenant, caseId);
        if (updated == 0) throw new IllegalStateException(
            "Caso " + caseId + " no encontrado");
    }

    private static UUID asUuid(Object v) {
        if (v == null) throw new IllegalStateException("UUID variable null");
        if (v instanceof UUID u) return u;
        return UUID.fromString(v.toString());
    }
}
