package com.tuempresa.compensation.event;

import java.math.BigDecimal;
import java.util.UUID;

public record CompensationCaseCreatedEvent(
    UUID tenantId, UUID caseId, UUID paymentId,
    UUID subcontractorId, UUID projectId,
    String invalidityType, UUID evidenceId,
    BigDecimal amount, String contractualBasis) {}
