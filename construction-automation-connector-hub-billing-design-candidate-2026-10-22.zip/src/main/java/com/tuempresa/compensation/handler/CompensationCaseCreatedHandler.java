package com.tuempresa.compensation.handler;

import com.tuempresa.compensation.event.CompensationCaseCreatedEvent;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;

/**
 * Correlaciona el evento de dominio con el message start de
 * compensationCaseProcess. Sin este handler, la compensación nunca arranca.
 */
@Component
public class CompensationCaseCreatedHandler {

    private final RuntimeService runtimeService;
    public CompensationCaseCreatedHandler(RuntimeService runtimeService) {
        this.runtimeService = runtimeService;
    }

    @EventListener
    @Transactional
    public void on(CompensationCaseCreatedEvent event) {
        String businessKey = event.caseId().toString();
        // UUIDs como objeto para cast seguro en delegates
        Map<String, Object> vars = new HashMap<>();
        vars.put("tenantId", event.tenantId());
        vars.put("compensationCaseId", event.caseId());
        vars.put("paymentId", event.paymentId());
        vars.put("subcontractorId", event.subcontractorId());
        vars.put("projectId", event.projectId());
        vars.put("amountToRecover", event.amount());
        vars.put("invalidityType", event.invalidityType());
        vars.put("evidenceId", event.evidenceId());
        vars.put("contractualBasis", event.contractualBasis());

        runtimeService.createMessageCorrelation("PaymentInvalidatedMessage")
            .setVariables(vars)
            .processInstanceBusinessKey(businessKey)
            .correlateStartMessage();
    }
}
