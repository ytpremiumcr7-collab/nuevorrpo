package com.tuempresa.compliance.projector;

import com.tuempresa.compliance.domain.ComplianceEvent;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@Component
public class ComplianceProjectorSync {

    private final JdbcTemplate jdbc;
    public ComplianceProjectorSync(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Transactional(propagation = Propagation.MANDATORY)
    public void apply(ComplianceEvent event) {
        jdbc.update("""
            INSERT INTO compliance_requirement
              (tenant_id, requisito_id, subcontractor_id, project_id,
               tipo_requisito, estado_verificacion, fecha_vencimiento,
               documento_id, fuente_evento_id, version_fila)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (tenant_id, requisito_id) DO UPDATE SET
              estado_verificacion = EXCLUDED.estado_verificacion,
              fecha_vencimiento   = EXCLUDED.fecha_vencimiento,
              documento_id        = EXCLUDED.documento_id,
              version_fila        = EXCLUDED.version_fila,
              actualizado_en      = now()
            """,
            event.tenantId(), event.requisitoId(), event.subcontractorId(),
            event.projectId(), event.tipoRequisito(), event.estadoVerificacion(),
            event.fechaVencimiento(), event.documentoId(),
            event.eventId(), event.aggregateVersion());

        // FIX A2: ORDER BY determinista
        List<Map<String,Object>> reqs = jdbc.queryForList("""
            SELECT requisito_id, tipo_requisito, estado_verificacion,
                   fecha_vencimiento, version_fila
              FROM compliance_requirement
             WHERE tenant_id = ? AND subcontractor_id = ? AND project_id = ?
             ORDER BY fecha_vencimiento ASC, version_fila DESC
            """, event.tenantId(), event.subcontractorId(), event.projectId());

        Map<String,Object> critico = reqs.stream()
            .filter(r -> !"VERIFICADO".equals(r.get("estado_verificacion"))
                      || ((LocalDate) r.get("fecha_vencimiento")).isBefore(LocalDate.now()))
            .findFirst()
            .orElse(reqs.get(0)); // Ahora reqs.get(0) es el que vence primero

        boolean todosVigentes = reqs.stream().allMatch(r ->
            "VERIFICADO".equals(r.get("estado_verificacion"))
            && !((LocalDate) r.get("fecha_vencimiento")).isBefore(LocalDate.now()));
        String estadoGlobal = todosVigentes ? "VIGENTE" : "BLOQUEADO";

        long total = reqs.size();
        long vigentes = reqs.stream().filter(r -> "VERIFICADO".equals(r.get("estado_verificacion"))).count();
        long bloqueados = total - vigentes;

        jdbc.update("""
            INSERT INTO compliance_subcontractor_head
              (tenant_id, subcontractor_id, project_id, estado_global, version_actual,
               requisito_critico_id, requisito_critico_tipo, requisito_critico_estado,
               requisito_critico_vencimiento, requisitos_total, requisitos_vigentes,
               requisitos_bloqueados, ultimo_evento_id)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT (tenant_id, subcontractor_id, project_id) DO UPDATE SET
              estado_global                 = EXCLUDED.estado_global,
              version_actual                = GREATEST(compliance_subcontractor_head.version_actual,
                                                        EXCLUDED.version_actual),
              requisito_critico_id          = EXCLUDED.requisito_critico_id,
              requisito_critico_tipo        = EXCLUDED.requisito_critico_tipo,
              requisito_critico_estado      = EXCLUDED.requisito_critico_estado,
              requisito_critico_vencimiento = EXCLUDED.requisito_critico_vencimiento,
              requisitos_total              = EXCLUDED.requisitos_total,
              requisitos_vigentes           = EXCLUDED.requisitos_vigentes,
              requisitos_bloqueados         = EXCLUDED.requisitos_bloqueados,
              ultimo_evento_id              = EXCLUDED.ultimo_evento_id,
              actualizado_en                = now()
            """,
            event.tenantId(), event.subcontractorId(), event.projectId(),
            estadoGlobal, event.aggregateVersion(),
            critico.get("requisito_id"), critico.get("tipo_requisito"),
            critico.get("estado_verificacion"), critico.get("fecha_vencimiento"),
            total, vigentes, bloqueados, event.eventId());
    }
}
