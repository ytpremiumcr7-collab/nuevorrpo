package com.tuempresa.compliance.projector;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

/**
 * CRÍTICO: solo toca columnas permitidas por GRANT a app_projector_async.
 * Si intenta UPDATE de estado_global o version_fila, Postgres lo rechaza.
 * No-op silencioso para eventos que no son de su competencia (con log).
 */
@Component
public class ComplianceAsyncProjector {

    private final JdbcTemplate jdbc;
    private static final org.slf4j.Logger log =
        org.slf4j.LoggerFactory.getLogger(ComplianceAsyncProjector.class);

    public ComplianceAsyncProjector(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Transactional
    public void apply(com.tuempresa.platform.events.OutboxRow row) {
        if ("ComplianceDocumentUploaded".equals(row.eventType())) {
            UUID tenant = row.tenantId();
            UUID requisitoId = row.aggregateId();
            UUID documentoId = row.documentoIdFromPayload();
            jdbc.queryForObject("SELECT set_config('app.tenant_id', ?, true)", String.class, tenant.toString());
            int changed = jdbc.update(
                "UPDATE compliance_requirement SET documento_id = ?, actualizado_en = now() " +
                "WHERE tenant_id = ? AND requisito_id = ?",
                documentoId, tenant, requisitoId);
            if (changed != 1) {
                throw new IllegalStateException("Evento ComplianceDocumentUploaded sin requisito único: " + requisitoId);
            }
        } else {
            throw new IllegalArgumentException("Tipo de evento no manejado por ComplianceAsyncProjector: " + row.eventType());
        }
    }
}
