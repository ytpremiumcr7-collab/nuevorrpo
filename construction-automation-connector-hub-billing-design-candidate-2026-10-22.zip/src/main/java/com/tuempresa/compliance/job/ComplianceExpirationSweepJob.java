package com.tuempresa.compliance.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Nicho construcción: seguimiento de vencimientos de certificados/licencias
 * y recordatorios de renovación (30d, 7d, vencido).
 * Independiente del BPMN — garantía operativa diaria.
 */
@Component
public class ComplianceExpirationSweepJob {

    private static final Logger log = LoggerFactory.getLogger(ComplianceExpirationSweepJob.class);
    private final JdbcTemplate jdbc;

    public ComplianceExpirationSweepJob(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Scheduled(cron = "0 30 6 * * *", zone = "UTC")
    @Transactional
    public void sweep() {
        List<UUID> tenants = jdbc.queryForList(
            "SELECT tenant_id FROM tenant WHERE active = true", UUID.class);
        for (UUID tenant : tenants) {
            jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
            sweepTenant(tenant);
        }
    }

    private void sweepTenant(UUID tenant) {
        // Nivel 3: ya vencidos y aún no alertados como vencidos
        alert(tenant, 3,
            "SELECT requisito_id, subcontractor_id, project_id, tipo_requisito, fecha_vencimiento " +
            "FROM compliance_requirement " +
            "WHERE tenant_id = ? AND estado_verificacion = 'VERIFICADO' " +
            "AND fecha_vencimiento < CURRENT_DATE AND expiry_alert_level < 3",
            "VENCIDO: certificado/licencia expirado");

        // Nivel 2: vence en 7 días
        alert(tenant, 2,
            "SELECT requisito_id, subcontractor_id, project_id, tipo_requisito, fecha_vencimiento " +
            "FROM compliance_requirement " +
            "WHERE tenant_id = ? AND estado_verificacion = 'VERIFICADO' " +
            "AND fecha_vencimiento BETWEEN CURRENT_DATE AND CURRENT_DATE + 7 " +
            "AND expiry_alert_level < 2",
            "Renovación urgente: vence en ≤7 días");

        // Nivel 1: vence en 30 días
        alert(tenant, 1,
            "SELECT requisito_id, subcontractor_id, project_id, tipo_requisito, fecha_vencimiento " +
            "FROM compliance_requirement " +
            "WHERE tenant_id = ? AND estado_verificacion = 'VERIFICADO' " +
            "AND fecha_vencimiento BETWEEN CURRENT_DATE + 8 AND CURRENT_DATE + 30 " +
            "AND expiry_alert_level < 1",
            "Renovación: vence en ≤30 días");
    }

    private void alert(UUID tenant, int level, String sql, String subjectPrefix) {
        List<Map<String, Object>> rows = jdbc.queryForList(sql, tenant);
        for (var row : rows) {
            UUID reqId = (UUID) row.get("requisito_id");
            jdbc.update(
                "INSERT INTO notification_outbox " +
                "(tenant_id, notification_id, recipient_role, subject, body) " +
                "VALUES (?, ?, 'COMPLIANCE_LEAD', ?, ?)",
                tenant, UUID.randomUUID(),
                subjectPrefix + " — " + row.get("tipo_requisito"),
                "Requisito " + reqId + " sub=" + row.get("subcontractor_id") +
                " proyecto=" + row.get("project_id") +
                " vence=" + row.get("fecha_vencimiento"));
            jdbc.update(
                "UPDATE compliance_requirement SET expiry_alerted_at = now(), " +
                "expiry_alert_level = ? WHERE tenant_id = ? AND requisito_id = ?",
                level, tenant, reqId);
            log.warn("Compliance expiry alert level={} tenant={} requisito={}",
                level, tenant, reqId);
        }
    }
}
