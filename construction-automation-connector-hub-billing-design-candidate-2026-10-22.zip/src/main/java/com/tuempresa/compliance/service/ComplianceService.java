package com.tuempresa.compliance.service;

import com.tuempresa.compliance.domain.ComplianceEvent;
import com.tuempresa.compliance.projector.ComplianceProjectorSync;
import com.tuempresa.platform.events.OutboxPublisher;
import com.tuempresa.platform.tenant.TenantContext;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.UUID;

@Service
public class ComplianceService {

    private final JdbcTemplate jdbc;
    private final ComplianceProjectorSync projector;
    private final OutboxPublisher outbox;
    private final ApplicationEventPublisher events;
    private final RuntimeService runtimeService;

    public ComplianceService(JdbcTemplate jdbc, ComplianceProjectorSync projector,
                             OutboxPublisher outbox, ApplicationEventPublisher events,
                             RuntimeService runtimeService) {
        this.jdbc = jdbc; this.projector = projector; this.outbox = outbox;
        this.events = events; this.runtimeService = runtimeService;
    }

    @Transactional
    public UUID addRequirement(UUID subcontractorId, UUID projectId,
                               String tipo, LocalDate fechaVencimiento) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        UUID requisitoId = UUID.randomUUID();
        ComplianceEvent event = new ComplianceEvent(
            tenant, requisitoId, subcontractorId, projectId, null,
            tipo, "PENDIENTE", fechaVencimiento, 1);
        projector.apply(event);
        outbox.publish(event);
        events.publishEvent(event);
        return requisitoId;
    }

    @Transactional
    public void verify(UUID requisitoId, UUID documentoId) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        var row = jdbc.queryForMap(
            "SELECT subcontractor_id, project_id, tipo_requisito, fecha_vencimiento, version_fila " +
            "FROM compliance_requirement WHERE tenant_id = ? AND requisito_id = ?",
            tenant, requisitoId);
        ComplianceEvent event = new ComplianceEvent(
            tenant, requisitoId,
            (UUID) row.get("subcontractor_id"), (UUID) row.get("project_id"),
            documentoId, (String) row.get("tipo_requisito"),
            "VERIFICADO", (LocalDate) row.get("fecha_vencimiento"),
            ((Number) row.get("version_fila")).longValue() + 1);
        projector.apply(event);
        outbox.publish(event);
        events.publishEvent(event);
    }

    @Transactional
    public void revoke(UUID requisitoId, String motivo, LocalDate effectiveDate) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        var row = jdbc.queryForMap(
            "SELECT subcontractor_id, project_id, tipo_requisito, fecha_vencimiento, version_fila " +
            "FROM compliance_requirement WHERE tenant_id = ? AND requisito_id = ?",
            tenant, requisitoId);
        ComplianceEvent event = new ComplianceEvent(
            tenant, requisitoId,
            (UUID) row.get("subcontractor_id"), (UUID) row.get("project_id"),
            null, (String) row.get("tipo_requisito"),
            "REVOCADO", (LocalDate) row.get("fecha_vencimiento"),
            ((Number) row.get("version_fila")).longValue() + 1);
        projector.apply(event);
        outbox.publish(event);
        events.publishEvent(event);

        // Correlacionar revocación a instancias en vuelo de paymentApprovalProcess
        UUID sub = (UUID) row.get("subcontractor_id");
        runtimeService.createMessageCorrelation("ComplianceRevokedMessage")
            .processInstanceVariableEquals("subcontractorId", sub)
            .setVariable("motivoCancelacion", motivo)
            .correlateAllWithResult();
    }
}
