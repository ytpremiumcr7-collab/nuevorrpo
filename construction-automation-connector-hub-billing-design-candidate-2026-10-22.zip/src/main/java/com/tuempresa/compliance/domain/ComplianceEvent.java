package com.tuempresa.compliance.domain;

import com.tuempresa.platform.events.DomainEvent;

import java.time.LocalDate;
import java.util.UUID;

public class ComplianceEvent extends DomainEvent {
    private final UUID tenantId, requisitoId, subcontractorId, projectId, documentoId;
    private final String tipoRequisito, estadoVerificacion;
    private final LocalDate fechaVencimiento;
    private final long version;

    public ComplianceEvent(UUID tenantId, UUID requisitoId, UUID subcontractorId,
                           UUID projectId, UUID documentoId, String tipoRequisito,
                           String estadoVerificacion, LocalDate fechaVencimiento,
                           long version) {
        if (tenantId == null || requisitoId == null || subcontractorId == null
            || projectId == null || tipoRequisito == null
            || estadoVerificacion == null || fechaVencimiento == null) {
            throw new IllegalArgumentException("ComplianceEvent incompleto");
        }
        this.tenantId = tenantId; this.requisitoId = requisitoId;
        this.subcontractorId = subcontractorId; this.projectId = projectId;
        this.documentoId = documentoId; this.tipoRequisito = tipoRequisito;
        this.estadoVerificacion = estadoVerificacion;
        this.fechaVencimiento = fechaVencimiento; this.version = version;
    }
    public UUID tenantId() { return tenantId; }
    public UUID requisitoId() { return requisitoId; }
    public UUID subcontractorId() { return subcontractorId; }
    public UUID projectId() { return projectId; }
    public UUID documentoId() { return documentoId; }
    public String tipoRequisito() { return tipoRequisito; }
    public String estadoVerificacion() { return estadoVerificacion; }
    public LocalDate fechaVencimiento() { return fechaVencimiento; }
    @Override public UUID aggregateId() { return requisitoId; }
    @Override public long aggregateVersion() { return version; }
    @Override public String eventType() { return "ComplianceRequirementChanged"; }
    @Override public String aggregateType() { return "ComplianceRequirement"; }
}
