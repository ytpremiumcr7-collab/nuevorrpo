package com.tuempresa.compliance.web;

import com.tuempresa.compliance.service.ComplianceService;
import com.tuempresa.identity.security.UserContext;
import com.tuempresa.identity.service.ProjectAuthorizationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/compliance/requirements")
public class ComplianceController {
    private final ComplianceService service;
    private final ProjectAuthorizationService authorization;
    public ComplianceController(ComplianceService service, ProjectAuthorizationService authorization) {
        this.service = service; this.authorization = authorization;
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Map<String,Object> body) {
        UUID projectId = UUID.fromString((String) body.get("projectId"));
        authorization.requireProjectRole(projectId, UserContext.ProjectRole.OWNER, UserContext.ProjectRole.COMPLIANCE_LEAD);
        UUID requirementId = service.addRequirement(UUID.fromString((String) body.get("subcontractorId")), projectId,
            (String) body.get("tipoRequisito"), LocalDate.parse((String) body.get("fechaVencimiento")));
        return ResponseEntity.ok(Map.of("requisitoId", requirementId));
    }

    @PostMapping("/{id}/verify")
    public ResponseEntity<?> verify(@PathVariable UUID id, @RequestBody Map<String,Object> body) {
        authorization.requireEntityProject(ProjectAuthorizationService.Resource.REQUIREMENT, id,
            UserContext.ProjectRole.OWNER, UserContext.ProjectRole.COMPLIANCE_LEAD);
        service.verify(id, UUID.fromString((String) body.get("documentoId")));
        return ResponseEntity.ok().build();
    }

    @PostMapping("/{id}/revoke")
    public ResponseEntity<?> revoke(@PathVariable UUID id, @RequestBody Map<String,Object> body) {
        authorization.requireEntityProject(ProjectAuthorizationService.Resource.REQUIREMENT, id,
            UserContext.ProjectRole.OWNER, UserContext.ProjectRole.COMPLIANCE_LEAD);
        service.revoke(id, (String) body.get("motivo"),
            LocalDate.parse((String) body.getOrDefault("effectiveDate", LocalDate.now().toString())));
        return ResponseEntity.ok().build();
    }
}
