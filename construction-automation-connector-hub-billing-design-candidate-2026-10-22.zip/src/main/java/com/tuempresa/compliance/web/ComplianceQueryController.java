package com.tuempresa.compliance.web;

import com.tuempresa.identity.security.UserContext;
import com.tuempresa.platform.tenant.TenantContext;
import com.tuempresa.platform.web.PageResponse;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/compliance/queue")
public class ComplianceQueryController {
    private final JdbcTemplate jdbc;
    public ComplianceQueryController(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @GetMapping
    @Transactional(readOnly = true)
    public PageResponse<Map<String,Object>> listQueue(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        UUID tenant = TenantContext.require();
        UUID userId = UserContext.require().userId();
        if (page < 0 || size < 1 || size > 100) throw new IllegalArgumentException("page debe ser >= 0 y size entre 1 y 100");
        jdbc.queryForObject("SELECT set_config('app.tenant_id', ?, true)", String.class, tenant.toString());

        String fromWhere = " FROM compliance_subcontractor_head c WHERE c.tenant_id = ? AND c.estado_global = 'BLOQUEADO' " +
            "AND EXISTS (SELECT 1 FROM project_membership pm WHERE pm.tenant_id = c.tenant_id AND pm.project_id = c.project_id AND pm.user_id = ? AND pm.active = true)";
        long total = jdbc.queryForObject("SELECT count(*)" + fromWhere, Long.class, tenant, userId);
        var content = jdbc.queryForList("SELECT c.subcontractor_id, c.project_id, c.estado_global, c.requisito_critico_tipo, c.requisito_critico_vencimiento" +
            fromWhere + " ORDER BY c.requisito_critico_vencimiento NULLS LAST LIMIT ? OFFSET ?", tenant, userId, size, Math.multiplyExact(page, size));
        return new PageResponse<>(content, page, size, total);
    }
}
