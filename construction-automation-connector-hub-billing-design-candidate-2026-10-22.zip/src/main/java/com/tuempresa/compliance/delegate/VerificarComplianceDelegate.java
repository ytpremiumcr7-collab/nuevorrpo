package com.tuempresa.compliance.delegate;

import com.tuempresa.platform.tenant.ProjectTimezoneResolver;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;

@Component("verificarComplianceDelegate")
public class VerificarComplianceDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    private final ProjectTimezoneResolver tz;
    public VerificarComplianceDelegate(JdbcTemplate jdbc, ProjectTimezoneResolver tz) {
        this.jdbc = jdbc; this.tz = tz;
    }

    @Override
    @Transactional(readOnly = true)
    public void execute(DelegateExecution execution) {
        UUID tenant = asUuid(execution.getVariable("tenantId"));
        UUID sub = asUuid(execution.getVariable("subcontractorId"));
        UUID project = asUuid(execution.getVariable("projectId"));
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        Map<String,Object> head = jdbc.queryForMap(
            "SELECT estado_global, version_actual, requisito_critico_tipo, " +
            "requisito_critico_estado, requisito_critico_vencimiento, requisitos_total, " +
            "requisitos_vigentes, requisitos_bloqueados " +
            "FROM compliance_subcontractor_head " +
            "WHERE tenant_id = ? AND subcontractor_id = ? AND project_id = ?",
            tenant, sub, project);

        var hoy = LocalDate.now(tz.forProject(project));
        Object rawExpiry = head.get("requisito_critico_vencimiento");
        LocalDate expiry;
        if (rawExpiry instanceof java.sql.Date sqlDate) expiry = sqlDate.toLocalDate();
        else if (rawExpiry instanceof LocalDate localDate) expiry = localDate;
        else expiry = null;
        String globalState = String.valueOf(head.get("estado_global"));
        String criticalState = String.valueOf(head.get("requisito_critico_estado"));
        int total = ((Number) head.get("requisitos_total")).intValue();
        int valid = ((Number) head.get("requisitos_vigentes")).intValue();
        int blocked = ((Number) head.get("requisitos_bloqueados")).intValue();
        boolean validCompliance = "VIGENTE".equals(globalState)
            && total > 0 && valid == total && blocked == 0
            && "VERIFICADO".equals(criticalState)
            && expiry != null && !expiry.isBefore(hoy);

        execution.setVariable("tipoRequisito", head.get("requisito_critico_tipo"));
        execution.setVariable("fechaVencimiento", expiry);
        execution.setVariable("fechaActual", hoy);
        execution.setVariable("estadoGlobalCompliance", globalState);
        execution.setVariable("estadoVerificacion", criticalState);
        execution.setVariable("complianceValid", validCompliance);
        execution.setVariable("complianceVersionSeen", ((Number) head.get("version_actual")).longValue());
    }

    private static UUID asUuid(Object v) {
        if (v == null) throw new IllegalStateException("UUID variable null");
        if (v instanceof UUID u) return u;
        return UUID.fromString(v.toString());
    }
}
