package com.tuempresa.billing.web;

import com.tuempresa.billing.service.PaymentApplicationService;
import com.tuempresa.billing.service.PaymentInvalidationService;
import com.tuempresa.identity.security.UserContext;
import com.tuempresa.identity.service.ProjectAuthorizationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {
    private final PaymentApplicationService payments;
    private final PaymentInvalidationService invalidations;
    private final ProjectAuthorizationService authorization;

    public PaymentController(PaymentApplicationService payments, PaymentInvalidationService invalidations,
                             ProjectAuthorizationService authorization) {
        this.payments = payments; this.invalidations = invalidations; this.authorization = authorization;
    }

    @PostMapping("/applications")
    public ResponseEntity<?> submit(@RequestHeader("Idempotency-Key") String idempotencyKey,
                                    @RequestBody Map<String,Object> body) {
        UUID projectId = UUID.fromString((String) body.get("projectId"));
        authorization.requireProjectRole(projectId, UserContext.ProjectRole.OWNER, UserContext.ProjectRole.FINANCE);
        String processId = payments.submit(
            UUID.fromString((String) body.get("invoiceId")),
            UUID.fromString((String) body.get("subcontractorId")), projectId,
            new BigDecimal(body.get("monto").toString()), UUID.fromString((String) body.get("contractId")), idempotencyKey);
        return ResponseEntity.ok(Map.of("processInstanceId", processId));
    }

    @PostMapping("/{paymentId}/invalidate")
    public ResponseEntity<?> invalidate(@PathVariable UUID paymentId, @RequestBody Map<String,Object> body) {
        authorization.requireEntityProject(ProjectAuthorizationService.Resource.PAYMENT, paymentId,
            UserContext.ProjectRole.OWNER, UserContext.ProjectRole.FINANCE,
            UserContext.ProjectRole.COMPLIANCE_LEAD);
        UserContext.CurrentUser me = UserContext.require();
        UUID id = invalidations.invalidate(paymentId, (String) body.get("invalidityType"),
            UUID.fromString((String) body.get("evidenceId")), new BigDecimal(body.get("amount").toString()),
            (String) body.get("contractualBasis"), LocalDate.parse((String) body.get("effectiveDate")), me.userId());
        return ResponseEntity.ok(Map.of("invalidationId", id));
    }
}
