package com.tuempresa.billing.web;

import com.tuempresa.platform.tenant.TenantContext;
import com.tuempresa.identity.security.UserContext;
import org.springframework.transaction.annotation.Transactional;
import com.tuempresa.platform.web.PageResponse;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/invoices")
public class InvoiceQueryController {

    private final JdbcTemplate jdbc;

    public InvoiceQueryController(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @GetMapping
    @Transactional(readOnly = true)
    public PageResponse<Map<String, Object>> list(
            @RequestParam(required = false) String status,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        UUID tenant = TenantContext.require();
        UUID userId = UserContext.require().userId();
        jdbc.queryForObject("SELECT set_config('app.tenant_id', ?, true)", String.class, tenant.toString());
        if (page < 0 || size < 1 || size > 100) throw new IllegalArgumentException("page debe ser >= 0 y size entre 1 y 100");

        StringBuilder where = new StringBuilder(" WHERE i.tenant_id = ? AND EXISTS (SELECT 1 FROM project_membership pm WHERE pm.tenant_id = i.tenant_id AND pm.project_id = i.project_id AND pm.user_id = ? AND pm.active = true) ");
        List<Object> args = new ArrayList<>();
        args.add(tenant);
        args.add(userId);
        if (status != null && !status.isBlank()) {
            if (!status.matches("RECEIVED|MATCHING|MATCHED|MISMATCH|PENDING_APPROVAL|APPROVED|REJECTED|PAID|CANCELLED")) throw new IllegalArgumentException("status inválido");
            where.append(" AND i.status = ?::invoice_status ");
            args.add(status);
        }

        Long total = jdbc.queryForObject(
            "SELECT count(*) FROM invoice i" + where, Long.class, args.toArray());

        List<Object> pageArgs = new ArrayList<>(args);
        pageArgs.add(size);
        pageArgs.add(page * size);
        var content = jdbc.queryForList(
            "SELECT i.invoice_id, i.invoice_number, i.amount, i.status, i.received_at FROM invoice i" +
            where + " ORDER BY i.received_at DESC LIMIT ? OFFSET ?",
            pageArgs.toArray());
        return new PageResponse<>(content, page, size, total == null ? 0 : total);
    }
}
