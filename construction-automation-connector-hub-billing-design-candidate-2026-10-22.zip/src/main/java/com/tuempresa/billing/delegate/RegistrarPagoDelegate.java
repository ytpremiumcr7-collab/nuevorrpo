package com.tuempresa.billing.delegate;

import com.tuempresa.platform.metrics.OutboxMetrics;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.Map;
import java.util.Locale;
import java.util.UUID;

/**
 * Registra una instrucción PENDING después de validar match y compliance.
 * No ejecuta transferencia bancaria; exige evidencia durable de aprobación de política, no aprobación humana.
 */
@Component("registrarPagoDelegate")
public class RegistrarPagoDelegate implements JavaDelegate {
    private final JdbcTemplate jdbc;
    private final OutboxMetrics metrics;

    public RegistrarPagoDelegate(JdbcTemplate jdbc, OutboxMetrics metrics) {
        this.jdbc = jdbc; this.metrics = metrics;
    }

    @Override
    @Transactional
    public void execute(DelegateExecution execution) {
        UUID tenant = requiredUuid(execution.getVariable("tenantId"), "tenantId");
        UUID invoiceId = requiredUuid(execution.getVariable("invoiceId"), "invoiceId");
        UUID sub = requiredUuid(execution.getVariable("subcontractorId"), "subcontractorId");
        UUID project = requiredUuid(execution.getVariable("projectId"), "projectId");
        UUID contractId = requiredUuid(execution.getVariable("contractId"), "contractId");
        Object rawAmount = execution.getVariable("montoFactura");
        if (!(rawAmount instanceof BigDecimal amount) || amount.signum() <= 0) {
            throw new IllegalStateException("montoFactura debe ser BigDecimal positivo");
        }
        UUID applicationId = requiredUuid(execution.getVariable("paymentApplicationId"), "paymentApplicationId");
        Object rawVersion = execution.getVariable("complianceVersionSeen");
        if (!(rawVersion instanceof Number version)) {
            throw new IllegalStateException("Falta complianceVersionSeen; no se registra instrucción");
        }
        long complianceVersion = version.longValue();
        jdbc.queryForObject("SELECT set_config('app.tenant_id', ?, true)", String.class, tenant.toString());

        // Defense in depth: BPMN reachability alone is not approval evidence.
        String processPolicyVersion = requiredText(execution.getVariable("approvalPolicyVersion"), "approvalPolicyVersion");
        String processApprovalRoute = requiredText(execution.getVariable("approvalRoute"), "approvalRoute");
        Map<String, Object> approval;
        try {
            approval = jdbc.queryForMap("SELECT d.approval_route, d.decision_source, d.decision, d.approved_amount, " +
                "d.policy_version, pa.status, pa.amount_approved, pa.approval_route AS application_route, " +
                "pa.approval_policy_version, pa.project_id FROM payment_approval_decision d " +
                "JOIN payment_application pa ON pa.tenant_id = d.tenant_id AND pa.payment_application_id = d.payment_application_id " +
                "WHERE d.tenant_id = ? AND d.payment_application_id = ? AND d.project_id = ? " +
                "AND d.decision_source = 'POLICY' AND d.decision = 'APPROVED' FOR SHARE OF d, pa",
                tenant, applicationId, project);
        } catch (EmptyResultDataAccessException e) {
            throw new IllegalStateException("No existe evidencia durable de aprobación de política; no se registra instrucción", e);
        }
        if (!"AUTOMATICA".equals(processApprovalRoute)
                || !"AUTOMATICA".equals(approval.get("approval_route"))
                || !"POLICY".equals(approval.get("decision_source"))
                || !"APPROVED".equals(approval.get("decision"))
                || !processPolicyVersion.equals(String.valueOf(approval.get("policy_version")))
                || !processPolicyVersion.equals(String.valueOf(approval.get("approval_policy_version")))
                || !"MXN".equals(requiredCurrency(invoiceCurrencyVariable(execution), "moneda de proceso"))
                || !project.equals(approval.get("project_id"))
                || amount.compareTo((BigDecimal) approval.get("approved_amount")) != 0
                || amount.compareTo((BigDecimal) approval.get("amount_approved")) != 0
                || !"APPROVED".equals(approval.get("status")) && !"PAYMENT_PENDING".equals(approval.get("status"))) {
            throw new IllegalStateException("La evidencia de aprobación no coincide con el proceso/solicitud; no se registra instrucción");
        }

        // Los reintentos de Camunda deben ser idempotentes: no crear un pago por segunda vez.
        var existing = jdbc.query("SELECT payment_id, invoice_id, amount, status FROM payment " +
                "WHERE tenant_id = ? AND payment_application_id = ?",
            (rs, rowNum) -> Map.of(
                "paymentId", rs.getObject("payment_id", UUID.class),
                "invoiceId", rs.getObject("invoice_id", UUID.class),
                "amount", rs.getBigDecimal("amount"),
                "status", rs.getString("status")), tenant, applicationId);
        if (!existing.isEmpty()) {
            Map<String, Object> prior = existing.get(0);
            if (!invoiceId.equals(prior.get("invoiceId")) || amount.compareTo((BigDecimal) prior.get("amount")) != 0) {
                throw new IllegalStateException("La solicitud ya tiene un pago incompatible asociado");
            }
            execution.setVariable("paymentId", prior.get("paymentId"));
            execution.setVariable("paymentStatus", prior.get("status"));
            return;
        }

        Map<String, Object> invoice;
        try {
            invoice = jdbc.queryForMap("SELECT project_id, contract_id, subcontractor_id, amount, currency " +
                "FROM invoice WHERE tenant_id = ? AND invoice_id = ? FOR UPDATE", tenant, invoiceId);
        } catch (EmptyResultDataAccessException e) {
            throw new IllegalStateException("Factura no encontrada durante el registro", e);
        }
        if (!project.equals(invoice.get("project_id")) || !contractId.equals(invoice.get("contract_id"))
                || !sub.equals(invoice.get("subcontractor_id"))) {
            throw new IllegalStateException("IDs de workflow no coinciden con la factura persistida");
        }
        BigDecimal invoiceAmount = (BigDecimal) invoice.get("amount");
        if (amount.compareTo(invoiceAmount) > 0) throw new IllegalStateException("Monto excede factura");
        BigDecimal otherOpenApplications = jdbc.queryForObject(
            "SELECT COALESCE(sum(pa.amount_requested), 0) FROM payment_application pa " +
            "WHERE pa.tenant_id = ? AND pa.invoice_id = ? AND pa.payment_application_id <> ? " +
            "AND pa.status IN ('PENDING_APPROVAL', 'AWAITING_APPROVAL', 'APPROVED', 'PAYMENT_PENDING') " +
            "AND NOT EXISTS (SELECT 1 FROM payment p WHERE p.tenant_id = pa.tenant_id " +
            "AND p.payment_application_id = pa.payment_application_id)",
            BigDecimal.class, tenant, invoiceId, applicationId);
        BigDecimal otherReservedPayments = jdbc.queryForObject(
            "SELECT COALESCE(sum(p.amount), 0) FROM payment p " +
            "WHERE p.tenant_id = ? AND p.invoice_id = ? AND p.payment_application_id <> ? " +
            "AND p.status IN ('PENDING'::payment_status, 'EXECUTED'::payment_status, 'FAILED'::payment_status)",
            BigDecimal.class, tenant, invoiceId, applicationId);
        if (otherOpenApplications.add(otherReservedPayments).add(amount).compareTo(invoiceAmount) > 0) {
            metrics.paymentsBlocked.increment();
            throw new IllegalStateException("La instrucción más otras reservas excedería el total de la factura");
        }
        String currency = requiredCurrency(invoice.get("currency"), "moneda de factura");
        Map<String, Object> contract;
        try {
            contract = jdbc.queryForMap(
                "SELECT project_id, currency FROM contract WHERE tenant_id = ? AND contract_id = ? FOR SHARE",
                tenant, contractId);
        } catch (EmptyResultDataAccessException e) {
            throw new IllegalStateException("Contrato no encontrado al crear la instrucción", e);
        }
        if (!project.equals(contract.get("project_id"))) {
            throw new IllegalStateException("El contrato persistido ya no pertenece al proyecto de la factura");
        }
        String contractCurrency = requiredCurrency(contract.get("currency"), "moneda de contrato");
        if (!currency.equals(contractCurrency)) {
            throw new IllegalStateException("La moneda de factura y contrato no coincide; no se registra instrucción");
        }

        Map<String, Object> head = jdbc.queryForMap("SELECT estado_global, version_actual " +
            "FROM compliance_subcontractor_head WHERE tenant_id = ? AND subcontractor_id = ? AND project_id = ? FOR UPDATE",
            tenant, sub, project);
        if (!"VIGENTE".equals(head.get("estado_global"))
                || ((Number) head.get("version_actual")).longValue() != complianceVersion) {
            metrics.paymentsBlocked.increment();
            throw new IllegalStateException("Compliance cambió o dejó de estar VIGENTE; revalidar antes de continuar");
        }

        Object matchResult = execution.getVariable("matchResult");
        if (!(matchResult instanceof Map<?, ?> match)) throw new IllegalStateException("Falta matchResult persistido");
        UUID matchId = requiredUuid(match.get("matchId"), "matchResult.matchId");
        String matchState = jdbc.queryForObject("SELECT estado FROM three_way_match_result " +
            "WHERE tenant_id = ? AND match_id = ? AND invoice_id = ? FOR SHARE", String.class,
            tenant, matchId, invoiceId);
        if (!"MATCH".equals(matchState) || !"MATCH".equals(String.valueOf(match.get("estado")))) {
            throw new IllegalStateException("Three-way match no válido; no se registra instrucción de pago");
        }

        BigDecimal contractLimit;
        try {
            contractLimit = jdbc.queryForObject("SELECT effective_amount FROM billing_contract_projection " +
                "WHERE tenant_id = ? AND contract_id = ? FOR UPDATE", BigDecimal.class, tenant, contractId);
        } catch (EmptyResultDataAccessException e) {
            contractLimit = jdbc.queryForObject("SELECT amount FROM contract WHERE tenant_id = ? AND contract_id = ? FOR UPDATE",
                BigDecimal.class, tenant, contractId);
        }
        BigDecimal reserved = jdbc.queryForObject("SELECT COALESCE(sum(p.amount), 0) FROM payment p " +
            "JOIN invoice i ON i.tenant_id = p.tenant_id AND i.invoice_id = p.invoice_id " +
            "WHERE p.tenant_id = ? AND i.contract_id = ? AND p.status IN ('PENDING'::payment_status, 'EXECUTED'::payment_status)",
            BigDecimal.class, tenant, contractId);
        if (reserved.add(amount).compareTo(contractLimit) > 0) {
            throw new IllegalStateException("La instrucción excedería el monto efectivo del contrato");
        }

        int updated = jdbc.update("UPDATE payment_application SET status = 'PAYMENT_PENDING', " +
            "match_id = ?, compliance_version_seen = ?, aggregate_version = aggregate_version + 1, updated_at = now() " +
            "WHERE tenant_id = ? AND payment_application_id = ? AND invoice_id = ? " +
            "AND project_id = ? AND subcontractor_id = ? AND amount_requested = ? " +
            "AND amount_approved = ? AND approval_route = 'AUTOMATICA' " +
            "AND approval_policy_version = ? AND status = 'APPROVED'",
            matchId, complianceVersion, tenant, applicationId, invoiceId, project, sub, amount, amount, processPolicyVersion);
        if (updated != 1) throw new IllegalStateException("Solicitud de pago ausente o en estado no permitido");

        UUID paymentId = UUID.randomUUID();
        jdbc.update("INSERT INTO payment (tenant_id, payment_id, invoice_id, payment_application_id, " +
            "project_id, subcontractor_id, amount, currency, executed_at, status, compliance_version_seen) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, 'PENDING', ?)",
            tenant, paymentId, invoiceId, applicationId, project, sub, amount, currency, complianceVersion);
        jdbc.update("INSERT INTO payment_read_model (tenant_id, payment_id, invoice_id, project_id, " +
            "subcontractor_id, amount, status, executed_at, compliance_version_seen) " +
            "VALUES (?, ?, ?, ?, ?, ?, 'PENDING', NULL, ?)",
            tenant, paymentId, invoiceId, project, sub, amount, complianceVersion);
        execution.setVariable("paymentId", paymentId);
        execution.setVariable("paymentStatus", "PENDING");
    }

    private static Object invoiceCurrencyVariable(DelegateExecution execution) {
        Object currency = execution.getVariable("monedaFactura");
        if (currency == null) currency = execution.getVariable("invoiceCurrency");
        return currency;
    }

    private static String requiredText(Object raw, String name) {
        if (raw == null || raw.toString().isBlank()) throw new IllegalStateException("Falta " + name);
        return raw.toString().trim();
    }

    private static String requiredCurrency(Object raw, String name) {
        if (raw == null) throw new IllegalStateException("Falta " + name);
        String currency = raw.toString().trim().toUpperCase(Locale.ROOT);
        if (!currency.matches("[A-Z]{3}")) {
            throw new IllegalStateException("Código de moneda inválido en " + name);
        }
        return currency;
    }

    private static UUID requiredUuid(Object value, String name) {
        if (value == null) throw new IllegalStateException("Falta UUID requerido: " + name);
        if (value instanceof UUID uuid) return uuid;
        try { return UUID.fromString(value.toString()); }
        catch (IllegalArgumentException e) { throw new IllegalStateException("UUID inválido: " + name, e); }
    }
}
