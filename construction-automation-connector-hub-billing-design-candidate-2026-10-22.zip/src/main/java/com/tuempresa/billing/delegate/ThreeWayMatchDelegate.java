package com.tuempresa.billing.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

@Component("threeWayMatchDelegate")
public class ThreeWayMatchDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    private static final BigDecimal PCT_TOL = new BigDecimal("0.02");
    private static final BigDecimal ABS_TOL = new BigDecimal("25.00");

    public ThreeWayMatchDelegate(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    @Transactional
    public void execute(DelegateExecution execution) {
        UUID tenant = asUuid(execution.getVariable("tenantId"));
        UUID invoiceId = asUuid(execution.getVariable("invoiceId"));
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        Map<String,Object> inv = jdbc.queryForMap(
            "SELECT po_reference, amount, project_id FROM invoice WHERE tenant_id = ? AND invoice_id = ? FOR SHARE",
            tenant, invoiceId);
        UUID invoiceProjectId = (UUID) inv.get("project_id");
        String poNumber = (String) inv.get("po_reference");
        if (poNumber == null || poNumber.isBlank()) {
            throw new IllegalStateException("Factura " + invoiceId + " sin po_reference");
        }
        UUID poId;
        try {
            poId = jdbc.queryForObject(
                "SELECT po_id FROM purchase_order WHERE tenant_id = ? AND po_number = ? AND project_id = ?",
                UUID.class, tenant, poNumber, invoiceProjectId);
        } catch (org.springframework.dao.EmptyResultDataAccessException e) {
            throw new IllegalStateException(
                "PO '" + poNumber + "' no encontrada para factura " + invoiceId);
        }

        List<Map<String,Object>> invLines = jdbc.queryForList(
            "SELECT line_number, quantity, unit_price FROM invoice_line " +
            "WHERE tenant_id = ? AND invoice_id = ? ORDER BY line_number", tenant, invoiceId);
        List<Map<String,Object>> poLines = jdbc.queryForList(
            "SELECT po_line_id, line_number, quantity, unit_price FROM purchase_order_line " +
            "WHERE tenant_id = ? AND po_id = ? ORDER BY line_number", tenant, poId);

        if (invLines.isEmpty() || poLines.isEmpty()) {
            throw new IllegalStateException("Factura o PO sin líneas");
        }
        BigDecimal invoiceHeaderAmount = (BigDecimal) inv.get("amount");
        BigDecimal invoiceLineTotal = invLines.stream()
            .map(line -> ((BigDecimal) line.get("quantity")).multiply((BigDecimal) line.get("unit_price")))
            .reduce(BigDecimal.ZERO, BigDecimal::add)
            .setScale(2, RoundingMode.HALF_UP);
        if (invoiceHeaderAmount.setScale(2, RoundingMode.HALF_UP).compareTo(invoiceLineTotal) != 0) {
            UUID mismatchId = UUID.randomUUID();
            String mismatchJson = "[{\"tipo\":\"MISMATCH_FACTURA_TOTAL\",\"encabezado\":\"" +
                invoiceHeaderAmount.toPlainString() + "\",\"sumaLineas\":\"" +
                invoiceLineTotal.toPlainString() + "\"}]";
            jdbc.update("INSERT INTO three_way_match_result " +
                "(tenant_id, match_id, invoice_id, estado, tolerancia_aplicada, diferencias, event_id) " +
                "VALUES (?, ?, ?, 'MISMATCH_FACTURA_TOTAL', ?, ?::jsonb, ?)",
                tenant, mismatchId, invoiceId, PCT_TOL, mismatchJson, UUID.randomUUID());
            execution.setVariable("matchResult", Map.of("estado", "MISMATCH_FACTURA_TOTAL", "matchId", mismatchId.toString()));
            return;
        }
        if (invLines.size() != poLines.size()) {
            throw new IllegalStateException("Factura y orden de compra no tienen la misma cantidad de líneas");
        }
        Set<Integer> invoiceLineNumbers = new HashSet<>();
        for (var line : invLines) {
            if (!invoiceLineNumbers.add(((Number) line.get("line_number")).intValue())) {
                throw new IllegalStateException("Factura con números de línea duplicados");
            }
        }
        Set<Integer> poLineNumbers = new HashSet<>();
        for (var line : poLines) {
            if (!poLineNumbers.add(((Number) line.get("line_number")).intValue())) {
                throw new IllegalStateException("Orden de compra con números de línea duplicados");
            }
        }
        if (!invoiceLineNumbers.equals(poLineNumbers)) {
            throw new IllegalStateException("Factura y orden de compra no contienen las mismas líneas");
        }

        List<Map<String,Object>> receipts = jdbc.queryForList(
            "SELECT grl.po_line_id, grl.quantity_received FROM goods_receipt_line grl " +
            "JOIN goods_receipt gr ON gr.tenant_id = grl.tenant_id AND gr.receipt_id = grl.receipt_id " +
            "WHERE gr.tenant_id = ? AND gr.po_id = ?", tenant, poId);
        Map<UUID, BigDecimal> receivedByPoLine = new HashMap<>();
        for (var r : receipts) {
            receivedByPoLine.merge((UUID) r.get("po_line_id"),
                (BigDecimal) r.get("quantity_received"), BigDecimal::add);
        }

        List<Map<String,Object>> diffs = new ArrayList<>();
        String estado = "MATCH";
        for (var poLine : poLines) {
            UUID poLineId = (UUID) poLine.get("po_line_id");
            int lineNo = (Integer) poLine.get("line_number");
            BigDecimal poQty = (BigDecimal) poLine.get("quantity");
            BigDecimal poPrice = (BigDecimal) poLine.get("unit_price");

            var invLine = invLines.stream()
                .filter(l -> ((Integer) l.get("line_number")).intValue() == lineNo)
                .findFirst().orElse(null);
            if (invLine == null) {
                diffs.add(Map.of("line", lineNo, "tipo", "FALTA_LINEA"));
                estado = "MISMATCH_CANTIDAD"; continue;
            }
            BigDecimal invQty = (BigDecimal) invLine.get("quantity");
            BigDecimal invPrice = (BigDecimal) invLine.get("unit_price");
            BigDecimal qtyTol = poQty.multiply(PCT_TOL).min(ABS_TOL);
            if (invQty.subtract(poQty).abs().compareTo(qtyTol) > 0) {
                diffs.add(Map.of("line", lineNo, "tipo", "MISMATCH_CANTIDAD"));
                estado = "MISMATCH_CANTIDAD";
            }
            BigDecimal priceTol = poPrice.multiply(PCT_TOL).min(ABS_TOL);
            if (invPrice.subtract(poPrice).abs().compareTo(priceTol) > 0) {
                diffs.add(Map.of("line", lineNo, "tipo", "MISMATCH_PRECIO"));
                estado = "MISMATCH_PRECIO";
            }
            BigDecimal received = receivedByPoLine.getOrDefault(poLineId, BigDecimal.ZERO);
            if (received.compareTo(invQty) < 0) {
                diffs.add(Map.of("line", lineNo, "tipo", "SIN_RECIBO"));
                estado = "SIN_RECIBO";
            }
        }

        UUID matchId = UUID.randomUUID();
        try {
            String diffsJson = new com.fasterxml.jackson.databind.ObjectMapper()
                .writeValueAsString(diffs);
            jdbc.update("""
                INSERT INTO three_way_match_result
                  (tenant_id, match_id, invoice_id, estado, tolerancia_aplicada,
                   diferencias, event_id)
                VALUES (?, ?, ?, ?, ?, ?::jsonb, ?)
                """,
                tenant, matchId, invoiceId, estado, PCT_TOL,
                diffsJson, UUID.randomUUID());
        } catch (Exception e) {
            throw new RuntimeException("No se pudo persistir el match", e);
        }

        execution.setVariable("matchResult",
            Map.of("estado", estado, "matchId", matchId.toString()));
    }

    private static UUID asUuid(Object v) {
        if (v == null) throw new IllegalStateException("UUID variable null");
        if (v instanceof UUID u) return u;
        return UUID.fromString(v.toString());
    }
}
