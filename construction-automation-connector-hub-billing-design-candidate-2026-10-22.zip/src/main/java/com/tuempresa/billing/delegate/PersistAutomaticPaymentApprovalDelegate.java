package com.tuempresa.billing.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Persists the exact versioned DMN auto-approval before payment registration. */
@Component("persistAutomaticPaymentApprovalDelegate")
public class PersistAutomaticPaymentApprovalDelegate implements JavaDelegate {
    private final JdbcTemplate jdbc;

    public PersistAutomaticPaymentApprovalDelegate(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    @Transactional
    public void execute(DelegateExecution execution) {
        UUID tenant = requiredUuid(execution.getVariable("tenantId"), "tenantId");
        UUID applicationId = requiredUuid(execution.getVariable("paymentApplicationId"), "paymentApplicationId");
        UUID invoiceId = requiredUuid(execution.getVariable("invoiceId"), "invoiceId");
        UUID projectId = requiredUuid(execution.getVariable("projectId"), "projectId");
        UUID contractId = requiredUuid(execution.getVariable("contractId"), "contractId");
        UUID subcontractorId = requiredUuid(execution.getVariable("subcontractorId"), "subcontractorId");
        BigDecimal amount = requiredAmount(execution.getVariable("montoFactura"));

        Object raw = execution.getVariable("approvalDecision");
        if (!(raw instanceof Map<?, ?> decision)) {
            throw new IllegalStateException("Falta resultado durable de nivelAprobacionPago");
        }
        Object manualReview = decision.get("requiereRevisionManual");
        String route = requiredText(decision.get("rutaAprobacion"), "rutaAprobacion");
        String policyVersion = requiredText(decision.get("policyVersion"), "policyVersion");
        if (!Boolean.FALSE.equals(manualReview) || !"AUTOMATICA".equals(route)) {
            throw new IllegalStateException("Solo una decisión automática explícita puede persistirse como aprobación de política");
        }
        if (!"nivelAprobacionPago-v2-MXN".equals(policyVersion)) {
            throw new IllegalStateException("Versión de política desconocida; se requiere revisión antes de crear una instrucción");
        }
        String currency = requiredText(execution.getVariable("monedaFactura"), "monedaFactura");
        if (!"MXN".equals(currency)) {
            throw new IllegalStateException("La aprobación automática no está habilitada para una moneda distinta de MXN");
        }
        // Defense in depth against an accidental/mutated DMN result; the policy version is bounded to this threshold.
        if (amount.compareTo(new BigDecimal("1000.00")) >= 0) {
            throw new IllegalStateException("El umbral de aprobación automática de esta versión no permite montos de 1000 MXN o superiores");
        }
        jdbc.queryForObject("SELECT set_config('app.tenant_id', ?, true)", String.class, tenant.toString());

        Map<String, Object> application = jdbc.queryForMap(
            "SELECT project_id, invoice_id, contract_id, subcontractor_id, amount_requested, amount_approved, " +
                "status, approval_route, approval_policy_version FROM payment_application " +
                "WHERE tenant_id = ? AND payment_application_id = ? FOR UPDATE",
            tenant, applicationId);
        if (!projectId.equals(application.get("project_id"))
                || !invoiceId.equals(application.get("invoice_id"))
                || !contractId.equals(application.get("contract_id"))
                || !subcontractorId.equals(application.get("subcontractor_id"))
                || amount.compareTo((BigDecimal) application.get("amount_requested")) != 0) {
            throw new IllegalStateException("Contexto de solicitud no coincide con la decisión de política");
        }

        List<Map<String, Object>> prior = jdbc.queryForList(
            "SELECT approval_id, project_id, approval_route, decision_source, decision, approved_amount, policy_version " +
                "FROM payment_approval_decision WHERE tenant_id = ? AND payment_application_id = ? " +
                "AND decision_source = 'POLICY' ORDER BY decided_at DESC FOR SHARE",
            tenant, applicationId);
        if (!prior.isEmpty()) {
            if (prior.size() != 1) throw new IllegalStateException("Hay varias decisiones de política; requiere revisión de datos");
            Map<String, Object> d = prior.get(0);
            boolean same = projectId.equals(d.get("project_id"))
                && route.equals(d.get("approval_route"))
                && "POLICY".equals(d.get("decision_source"))
                && "APPROVED".equals(d.get("decision"))
                && amount.compareTo((BigDecimal) d.get("approved_amount")) == 0
                && policyVersion.equals(d.get("policy_version"));
            if (!same) throw new IllegalStateException("La decisión de política previa no coincide; no se permite reescribir evidencia");
            String state = String.valueOf(application.get("status"));
            if (!"APPROVED".equals(state) && !"PAYMENT_PENDING".equals(state)) {
                throw new IllegalStateException("Evidencia de aprobación existe pero el estado de solicitud es inconsistente");
            }
            execution.setVariable("paymentApprovalId", d.get("approval_id"));
            execution.setVariable("approvalPolicyVersion", policyVersion);
            execution.setVariable("approvalRoute", route);
            return;
        }

        if (!"PENDING_APPROVAL".equals(application.get("status"))) {
            throw new IllegalStateException("La solicitud ya no está en estado PENDING_APPROVAL");
        }
        UUID approvalId = UUID.randomUUID();
        String reason = "Aprobación automática por la decisión " + policyVersion + " para una solicitud MXN bajo el umbral configurado.";
        jdbc.update("INSERT INTO payment_approval_decision " +
            "(tenant_id, approval_id, payment_application_id, project_id, approval_route, decision_source, " +
            "decision, approved_amount, policy_version, decision_reason, decided_by) " +
            "VALUES (?, ?, ?, ?, ?, 'POLICY', 'APPROVED', ?, ?, ?, NULL)",
            tenant, approvalId, applicationId, projectId, route, amount, policyVersion, reason);
        int updated = jdbc.update("UPDATE payment_application SET amount_approved = ?, status = 'APPROVED', " +
            "approval_route = ?, approval_policy_version = ?, aggregate_version = aggregate_version + 1, updated_at = now() " +
            "WHERE tenant_id = ? AND payment_application_id = ? AND status = 'PENDING_APPROVAL' " +
            "AND amount_requested = ? AND project_id = ?",
            amount, route, policyVersion, tenant, applicationId, amount, projectId);
        if (updated != 1) throw new IllegalStateException("No se pudo transicionar la solicitud a APPROVED; transacción abortada");

        execution.setVariable("paymentApprovalId", approvalId);
        execution.setVariable("approvalPolicyVersion", policyVersion);
        execution.setVariable("approvalRoute", route);
    }

    private static BigDecimal requiredAmount(Object raw) {
        if (!(raw instanceof BigDecimal amount) || amount.signum() <= 0) {
            throw new IllegalStateException("montoFactura debe ser BigDecimal positivo");
        }
        return amount;
    }

    private static String requiredText(Object raw, String field) {
        if (raw == null || raw.toString().isBlank()) throw new IllegalStateException("Falta " + field);
        return raw.toString().trim();
    }

    private static UUID requiredUuid(Object raw, String field) {
        if (raw == null) throw new IllegalStateException("Falta UUID requerido: " + field);
        if (raw instanceof UUID uuid) return uuid;
        try { return UUID.fromString(raw.toString()); }
        catch (IllegalArgumentException e) { throw new IllegalStateException("UUID inválido: " + field, e); }
    }
}
