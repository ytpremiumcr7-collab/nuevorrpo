package com.tuempresa.billing.event;
import java.math.BigDecimal;
import java.util.UUID;
public record ChangeOrderApprovedEvent(
    UUID tenantId, UUID contractId, UUID changeOrderId, BigDecimal amount) {}
