package com.tuempresa.billing.event;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

public record PaymentInvalidatedEvent(
    UUID tenantId, UUID paymentId, UUID subcontractorId, UUID projectId,
    String invalidityType, UUID evidenceId, BigDecimal amount,
    String contractualBasis, LocalDate effectiveDate) {}
