package com.tuempresa.billing.service;

import com.tuempresa.platform.metrics.OutboxMetrics;
import com.tuempresa.platform.tenant.TenantContext;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.Locale;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class PaymentApplicationService {
    private final JdbcTemplate jdbc;
    private final RuntimeService runtimeService;
    private final OutboxMetrics metrics;

    public PaymentApplicationService(JdbcTemplate jdbc, RuntimeService runtimeService, OutboxMetrics metrics) {
        this.jdbc = jdbc; this.runtimeService = runtimeService; this.metrics = metrics;
    }

    @Transactional
    public String submit(UUID invoiceId, UUID subcontractorId, UUID projectId,
                         BigDecimal amount, UUID contractId, String idempotencyKey) {
        UUID tenant = TenantContext.require();
        jdbc.queryForObject("SELECT set_config('app.tenant_id', ?, true)", String.class, tenant.toString());
        if (idempotencyKey == null || idempotencyKey.isBlank() || idempotencyKey.length() > 200
                || !idempotencyKey.matches("[A-Za-z0-9._:-]{16,200}")) {
            metrics.paymentsBlocked.increment();
            throw new IllegalArgumentException("Idempotency-Key es obligatorio y debe tener 16-200 caracteres seguros");
        }
        if (invoiceId == null || subcontractorId == null || projectId == null || contractId == null || amount == null) {
            metrics.paymentsBlocked.increment();
            throw new IllegalArgumentException("Factura, obra, contrato, subcontratista y monto son obligatorios");
        }
        if (amount.signum() <= 0) {
            metrics.paymentsBlocked.increment();
            throw new IllegalArgumentException("El monto solicitado debe ser positivo");
        }
        try {
            amount = amount.setScale(2, RoundingMode.UNNECESSARY);
        } catch (ArithmeticException e) {
            metrics.paymentsBlocked.increment();
            throw new IllegalArgumentException("El monto debe tener como máximo dos decimales monetarios", e);
        }
        String requestHash = requestHash(invoiceId, subcontractorId, projectId, contractId, amount);
        // Serialize identical idempotency keys even if requests point at different invoice rows.
        jdbc.query("SELECT pg_advisory_xact_lock(hashtextextended(?, 0))",
            (org.springframework.jdbc.core.RowCallbackHandler) rs -> {},
            tenant + ":payment-application:" + idempotencyKey);
        var priorRequests = jdbc.queryForList("SELECT payment_application_id, process_instance_id, " +
            "submission_request_hash, invoice_id, subcontractor_id, project_id, contract_id, amount_requested " +
            "FROM payment_application WHERE tenant_id = ? AND submission_idempotency_key = ? FOR UPDATE",
            tenant, idempotencyKey);
        if (!priorRequests.isEmpty()) {
            Map<String, Object> prior = priorRequests.get(0);
            boolean same = requestHash.equals(String.valueOf(prior.get("submission_request_hash")))
                && invoiceId.equals(prior.get("invoice_id"))
                && subcontractorId.equals(prior.get("subcontractor_id"))
                && projectId.equals(prior.get("project_id"))
                && contractId.equals(prior.get("contract_id"))
                && amount.compareTo((BigDecimal) prior.get("amount_requested")) == 0;
            if (!same) {
                metrics.paymentsBlocked.increment();
                throw new IllegalStateException("Idempotency-Key reutilizada con un cuerpo distinto o contexto persistido inconsistente");
            }
            Object processId = prior.get("process_instance_id");
            if (!(processId instanceof String process) || process.isBlank()) {
                throw new IllegalStateException("La solicitud idempotente previa carece de process_instance_id; revisión operativa requerida");
            }
            return process;
        }
        if (invoiceId == null || subcontractorId == null || projectId == null || contractId == null
                || amount == null || amount.signum() <= 0) {
            metrics.paymentsBlocked.increment();
            throw new IllegalArgumentException("Factura, obra, contrato, subcontratista y monto positivo son obligatorios");
        }
        Map<String, Object> invoice;
        try {
            invoice = jdbc.queryForMap("SELECT project_id, contract_id, subcontractor_id, amount, currency, status " +
                "FROM invoice WHERE tenant_id = ? AND invoice_id = ? FOR UPDATE", tenant, invoiceId);
        } catch (EmptyResultDataAccessException e) {
            metrics.paymentsBlocked.increment();
            throw new IllegalArgumentException("Factura no encontrada en este tenant", e);
        }
        if (!projectId.equals(invoice.get("project_id"))
                || !contractId.equals(invoice.get("contract_id"))
                || !subcontractorId.equals(invoice.get("subcontractor_id"))) {
            metrics.paymentsBlocked.increment();
            throw new IllegalArgumentException("Los IDs enviados no coinciden con la factura persistida");
        }
        BigDecimal invoiceAmount = (BigDecimal) invoice.get("amount");
        if (amount.compareTo(invoiceAmount) > 0) {
            metrics.paymentsBlocked.increment();
            throw new IllegalArgumentException("El monto solicitado excede el importe de la factura");
        }
        if ("CANCELLED".equals(String.valueOf(invoice.get("status")))
                || "PAID".equals(String.valueOf(invoice.get("status")))) {
            metrics.paymentsBlocked.increment();
            throw new IllegalStateException("La factura está cancelada o pagada");
        }
        BigDecimal pendingApplications = jdbc.queryForObject(
            "SELECT COALESCE(sum(pa.amount_requested), 0) FROM payment_application pa " +
            "WHERE pa.tenant_id = ? AND pa.invoice_id = ? " +
            "AND pa.status IN ('PENDING_APPROVAL', 'AWAITING_APPROVAL', 'APPROVED', 'PAYMENT_PENDING') " +
            "AND NOT EXISTS (SELECT 1 FROM payment p WHERE p.tenant_id = pa.tenant_id " +
            "AND p.payment_application_id = pa.payment_application_id)",
            BigDecimal.class, tenant, invoiceId);
        BigDecimal reservedPayments = jdbc.queryForObject(
            "SELECT COALESCE(sum(p.amount), 0) FROM payment p WHERE p.tenant_id = ? AND p.invoice_id = ? " +
            "AND p.status IN ('PENDING'::payment_status, 'EXECUTED'::payment_status, 'FAILED'::payment_status)",
            BigDecimal.class, tenant, invoiceId);
        if (pendingApplications.add(reservedPayments).add(amount).compareTo(invoiceAmount) > 0) {
            metrics.paymentsBlocked.increment();
            throw new IllegalStateException("El total solicitado más las solicitudes/instrucciones reservadas excede el importe de la factura");
        }
        Map<String, Object> contractRow;
        try {
            contractRow = jdbc.queryForMap(
                "SELECT project_id, currency FROM contract WHERE tenant_id = ? AND contract_id = ? FOR SHARE",
                tenant, contractId);
        } catch (EmptyResultDataAccessException e) {
            metrics.paymentsBlocked.increment();
            throw new IllegalArgumentException("Contrato no encontrado en este tenant", e);
        }
        if (!projectId.equals(contractRow.get("project_id"))) {
            metrics.paymentsBlocked.increment();
            throw new IllegalArgumentException("El contrato no pertenece a la obra de la factura");
        }
        String invoiceCurrency = requiredCurrency(invoice.get("currency"), "moneda de factura");
        String contractCurrency = requiredCurrency(contractRow.get("currency"), "moneda de contrato");
        if (!invoiceCurrency.equals(contractCurrency)) {
            metrics.paymentsBlocked.increment();
            throw new IllegalStateException("La moneda de factura y contrato no coincide");
        }

        Map<String, Object> head;
        try {
            head = jdbc.queryForMap("SELECT estado_global, version_actual FROM compliance_subcontractor_head " +
                "WHERE tenant_id = ? AND subcontractor_id = ? AND project_id = ? FOR UPDATE",
                tenant, subcontractorId, projectId);
        } catch (EmptyResultDataAccessException e) {
            metrics.paymentsBlocked.increment();
            throw new IllegalStateException("No existe compliance para este subcontratista y obra", e);
        }
        if (!"VIGENTE".equals(head.get("estado_global"))) {
            metrics.paymentsBlocked.increment();
            throw new IllegalStateException("Compliance no vigente: " + head.get("estado_global"));
        }

        UUID applicationId = UUID.randomUUID();
        jdbc.update("INSERT INTO payment_application " +
            "(tenant_id, payment_application_id, invoice_id, project_id, contract_id, subcontractor_id, " +
            "amount_requested, status, compliance_version_seen, submission_idempotency_key, submission_request_hash) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, 'PENDING_APPROVAL', ?, ?, ?)",
            tenant, applicationId, invoiceId, projectId, contractId, subcontractorId,
            amount, ((Number) head.get("version_actual")).longValue(), idempotencyKey, requestHash);

        Map<String, Object> variables = new HashMap<>();
        variables.put("tenantId", tenant);
        variables.put("invoiceId", invoiceId);
        variables.put("subcontractorId", subcontractorId);
        variables.put("projectId", projectId);
        variables.put("montoFactura", amount);
        variables.put("contractId", contractId);
        variables.put("paymentApplicationId", applicationId);
        variables.put("invoiceCurrency", invoiceCurrency);
        variables.put("monedaFactura", invoiceCurrency);
        variables.put("complianceVersionSeen", ((Number) head.get("version_actual")).longValue());

        var instance = runtimeService.startProcessInstanceByKey(
            "paymentApprovalProcess", applicationId.toString(), variables);
        jdbc.update("UPDATE payment_application SET process_instance_id = ?, updated_at = now() " +
            "WHERE tenant_id = ? AND payment_application_id = ? AND submission_idempotency_key = ?",
            instance.getId(), tenant, applicationId, idempotencyKey);
        return instance.getId();
    }

    private static String requestHash(UUID invoiceId, UUID subcontractorId, UUID projectId,
                                      UUID contractId, BigDecimal amount) {
        String canonical = invoiceId + "|" + subcontractorId + "|" + projectId + "|" + contractId + "|" + amount.toPlainString();
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256")
                .digest(canonical.getBytes(StandardCharsets.UTF_8)));
        } catch (NoSuchAlgorithmException impossible) {
            throw new IllegalStateException("SHA-256 no está disponible en este runtime", impossible);
        }
    }

    private static String requiredCurrency(Object raw, String field) {
        if (raw == null) throw new IllegalStateException("Falta " + field);
        String currency = raw.toString().trim().toUpperCase(Locale.ROOT);
        if (!currency.matches("[A-Z]{3}")) {
            throw new IllegalStateException("Código de moneda inválido en " + field);
        }
        return currency;
    }
}
