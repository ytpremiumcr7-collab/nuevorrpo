package com.tuempresa.billing.service;

import com.tuempresa.billing.event.PaymentInvalidatedEvent;
import com.tuempresa.platform.tenant.TenantContext;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class PaymentInvalidationService {

    private final JdbcTemplate jdbc;
    private final ApplicationEventPublisher events;

    public PaymentInvalidationService(JdbcTemplate jdbc, ApplicationEventPublisher events) {
        this.jdbc = jdbc;
        this.events = events;
    }

    @Transactional
    public UUID invalidate(UUID paymentId, String invalidityType, UUID evidenceId,
                           BigDecimal amount, String contractualBasis,
                           LocalDate effectiveDate, UUID detectedBy) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        if (detectedBy == null || !detectedBy.equals(com.tuempresa.identity.security.UserContext.require().userId())) {
            throw new com.tuempresa.identity.security.UserContext.ForbiddenException(
                "El actor de la invalidación debe ser el usuario autenticado");
        }
        if (amount == null || amount.signum() <= 0 || invalidityType == null || invalidityType.isBlank()
                || evidenceId == null || contractualBasis == null || contractualBasis.isBlank()
                || effectiveDate == null) {
            throw new IllegalArgumentException("Datos de invalidación incompletos o inválidos");
        }
        Map<String, Object> payment = jdbc.queryForMap(
            "SELECT subcontractor_id, project_id, amount, executed_at FROM payment " +
            "WHERE tenant_id = ? AND payment_id = ? FOR UPDATE",
            tenant, paymentId);

        if (payment.get("executed_at") == null) {
            throw new IllegalStateException(
                "Pago " + paymentId + " no ejecutado. No se puede invalidar.");
        }

        UUID invalidationId = UUID.randomUUID();
        List<UUID> inserted = jdbc.query("""
            INSERT INTO payment_invalidation
              (tenant_id, invalidation_id, payment_id, invalidity_type,
               evidence_id, effective_date, amount, contractual_basis, detected_by)
            VALUES (?, ?, ?, ?::invalidity_type, ?, ?, ?, ?, ?)
            ON CONFLICT (tenant_id, payment_id, invalidity_type, evidence_id) DO NOTHING
            RETURNING invalidation_id
            """,
            (rs, i) -> rs.getObject(1, UUID.class),
            tenant, invalidationId, paymentId, invalidityType, evidenceId,
            effectiveDate, amount, contractualBasis, detectedBy);

        if (inserted.isEmpty()) {
            // Idempotente: ya existía; devolver el existente sin re-publicar evento
            return jdbc.queryForObject(
                "SELECT invalidation_id FROM payment_invalidation " +
                "WHERE tenant_id = ? AND payment_id = ? " +
                "AND invalidity_type = ?::invalidity_type AND evidence_id = ?",
                UUID.class, tenant, paymentId, invalidityType, evidenceId);
        }

        events.publishEvent(new PaymentInvalidatedEvent(
            tenant, paymentId,
            (UUID) payment.get("subcontractor_id"),
            (UUID) payment.get("project_id"),
            invalidityType, evidenceId, amount,
            contractualBasis, effectiveDate));
        return inserted.get(0);
    }
}
