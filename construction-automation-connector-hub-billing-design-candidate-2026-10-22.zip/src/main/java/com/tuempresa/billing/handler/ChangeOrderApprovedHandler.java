package com.tuempresa.billing.handler;

import org.springframework.context.event.EventListener;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.UUID;

@Component
public class ChangeOrderApprovedHandler {
    private final JdbcTemplate jdbc;
    public ChangeOrderApprovedHandler(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @EventListener
    @Transactional
    public void on(ChangeOrderApprovedEvent event) {
        jdbc.execute("SET LOCAL app.tenant_id = '" + event.tenantId() + "'");

        // Upsert de la proyección
        jdbc.update(
            "INSERT INTO billing_contract_projection " +
            "(tenant_id, contract_id, original_amount, approved_co_amount, effective_amount) " +
            "SELECT tenant_id, contract_id, amount, ?, amount + ? " +
            "FROM contract WHERE tenant_id = ? AND contract_id = ? " +
            "ON CONFLICT (tenant_id, contract_id) DO UPDATE SET " +
            "approved_co_amount = billing_contract_projection.approved_co_amount + EXCLUDED.approved_co_amount, " +
            "effective_amount = billing_contract_projection.original_amount + (billing_contract_projection.approved_co_amount + EXCLUDED.approved_co_amount), " +
            "updated_at = now()",
            event.amount(), event.amount(), event.tenantId(), event.contractId());
    }
}
