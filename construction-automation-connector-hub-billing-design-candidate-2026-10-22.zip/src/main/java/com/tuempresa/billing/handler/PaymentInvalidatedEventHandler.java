package com.tuempresa.billing.handler;

import com.tuempresa.billing.event.PaymentInvalidatedEvent;
import com.tuempresa.compensation.service.CompensationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.event.EventListener;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

/**
 * CORRECCIÓN de la Parte 1: antes este handler correlacionaba el mensaje
 * BPMN directamente, duplicando la correlación con CompensationCaseCreatedHandler
 * y causando MismatchingMessageCorrelationException.
 *
 * Ahora solo crea el compensation_case. La correlación BPMN la hace
 * CompensationCaseCreatedHandler vía CompensationCaseCreatedEvent.
 *
 * Flujo unidireccional:
 *   PaymentInvalidationService.invalidate()
 *     -> PaymentInvalidatedEvent (Spring)
 *       -> [este handler] CompensationService.open()
 *         -> CompensationCaseCreatedEvent (Spring)
 *           -> CompensationCaseCreatedHandler -> message correlation BPMN
 */
@Component
public class PaymentInvalidatedEventHandler {

    private static final Logger log =
        LoggerFactory.getLogger(PaymentInvalidatedEventHandler.class);

    private final CompensationService compensationService;

    public PaymentInvalidatedEventHandler(CompensationService compensationService) {
        this.compensationService = compensationService;
    }

    @EventListener
    @Transactional
    public void on(PaymentInvalidatedEvent event) {
        try {
            compensationService.open(
                event.paymentId(),
                event.invalidityType(),
                event.evidenceId(),
                event.amount(),
                event.contractualBasis());
        } catch (Exception e) {
            log.error("Falló apertura de compensación para payment={}, type={}: {}",
                event.paymentId(), event.invalidityType(), e.getMessage(), e);
            // No tragamos: dejar que el caller (PaymentInvalidationService) falle
            throw e;
        }
    }
}
