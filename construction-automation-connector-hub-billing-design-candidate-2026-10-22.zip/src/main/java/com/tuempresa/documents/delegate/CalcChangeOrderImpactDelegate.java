package com.tuempresa.documents.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.UUID;

@Component("calcChangeOrderImpactDelegate")
public class CalcChangeOrderImpactDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    public CalcChangeOrderImpactDelegate(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = (UUID) execution.getVariable("tenantId");
        UUID changeOrderId = (UUID) execution.getVariable("changeOrderId");
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        BigDecimal amount = jdbc.queryForObject(
            "SELECT amount FROM change_order WHERE tenant_id = ? AND change_order_id = ?",
            BigDecimal.class, tenant, changeOrderId);
        if (amount == null) throw new IllegalStateException(
            "Change order " + changeOrderId + " sin monto");
        String group = amount.compareTo(new BigDecimal("50000")) > 0
            ? "COMITE" : "GERENTE_PROYECTO";
        execution.setVariable("changeOrderApprovalGroup", group);
        execution.setVariable("changeOrderAmount", amount);
    }
}
