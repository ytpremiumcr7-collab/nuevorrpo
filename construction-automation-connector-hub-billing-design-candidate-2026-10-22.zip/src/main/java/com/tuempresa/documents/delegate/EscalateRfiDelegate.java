package com.tuempresa.documents.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component("escalateRfiDelegate")
public class EscalateRfiDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    public EscalateRfiDelegate(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = (UUID) execution.getVariable("tenantId");
        UUID rfiId = (UUID) execution.getVariable("rfiId");
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        jdbc.update("INSERT INTO notification_outbox " +
            "(tenant_id, notification_id, recipient_role, subject, body) " +
            "VALUES (?, ?, 'PROJECT_MANAGER', 'RFI SLA incumplido', ?)",
            tenant, UUID.randomUUID(), "RFI " + rfiId + " excedió el plazo contractual");
    }
}
