package com.tuempresa.documents.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.UUID;

@Component("routeRfiDelegate")
public class RouteRfiDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    public RouteRfiDelegate(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = (UUID) execution.getVariable("tenantId");
        UUID rfiId = (UUID) execution.getVariable("rfiId");
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        Map<String,Object> rfi = jdbc.queryForMap(
            "SELECT work_package_id, assigned_to_role FROM rfi " +
            "WHERE tenant_id = ? AND rfi_id = ?", tenant, rfiId);
        String role = (String) rfi.get("assigned_to_role");
        if (role == null) throw new IllegalStateException(
            "RFI " + rfiId + " sin assigned_to_role. No se puede rutear.");
        execution.setVariable("rfiAssigneeGroup", role);
    }
}
