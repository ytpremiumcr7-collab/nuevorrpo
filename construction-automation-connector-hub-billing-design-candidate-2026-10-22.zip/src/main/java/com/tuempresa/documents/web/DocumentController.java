package com.tuempresa.documents.web;

import com.tuempresa.documents.service.DocumentService;
import com.tuempresa.identity.security.UserContext;
import com.tuempresa.identity.service.ProjectAuthorizationService;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/files")
public class DocumentController {
    private final DocumentService service;
    private final ProjectAuthorizationService authorization;
    public DocumentController(DocumentService service, ProjectAuthorizationService authorization) {
        this.service = service; this.authorization = authorization;
    }

    @PostMapping("/upload")
    public ResponseEntity<?> upload(@RequestParam("projectId") UUID projectId,
                                    @RequestParam("file") MultipartFile file) {
        authorization.requireProjectRole(projectId, UserContext.ProjectRole.OWNER, UserContext.ProjectRole.PROJECT_ENGINEER);
        UUID docId = service.upload(projectId, file);
        return ResponseEntity.ok(Map.of("documentId", docId));
    }

    @GetMapping("/{id}/download")
    public ResponseEntity<InputStreamResource> download(@PathVariable UUID id) {
        authorization.requireEntityProject(ProjectAuthorizationService.Resource.DOCUMENT, id,
            UserContext.ProjectRole.OWNER, UserContext.ProjectRole.PROJECT_ENGINEER,
            UserContext.ProjectRole.SAFETY_LEAD, UserContext.ProjectRole.FINANCE,
            UserContext.ProjectRole.COMPLIANCE_LEAD, UserContext.ProjectRole.SUBCONTRACTOR_ADMIN,
            UserContext.ProjectRole.VIEWER);
        InputStream stream = service.download(id);
        return ResponseEntity.ok().header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"file\"")
            .contentType(MediaType.APPLICATION_OCTET_STREAM).body(new InputStreamResource(stream));
    }
}
