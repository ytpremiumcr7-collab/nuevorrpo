package com.tuempresa.documents.web;

import com.tuempresa.documents.service.DailyReportService;
import com.tuempresa.documents.service.ProjectDocumentsService;
import com.tuempresa.documents.service.SubmittalService;
import com.tuempresa.identity.security.UserContext;
import com.tuempresa.identity.service.ProjectAuthorizationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/documents")
public class ProjectDocumentsController {
    private final ProjectDocumentsService service;
    private final SubmittalService submittals;
    private final DailyReportService dailyReports;
    private final ProjectAuthorizationService authorization;

    public ProjectDocumentsController(ProjectDocumentsService service, SubmittalService submittals,
                                      DailyReportService dailyReports, ProjectAuthorizationService authorization) {
        this.service = service; this.submittals = submittals; this.dailyReports = dailyReports;
        this.authorization = authorization;
    }

    @PostMapping("/rfis")
    public ResponseEntity<?> createRfi(@RequestBody Map<String,Object> body) {
        UUID projectId = UUID.fromString((String) body.get("projectId"));
        authorization.requireProjectRole(projectId, UserContext.ProjectRole.OWNER, UserContext.ProjectRole.PROJECT_ENGINEER);
        UUID id = service.createRfi(projectId, body.get("workPackageId") == null ? null : UUID.fromString((String) body.get("workPackageId")),
            (String) body.get("rfiNumber"), (String) body.get("title"), (String) body.get("description"), UserContext.require().userId());
        return ResponseEntity.ok(Map.of("rfiId", id));
    }

    @PostMapping("/rfis/{id}/respond")
    public ResponseEntity<?> respondRfi(@PathVariable UUID id, @RequestBody Map<String,Object> body) {
        authorization.requireEntityProject(ProjectAuthorizationService.Resource.RFI, id,
            UserContext.ProjectRole.OWNER, UserContext.ProjectRole.PROJECT_ENGINEER);
        service.respondRfi(id, UserContext.require().userId(), (String) body.get("responseText"));
        return ResponseEntity.ok().build();
    }

    @PostMapping("/change-orders")
    public ResponseEntity<?> createChangeOrder(@RequestBody Map<String,Object> body) {
        UUID projectId = UUID.fromString((String) body.get("projectId"));
        authorization.requireProjectRole(projectId, UserContext.ProjectRole.OWNER, UserContext.ProjectRole.PROJECT_ENGINEER);
        UUID id = service.createChangeOrder(projectId, UUID.fromString((String) body.get("contractId")),
            body.get("workPackageId") == null ? null : UUID.fromString((String) body.get("workPackageId")),
            (String) body.get("coNumber"), (String) body.get("title"), (String) body.get("justification"),
            new BigDecimal(body.get("amount").toString()), UserContext.require().userId());
        return ResponseEntity.ok(Map.of("changeOrderId", id));
    }

    @PostMapping("/change-orders/{id}/approve")
    public ResponseEntity<?> approveChangeOrder(@PathVariable UUID id, @RequestBody Map<String,Object> body) {
        authorization.requireEntityProject(ProjectAuthorizationService.Resource.CHANGE_ORDER, id,
            UserContext.ProjectRole.OWNER, UserContext.ProjectRole.FINANCE);
        service.approveChangeOrder(id, UserContext.require().userId());
        return ResponseEntity.ok().build();
    }

    @PostMapping("/submittals")
    public ResponseEntity<?> createSubmittal(@RequestBody Map<String,Object> body) {
        UUID projectId = UUID.fromString((String) body.get("projectId"));
        authorization.requireProjectRole(projectId, UserContext.ProjectRole.OWNER, UserContext.ProjectRole.PROJECT_ENGINEER);
        UUID id = submittals.submit(projectId, body.get("workPackageId") == null ? null : UUID.fromString((String) body.get("workPackageId")),
            (String) body.get("submittalNumber"), (String) body.get("title"), UUID.fromString((String) body.get("documentId")),
            UserContext.require().userId());
        return ResponseEntity.ok(Map.of("submittalId", id));
    }

    @PostMapping("/submittals/{id}/review")
    public ResponseEntity<?> reviewSubmittal(@PathVariable UUID id, @RequestBody Map<String,Object> body) {
        authorization.requireEntityProject(ProjectAuthorizationService.Resource.SUBMITTAL, id,
            UserContext.ProjectRole.OWNER, UserContext.ProjectRole.PROJECT_ENGINEER);
        submittals.review(id, (String) body.get("status"), UserContext.require().userId());
        return ResponseEntity.ok().build();
    }

    @GetMapping("/projects/{projectId}/submittals")
    public List<Map<String,Object>> listSubmittals(@PathVariable UUID projectId) {
        authorization.requireProjectMember(projectId);
        return submittals.listByProject(projectId);
    }

    @PostMapping("/daily-reports")
    public ResponseEntity<?> submitDailyReport(@RequestBody Map<String,Object> body) {
        UUID projectId = UUID.fromString((String) body.get("projectId"));
        authorization.requireProjectRole(projectId, UserContext.ProjectRole.OWNER, UserContext.ProjectRole.PROJECT_ENGINEER,
            UserContext.ProjectRole.SAFETY_LEAD);
        UUID id = dailyReports.submit(projectId, body.get("siteId") == null ? null : UUID.fromString((String) body.get("siteId")),
            LocalDate.parse((String) body.get("reportDate")), (String) body.get("weather"),
            body.get("workforceCount") == null ? null : ((Number) body.get("workforceCount")).intValue(),
            (String) body.get("summary"), body.get("documentId") == null ? null : UUID.fromString((String) body.get("documentId")),
            UserContext.require().userId());
        return ResponseEntity.ok(Map.of("reportId", id));
    }

    @GetMapping("/projects/{projectId}/daily-reports")
    public List<Map<String,Object>> listDailyReports(@PathVariable UUID projectId) {
        authorization.requireProjectMember(projectId);
        return dailyReports.listByProject(projectId);
    }
}
