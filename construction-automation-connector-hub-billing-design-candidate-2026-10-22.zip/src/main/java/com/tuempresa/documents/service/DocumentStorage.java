package com.tuempresa.documents.service;

import java.io.InputStream;

public interface DocumentStorage {
    String store(String key, InputStream content, String contentType, long size);
    InputStream retrieve(String key);
    void delete(String key);
}
