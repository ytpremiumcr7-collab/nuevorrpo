package com.tuempresa.documents.service;

import com.tuempresa.platform.tenant.TenantContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class SubmittalService {

    private final JdbcTemplate jdbc;

    public SubmittalService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Transactional
    public UUID submit(UUID projectId, UUID workPackageId, String number, String title,
                       UUID documentId, UUID createdBy) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        UUID id = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO submittal
              (tenant_id, submittal_id, project_id, work_package_id, submittal_number,
               title, status, document_id, created_by)
            VALUES (?, ?, ?, ?, ?, ?, 'SUBMITTED'::submittal_status, ?, ?)
            """,
            tenant, id, projectId, workPackageId, number, title, documentId, createdBy);
        return id;
    }

    @Transactional
    public void review(UUID submittalId, String newStatus, UUID reviewer) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        int n = jdbc.update(
            "UPDATE submittal SET status = ?::submittal_status, reviewed_at = now(), " +
            "aggregate_version = aggregate_version + 1, updated_at = now() " +
            "WHERE tenant_id = ? AND submittal_id = ?",
            newStatus, tenant, submittalId);
        if (n == 0) throw new IllegalStateException("Submittal no encontrado: " + submittalId);
    }

    public List<Map<String, Object>> listByProject(UUID projectId) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        return jdbc.queryForList(
            "SELECT submittal_id, submittal_number, title, status, document_id, created_at " +
            "FROM submittal WHERE tenant_id = ? AND project_id = ? ORDER BY created_at DESC",
            tenant, projectId);
    }
}
