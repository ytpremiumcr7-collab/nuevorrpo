package com.tuempresa.documents.service;

import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

@Service
public class LocalDocumentStorage implements DocumentStorage {
    private final Path root = Paths.get("./storage").toAbsolutePath().normalize();

    public LocalDocumentStorage() throws IOException {
        Files.createDirectories(root);
    }

    @Override
    public String store(String key, InputStream content, String contentType, long size) {
        try {
            Path target = root.resolve(key).normalize();
            if (!target.startsWith(root)) throw new SecurityException("Path traversal detected");
            Files.createDirectories(target.getParent());
            Files.copy(content, target, StandardCopyOption.REPLACE_EXISTING);
            return key;
        } catch (IOException e) {
            throw new RuntimeException("Failed to store file", e);
        }
    }

    @Override
    public InputStream retrieve(String key) {
        try {
            Path target = root.resolve(key).normalize();
            if (!target.startsWith(root)) throw new SecurityException("Path traversal detected");
            return Files.newInputStream(target);
        } catch (IOException e) {
            throw new RuntimeException("File not found", e);
        }
    }

    @Override
    public void delete(String key) {
        try {
            Path target = root.resolve(key).normalize();
            if (!target.startsWith(root)) throw new SecurityException("Path traversal detected");
            Files.deleteIfExists(target);
        } catch (IOException ignored) {}
    }
}
