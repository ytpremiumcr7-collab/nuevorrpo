package com.tuempresa.documents.service;

import com.tuempresa.platform.tenant.TenantContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.InputStream;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.UUID;

@Service
public class DocumentService {
    private final JdbcTemplate jdbc;
    private final DocumentStorage storage;

    public DocumentService(JdbcTemplate jdbc, DocumentStorage storage) {
        this.jdbc = jdbc; this.storage = storage;
    }

    @Transactional
    public UUID upload(UUID projectId, MultipartFile file) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        if (file.isEmpty()) throw new IllegalArgumentException("Archivo vacío");

        try {
            String sha256 = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(file.getBytes()));
            UUID docId = UUID.randomUUID();
            String key = tenant + "/" + projectId + "/" + docId + "_" + file.getOriginalFilename();

            try (InputStream is = file.getInputStream()) {
                storage.store(key, is, file.getContentType(), file.getSize());
            }

            jdbc.update(
                "INSERT INTO document (tenant_id, document_id, project_id, mime_type, sha256, author_id, file_name, content_type, size_bytes, storage_key) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                tenant, docId, projectId, file.getContentType(), sha256, tenant, 
                file.getOriginalFilename(), file.getContentType(), file.getSize(), key);

            return docId;
        } catch (Exception e) {
            throw new RuntimeException("Error procesando documento", e);
        }
    }

    public InputStream download(UUID documentId) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        String key = jdbc.queryForObject(
            "SELECT storage_key FROM document WHERE tenant_id = ? AND document_id = ?",
            String.class, tenant, documentId);
        if (key == null) throw new IllegalArgumentException("Documento no encontrado");
        return storage.retrieve(key);
    }
}
