package com.tuempresa.documents.service;

import com.tuempresa.platform.tenant.TenantContext;
import com.tuempresa.billing.event.ChangeOrderApprovedEvent;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class ProjectDocumentsService {

    private final JdbcTemplate jdbc;
    private final RuntimeService runtimeService;
    private final ApplicationEventPublisher events;

    public ProjectDocumentsService(JdbcTemplate jdbc, RuntimeService runtimeService,
                                   ApplicationEventPublisher events) {
        this.jdbc = jdbc;
        this.runtimeService = runtimeService;
        this.events = events;
    }

    // ----------------------------------------------------------------
    // RFI
    // ----------------------------------------------------------------
    @Transactional
    public UUID createRfi(UUID projectId, UUID workPackageId,
                          String rfiNumber, String title, String description,
                          UUID createdBy) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        // Asignación determinista por política; fail-loud si no hay
        String assignedRole = jdbc.query(
            "SELECT assigned_to_role FROM rfi_routing_policy " +
            "WHERE tenant_id = ? AND " +
            "  ((project_id = ? AND work_package_id = ?) " +
            "   OR (project_id = ? AND work_package_id IS NULL) " +
            "   OR (project_id IS NULL AND work_package_id IS NULL)) " +
            "ORDER BY priority, (work_package_id IS NULL), (project_id IS NULL) " +
            "LIMIT 1",
            rs -> rs.next() ? rs.getString(1) : null,
            tenant, projectId, workPackageId, projectId);
        if (assignedRole == null) {
            throw new IllegalStateException(
                "No hay política de enrutamiento para project=" + projectId +
                ", work_package=" + workPackageId);
        }

        UUID rfiId = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO rfi
              (tenant_id, rfi_id, project_id, work_package_id, rfi_number,
               title, description, status, assigned_to_role, deadline, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, 'ROUTED'::rfi_status, ?, CURRENT_DATE + 14, ?)
            """,
            tenant, rfiId, projectId, workPackageId, rfiNumber,
            title, description, assignedRole, createdBy);

        Map<String, Object> vars = new HashMap<>();
        vars.put("tenantId", tenant);
        vars.put("rfiId", rfiId);
        vars.put("projectId", projectId);
        vars.put("rfiAssigneeGroup", assignedRole);

        runtimeService.startProcessInstanceByKey(
            "rfiProcess", rfiId.toString(), vars);
        return rfiId;
    }

    @Transactional
    public void respondRfi(UUID rfiId, UUID respondedBy, String responseText) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        int updated = jdbc.update(
            "UPDATE rfi SET responded_at = now(), responded_by = ?, " +
            "response_text = ?, status = 'RESPONDED'::rfi_status, " +
            "aggregate_version = aggregate_version + 1, updated_at = now() " +
            "WHERE tenant_id = ? AND rfi_id = ? " +
            "AND status IN ('ROUTED','ASSIGNED','ESCALATED')",
            respondedBy, responseText, tenant, rfiId);
        if (updated == 0) {
            throw new IllegalStateException(
                "RFI " + rfiId + " no está en estado respondible");
        }
    }

    // ----------------------------------------------------------------
    // Change Order
    // ----------------------------------------------------------------
    @Transactional
    public UUID createChangeOrder(UUID projectId, UUID contractId, UUID workPackageId,
                                  String coNumber, String title, String justification,
                                  BigDecimal amount, UUID createdBy) {
        if (justification == null || justification.isBlank()) {
            throw new IllegalArgumentException(
                "Change order sin justificación. El gate de auditoría lo exige.");
        }
        if (amount == null || amount.signum() < 0) {
            throw new IllegalArgumentException("Change order con monto inválido: " + amount);
        }
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        UUID coId = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO change_order
              (tenant_id, change_order_id, project_id, contract_id, work_package_id,
               co_number, title, justification, amount, status, created_by)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'SUBMITTED'::change_order_status, ?)
            """,
            tenant, coId, projectId, contractId, workPackageId,
            coNumber, title, justification, amount, createdBy);

        Map<String, Object> vars = new HashMap<>();
        vars.put("tenantId", tenant);
        vars.put("changeOrderId", coId);
        vars.put("projectId", projectId);

        runtimeService.startProcessInstanceByKey(
            "changeOrderProcess", coId.toString(), vars);
        return coId;
    }

    @Transactional
    public void approveChangeOrder(UUID changeOrderId, UUID approvedBy) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        var row = jdbc.queryForMap(
            "SELECT contract_id, amount, status FROM change_order " +
            "WHERE tenant_id = ? AND change_order_id = ?", tenant, changeOrderId);
        if (!"SUBMITTED".equals(String.valueOf(row.get("status")))
            && !"UNDER_REVIEW".equals(String.valueOf(row.get("status")))) {
            throw new IllegalStateException("CO " + changeOrderId + " no está en estado aprobable");
        }
        int updated = jdbc.update(
            "UPDATE change_order SET status = 'APPROVED'::change_order_status, " +
            "approved_by = ?, approved_at = now(), " +
            "aggregate_version = aggregate_version + 1, updated_at = now() " +
            "WHERE tenant_id = ? AND change_order_id = ?",
            approvedBy, tenant, changeOrderId);
        if (updated == 0) throw new IllegalStateException("CO no actualizado");
        events.publishEvent(new ChangeOrderApprovedEvent(
            tenant, (UUID) row.get("contract_id"), changeOrderId,
            (java.math.BigDecimal) row.get("amount")));
    }

}
