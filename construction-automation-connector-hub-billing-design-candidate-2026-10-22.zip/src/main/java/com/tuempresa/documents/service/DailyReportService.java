package com.tuempresa.documents.service;

import com.tuempresa.platform.tenant.TenantContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class DailyReportService {

    private final JdbcTemplate jdbc;

    public DailyReportService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Transactional
    public UUID submit(UUID projectId, UUID siteId, LocalDate reportDate, String weather,
                       Integer workforce, String summary, UUID documentId, UUID submittedBy) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        UUID id = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO daily_report
              (tenant_id, report_id, project_id, site_id, report_date, weather,
               workforce_count, summary, status, document_id, submitted_by, submitted_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'SUBMITTED'::daily_report_status, ?, ?, now())
            ON CONFLICT (tenant_id, project_id, report_date) DO UPDATE SET
              weather = EXCLUDED.weather,
              workforce_count = EXCLUDED.workforce_count,
              summary = EXCLUDED.summary,
              document_id = EXCLUDED.document_id,
              status = 'SUBMITTED'::daily_report_status,
              submitted_at = now(),
              aggregate_version = daily_report.aggregate_version + 1,
              updated_at = now()
            """,
            tenant, id, projectId, siteId, reportDate, weather, workforce,
            summary, documentId, submittedBy);
        return id;
    }

    public List<Map<String, Object>> listByProject(UUID projectId) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        return jdbc.queryForList(
            "SELECT report_id, report_date, weather, workforce_count, summary, status, submitted_at " +
            "FROM daily_report WHERE tenant_id = ? AND project_id = ? ORDER BY report_date DESC",
            tenant, projectId);
    }
}
