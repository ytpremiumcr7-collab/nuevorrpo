package com.tuempresa.integration.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tuempresa.platform.tenant.TenantContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.UUID;

@Service
public class IntegrationOutboxService {

    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;

    public IntegrationOutboxService(JdbcTemplate jdbc, ObjectMapper mapper) {
        this.jdbc = jdbc;
        this.mapper = mapper;
    }

    @Transactional
    public UUID enqueue(String system, String direction, String entityType,
                        UUID entityId, Map<String, Object> payload) {
        UUID tenant = TenantContext.require();
        UUID messageId = UUID.randomUUID();
        String json;
        try {
            json = mapper.writeValueAsString(payload);
        } catch (Exception e) {
            throw new IllegalStateException("Payload no serializable", e);
        }
        jdbc.update(
            "INSERT INTO integration_outbox " +
            "(tenant_id, message_id, system, direction, entity_type, entity_id, payload) " +
            "VALUES (?, ?, ?::integration_system, ?::integration_direction, ?, ?, ?::jsonb)",
            tenant, messageId, system, direction, entityType, entityId, json);
        return messageId;
    }
}
