package com.tuempresa.integration.procore;

import com.tuempresa.identity.security.UserContext;
import com.tuempresa.identity.service.ProjectAuthorizationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/integrations/procore")
public class ProcoreController {
    private final ProcoreBridgeService bridge;
    private final ProcoreClient client;
    private final ProjectAuthorizationService authorization;

    public ProcoreController(ProcoreBridgeService bridge, ProcoreClient client,
            ProjectAuthorizationService authorization) {
        this.bridge = bridge; this.client = client; this.authorization = authorization;
    }

    @GetMapping("/status")
    public Map<String, Object> status() {
        UserContext.require();
        return Map.of("enabled", client.isEnabled(), "mode", client.isEnabled() ? "LIVE" : "DRY_RUN");
    }

    @PostMapping("/map")
    public ResponseEntity<?> map(@RequestBody Map<String, String> body) {
        authorization.requireOwnerOnAnyProject();
        String externalType = required(body, "externalType");
        String internalType = required(body, "internalType");
        if (!"PROJECT".equalsIgnoreCase(externalType) || !"PROJECT".equalsIgnoreCase(internalType)) {
            return ResponseEntity.badRequest().body(Map.of("error", "Solo se permite mapear proyectos Procore en esta versión"));
        }
        String externalId = required(body, "externalId");
        UUID internalId = UUID.fromString(required(body, "internalId"));
        authorization.requireProjectRole(internalId, UserContext.ProjectRole.OWNER);
        bridge.mapExternal("PROJECT", externalId, "PROJECT", internalId);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/rfis/{rfiId}/push")
    public ResponseEntity<?> pushRfi(@PathVariable UUID rfiId, @RequestBody Map<String, Object> body) {
        authorization.requireEntityProject(ProjectAuthorizationService.Resource.RFI, rfiId,
            UserContext.ProjectRole.OWNER, UserContext.ProjectRole.PROJECT_ENGINEER);
        String procoreProjectId = String.valueOf(body.getOrDefault("procoreProjectId", "")).trim();
        if (procoreProjectId.isEmpty() || procoreProjectId.length() > 120) {
            return ResponseEntity.badRequest().body(Map.of("error", "procoreProjectId inválido"));
        }
        Object rawPayload = body.getOrDefault("payload", Map.of());
        if (!(rawPayload instanceof Map<?, ?>)) return ResponseEntity.badRequest().body(Map.of("error", "payload debe ser un objeto"));
        @SuppressWarnings("unchecked") Map<String, Object> payload = (Map<String, Object>) rawPayload;
        bridge.pushRfiNow(rfiId, procoreProjectId, payload);
        return ResponseEntity.ok(Map.of("pushed", client.isEnabled(), "dryRun", bridge.dryRun()));
    }

    /** Inbound webhooks are deliberately closed until signature verification, tenant routing,
     * deduplication and a dedicated inbound processor exist. Never enqueue inbound as outbound. */
    @PostMapping("/webhooks")
    public ResponseEntity<?> webhook(@RequestBody Map<String, Object> body) {
        return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED).body(Map.of(
            "error", "Inbound Procore deshabilitado: falta adaptador firmado, deduplicación y procesamiento inbound"));
    }
    private static String required(Map<String, String> body, String key) {
        String value = body.get(key);
        if (value == null || value.isBlank() || value.length() > 200) throw new IllegalArgumentException(key + " inválido");
        return value.trim();
    }
}
