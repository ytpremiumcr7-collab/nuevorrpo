package com.tuempresa.integration.procore;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestClientException;

import java.util.List;
import java.util.Map;

/**
 * Cliente HTTP real hacia Procore API v1.0.
 * Si procore.base-url / token no están configurados, operate en modo dry-run
 * (log + no falla el core). Nunca stub silencioso: dry-run es explícito.
 */
@Component
public class ProcoreClient {

    private static final Logger log = LoggerFactory.getLogger(ProcoreClient.class);

    private final RestClient client;
    private final boolean enabled;

    public ProcoreClient(
            @Value("${integration.procore.base-url:}") String baseUrl,
            @Value("${integration.procore.token:}") String token) {
        this.enabled = baseUrl != null && !baseUrl.isBlank()
            && token != null && !token.isBlank();
        if (enabled) {
            this.client = RestClient.builder()
                .baseUrl(baseUrl)
                .defaultHeader("Authorization", "Bearer " + token)
                .defaultHeader("Content-Type", MediaType.APPLICATION_JSON_VALUE)
                .build();
        } else {
            this.client = null;
            log.warn("ProcoreClient en DRY-RUN (integration.procore.base-url/token no configurados)");
        }
    }

    public boolean isEnabled() {
        return enabled;
    }

    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> listProjects(String companyId) {
        if (!enabled) {
            log.info("DRY-RUN Procore listProjects companyId={}", companyId);
            return List.of();
        }
        try {
            return client.get()
                .uri("/companies/{companyId}/projects", companyId)
                .retrieve()
                .body(List.class);
        } catch (RestClientException e) {
            throw new IllegalStateException("Procore listProjects falló: " + e.getMessage(), e);
        }
    }

    public void pushRfi(String projectExternalId, Map<String, Object> payload) {
        if (!enabled) {
            log.info("DRY-RUN Procore pushRfi project={} payloadKeys={}",
                projectExternalId, payload.keySet());
            return;
        }
        try {
            client.post()
                .uri("/projects/{projectId}/rfis", projectExternalId)
                .body(payload)
                .retrieve()
                .toBodilessEntity();
        } catch (RestClientException e) {
            throw new IllegalStateException("Procore pushRfi falló: " + e.getMessage(), e);
        }
    }
}
