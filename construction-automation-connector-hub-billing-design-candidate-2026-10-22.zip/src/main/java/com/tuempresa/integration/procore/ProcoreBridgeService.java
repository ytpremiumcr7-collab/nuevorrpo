package com.tuempresa.integration.procore;

import com.tuempresa.integration.service.IntegrationOutboxService;
import com.tuempresa.platform.tenant.TenantContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.UUID;

/**
 * Puente: no reescribe el core. Mapea IDs y encola outbox / empuja a Procore.
 */
@Service
public class ProcoreBridgeService {

    private final JdbcTemplate jdbc;
    private final ProcoreClient client;
    private final IntegrationOutboxService outbox;

    public ProcoreBridgeService(JdbcTemplate jdbc, ProcoreClient client,
                                IntegrationOutboxService outbox) {
        this.jdbc = jdbc;
        this.client = client;
        this.outbox = outbox;
    }

    @Transactional
    public void mapExternal(String externalType, String externalId,
                            String internalType, UUID internalId) {
        UUID tenant = TenantContext.require();
        jdbc.update(
            "INSERT INTO external_id_map " +
            "(tenant_id, system, external_type, external_id, internal_type, internal_id) " +
            "VALUES (?, 'PROCORE', ?, ?, ?, ?) " +
            "ON CONFLICT (tenant_id, system, external_type, external_id) DO UPDATE SET " +
            "internal_id = EXCLUDED.internal_id, synced_at = now()",
            tenant, externalType, externalId, internalType, internalId);
    }

    @Transactional
    public UUID enqueueRfiOutbound(UUID rfiId, Map<String, Object> payload) {
        return outbox.enqueue("PROCORE", "OUTBOUND", "RFI", rfiId, payload);
    }

    @Transactional
    public void pushRfiNow(UUID rfiId, String procoreProjectId, Map<String, Object> payload) {
        UUID tenant = TenantContext.require();
        UUID projectId = jdbc.queryForObject(
            "SELECT project_id FROM rfi WHERE tenant_id = ? AND rfi_id = ? FOR SHARE",
            UUID.class, tenant, rfiId);
        String mappedProject = jdbc.queryForObject(
            "SELECT external_id FROM external_id_map WHERE tenant_id = ? AND system = 'PROCORE' " +
            "AND external_type = 'PROJECT' AND internal_type = 'PROJECT' AND internal_id = ?",
            String.class, tenant, projectId);
        if (!mappedProject.equals(procoreProjectId)) {
            throw new IllegalArgumentException("El proyecto Procore externo no coincide con el mapeo autorizado de la obra");
        }
        client.pushRfi(procoreProjectId, payload);
        outbox.enqueue("PROCORE", "OUTBOUND", "RFI", rfiId,
            Map.of("status", "PUSHED", "project", procoreProjectId));
        mapExternal("RFI", String.valueOf(payload.getOrDefault("procoreRfiId", rfiId)),
            "RFI", rfiId);
    }

    public boolean dryRun() {
        return !client.isEnabled();
    }
}
