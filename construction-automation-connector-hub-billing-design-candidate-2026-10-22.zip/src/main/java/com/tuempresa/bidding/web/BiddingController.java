package com.tuempresa.bidding.web;

import com.tuempresa.bidding.service.BiddingService;
import com.tuempresa.identity.security.UserContext;
import com.tuempresa.identity.service.ProjectAuthorizationService;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/bids")
public class BiddingController {
    private final BiddingService service;
    private final ProjectAuthorizationService authorization;
    public BiddingController(BiddingService service, ProjectAuthorizationService authorization) {
        this.service = service; this.authorization = authorization;
    }

    @PostMapping("/packages")
    public ResponseEntity<?> createPackage(@RequestBody Map<String,Object> body) {
        UUID projectId = UUID.fromString((String) body.get("projectId"));
        authorization.requireProjectRole(projectId, UserContext.ProjectRole.OWNER, UserContext.ProjectRole.PROJECT_ENGINEER);
        UUID id = service.createPackage(projectId,
            body.get("workPackageId") == null ? null : UUID.fromString((String) body.get("workPackageId")),
            (String) body.get("name"), Instant.parse((String) body.get("bidDeadline")), UserContext.require().userId());
        return ResponseEntity.ok(Map.of("bidPackageId", id));
    }

    @PostMapping("/packages/{packageId}/bids")
    public ResponseEntity<?> submitBid(@PathVariable UUID packageId, @RequestBody Map<String,Object> body) {
        authorization.requireEntityProject(ProjectAuthorizationService.Resource.BID_PACKAGE, packageId,
            UserContext.ProjectRole.OWNER, UserContext.ProjectRole.SUBCONTRACTOR_ADMIN);
        // Do not trust body.bidderId: there is not yet a reviewed app_user -> party binding.
        // Fail closed instead of letting an authenticated user submit on behalf of any contractor.
        return ResponseEntity.status(HttpStatus.NOT_IMPLEMENTED).body(Map.of(
            "error", "Envío de ofertas deshabilitado hasta implementar y verificar el vínculo de identidad de contratista"));
    }

    @PostMapping("/packages/{packageId}/award")
    public ResponseEntity<?> award(@PathVariable UUID packageId, @RequestBody Map<String,Object> body) {
        authorization.requireEntityProject(ProjectAuthorizationService.Resource.BID_PACKAGE, packageId,
            UserContext.ProjectRole.OWNER);
        UUID contractId = service.award(packageId, UUID.fromString((String) body.get("selectedBidId")),
            (String) body.get("justification"), UserContext.require().userId());
        return ResponseEntity.ok(Map.of("contractId", contractId));
    }
}
