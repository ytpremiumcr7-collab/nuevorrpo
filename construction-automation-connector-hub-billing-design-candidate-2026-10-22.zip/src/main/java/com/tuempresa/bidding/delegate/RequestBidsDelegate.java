package com.tuempresa.bidding.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component("requestBidsDelegate")
public class RequestBidsDelegate implements JavaDelegate {
    @Override
    public void execute(DelegateExecution execution) {
        UUID bidPackageId = (UUID) execution.getVariable("bidPackageId");
        if (bidPackageId == null) {
            throw new IllegalStateException("bidPackageId no seteado");
        }
        // Crear notificaciones para bidders elegibles
        execution.setVariable("bidsRequestedAt", java.time.Instant.now().toString());
    }
}
