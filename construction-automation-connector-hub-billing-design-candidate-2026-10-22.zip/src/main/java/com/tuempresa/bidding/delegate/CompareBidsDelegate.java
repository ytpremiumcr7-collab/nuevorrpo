package com.tuempresa.bidding.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.UUID;

@Component("compareBidsDelegate")
public class CompareBidsDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    public CompareBidsDelegate(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = (UUID) execution.getVariable("tenantId");
        UUID packageId = (UUID) execution.getVariable("bidPackageId");
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        List<java.util.Map<String,Object>> bids = jdbc.queryForList(
            "SELECT bid_id, amount FROM bid WHERE tenant_id = ? AND bid_package_id = ? " +
            "ORDER BY amount", tenant, packageId);
        if (bids.isEmpty()) {
            throw new IllegalStateException(
                "No hay ofertas para el paquete " + packageId + "; no se puede comparar.");
        }
        execution.setVariable("bidCount", bids.size());
    }
}
