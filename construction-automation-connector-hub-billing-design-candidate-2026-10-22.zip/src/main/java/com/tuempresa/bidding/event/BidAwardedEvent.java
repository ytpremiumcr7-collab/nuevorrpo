package com.tuempresa.bidding.event;

import java.math.BigDecimal;
import java.util.UUID;

public record BidAwardedEvent(
    UUID tenantId, UUID bidPackageId, UUID selectedBidId, UUID projectId,
    UUID contractId, UUID bidderId, BigDecimal amount,
    String justification, UUID awardedBy) {}
