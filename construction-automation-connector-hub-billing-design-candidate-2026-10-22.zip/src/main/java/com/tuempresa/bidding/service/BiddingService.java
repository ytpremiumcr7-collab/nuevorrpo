package com.tuempresa.bidding.service;

import com.tuempresa.platform.tenant.TenantContext;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

@Service
public class BiddingService {

    private final JdbcTemplate jdbc;
    private final RuntimeService runtimeService;
    private final ApplicationEventPublisher events;

    public BiddingService(JdbcTemplate jdbc, RuntimeService runtimeService,
                          ApplicationEventPublisher events) {
        this.jdbc = jdbc; this.runtimeService = runtimeService; this.events = events;
    }

    @Transactional
    public UUID createPackage(UUID projectId, UUID workPackageId, String name,
                              Instant bidDeadline, UUID createdBy) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        UUID id = UUID.randomUUID();
        jdbc.update(
            "INSERT INTO bid_package (tenant_id, bid_package_id, project_id, " +
            "work_package_id, name, status, bid_deadline, created_by) " +
            "VALUES (?, ?, ?, ?, ?, 'OPEN'::bid_package_status, ?, ?)",
            tenant, id, projectId, workPackageId, name,
            java.sql.Timestamp.from(bidDeadline), createdBy);
        return id;
    }

    @Transactional
    public UUID submitBid(UUID bidPackageId, UUID bidderId, BigDecimal amount, UUID documentId) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        String status = jdbc.queryForObject(
            "SELECT status FROM bid_package WHERE tenant_id = ? AND bid_package_id = ?",
            String.class, tenant, bidPackageId);
        if (!"OPEN".equals(status) && !"RECEIVING".equals(status)) {
            throw new IllegalStateException(
                "Paquete " + bidPackageId + " no acepta ofertas (status=" + status + ")");
        }
        UUID bidId = UUID.randomUUID();
        jdbc.update(
            "INSERT INTO bid (tenant_id, bid_id, bid_package_id, bidder_id, " +
            "amount, status, document_id) VALUES (?, ?, ?, ?, ?, 'RECEIVED'::bid_status, ?)",
            tenant, bidId, bidPackageId, bidderId, amount, documentId);
        return bidId;
    }

    /**
     * Adjudicación con justificación obligatoria e idempotencia por status.
     * Solo un thread gana (UPDATE ... WHERE status IN ('OPEN','RECEIVING')).
     * Emite BidAwarded para crear Contract en el shared kernel.
     */
    @Transactional
    public UUID award(UUID bidPackageId, UUID selectedBidId, String justification,
                      UUID awardedBy) {
        if (justification == null || justification.isBlank()) {
            throw new IllegalArgumentException(
                "Adjudicación sin justificación. Gate de auditoría exige justificación.");
        }
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        List<Map<String,Object>> selected = jdbc.queryForList(
            "SELECT amount, bidder_id FROM bid " +
            "WHERE tenant_id = ? AND bid_id = ? AND bid_package_id = ?",
            tenant, selectedBidId, bidPackageId);
        if (selected.isEmpty()) {
            throw new IllegalStateException(
                "Bid " + selectedBidId + " no pertenece al paquete " + bidPackageId);
        }
        BigDecimal amount = (BigDecimal) selected.get(0).get("amount");
        UUID bidderId = (UUID) selected.get(0).get("bidder_id");

        // Idempotencia atómica: solo uno gana
        int updated = jdbc.update(
            "UPDATE bid_package SET status = 'AWARDED'::bid_package_status, " +
            "awarded_bid_id = ?, awarded_at = now(), " +
            "aggregate_version = aggregate_version + 1, updated_at = now() " +
            "WHERE tenant_id = ? AND bid_package_id = ? " +
            "AND status IN ('OPEN','RECEIVING','EVALUATING')",
            selectedBidId, tenant, bidPackageId);
        if (updated == 0) {
            throw new IllegalStateException(
                "Paquete " + bidPackageId + " ya fue adjudicado o no está en estado adjudicable");
        }
        jdbc.update("UPDATE bid SET status = 'SELECTED'::bid_status " +
            "WHERE tenant_id = ? AND bid_id = ?", tenant, selectedBidId);
        jdbc.update("UPDATE bid SET status = 'NOT_SELECTED'::bid_status " +
            "WHERE tenant_id = ? AND bid_package_id = ? AND bid_id <> ?",
            tenant, bidPackageId, selectedBidId);

        // Resolver contract_type y project del paquete para emitir el evento
        Map<String,Object> pkg = jdbc.queryForMap(
            "SELECT project_id, work_package_id FROM bid_package " +
            "WHERE tenant_id = ? AND bid_package_id = ?", tenant, bidPackageId);
        UUID projectId = (UUID) pkg.get("project_id");
        String contractType = jdbc.queryForObject(
            "SELECT contract_type FROM contract " +
            "WHERE tenant_id = ? AND project_id = ? LIMIT 1",
            String.class, tenant, projectId);

        UUID contractId = UUID.randomUUID();
        jdbc.update(
            "INSERT INTO contract (tenant_id, contract_id, project_id, amount, " +
            "currency, contract_type, effective_from) " +
            "VALUES (?, ?, ?, ?, 'USD', ?, CURRENT_DATE)",
            tenant, contractId, projectId, amount,
            contractType == null ? "AIA_A201" : contractType);
        jdbc.update(
            "INSERT INTO contract_party (tenant_id, contract_id, party_id, role_in_contract) " +
            "VALUES (?, ?, ?, 'SUBCONTRACTOR')",
            tenant, contractId, bidderId);

        events.publishEvent(new BidAwardedEvent(
            tenant, bidPackageId, selectedBidId, projectId, contractId,
            bidderId, amount, justification, awardedBy));
        return contractId;
    }
}
