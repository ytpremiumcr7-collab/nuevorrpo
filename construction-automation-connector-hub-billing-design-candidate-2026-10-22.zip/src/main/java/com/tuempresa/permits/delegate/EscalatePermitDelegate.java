package com.tuempresa.permits.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component("escalatePermitDelegate")
public class EscalatePermitDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    public EscalatePermitDelegate(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = (UUID) execution.getVariable("tenantId");
        UUID permitId = (UUID) execution.getVariable("permitId");
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        jdbc.update("INSERT INTO notification_outbox " +
            "(tenant_id, notification_id, recipient_role, subject, body) " +
            "VALUES (?, ?, 'PERMIT_MANAGER', 'Permiso vencido sin respuesta', ?)",
            tenant, UUID.randomUUID(),
            "Permiso " + permitId + " excedió el plazo de la autoridad");
    }
}
