package com.tuempresa.permits.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;

@Component("submitPermitDelegate")
public class SubmitPermitDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    public SubmitPermitDelegate(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = (UUID) execution.getVariable("tenantId");
        UUID permitId = (UUID) execution.getVariable("permitId");
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        Map<String,Object> permit = jdbc.queryForMap(
            "SELECT jurisdiction, permit_type FROM permit_application " +
            "WHERE tenant_id = ? AND permit_id = ?", tenant, permitId);

        Integer duration = jdbc.queryForObject(
            "SELECT duration FROM permit_phase_config " +
            "WHERE jurisdiction = ? AND permit_type = ? AND phase = 'REVIEW'",
            Integer.class, permit.get("jurisdiction"), permit.get("permit_type"));
        if (duration == null) throw new IllegalStateException(
            "Sin configuración de plazo para " + permit.get("jurisdiction") +
            "/" + permit.get("permit_type"));

        String timeUnit = jdbc.queryForObject(
            "SELECT time_unit FROM permit_phase_config " +
            "WHERE jurisdiction = ? AND permit_type = ? AND phase = 'REVIEW'",
            String.class, permit.get("jurisdiction"), permit.get("permit_type"));

        LocalDate deadline = "BUSINESS_DAYS".equals(timeUnit)
            ? jdbc.queryForObject("SELECT add_business_days(?, CURRENT_DATE, ?)",
                                  LocalDate.class, permit.get("jurisdiction"), duration)
            : jdbc.queryForObject("SELECT add_calendar_days(CURRENT_DATE, ?)",
                                  LocalDate.class, duration);

        execution.setVariable("permitDeadlineDate",
            deadline.atStartOfDay().toInstant(java.time.ZoneOffset.UTC).toString());
        execution.setVariable("permitDeadline", deadline.toString());
    }
}
