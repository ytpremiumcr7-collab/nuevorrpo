package com.tuempresa.permits.web;

import com.tuempresa.identity.security.UserContext;
import com.tuempresa.identity.service.ProjectAuthorizationService;
import com.tuempresa.permits.service.PermitService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/permits")
public class PermitController {
    private final PermitService service;
    private final ProjectAuthorizationService authorization;
    public PermitController(PermitService service, ProjectAuthorizationService authorization) {
        this.service = service; this.authorization = authorization;
    }

    @PostMapping
    public ResponseEntity<?> submit(@RequestBody Map<String,Object> body) {
        UUID projectId = UUID.fromString((String) body.get("projectId"));
        authorization.requireProjectRole(projectId, UserContext.ProjectRole.OWNER, UserContext.ProjectRole.PROJECT_ENGINEER);
        UUID id = service.submit(projectId, body.get("siteId") == null ? null : UUID.fromString((String) body.get("siteId")),
            (String) body.get("jurisdiction"), (String) body.get("permitType"), (String) body.get("permitNumber"),
            UserContext.require().userId());
        return ResponseEntity.ok(Map.of("permitId", id));
    }
}
