package com.tuempresa.permits.service;

import com.tuempresa.platform.tenant.TenantContext;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class PermitService {

    private final JdbcTemplate jdbc;
    private final RuntimeService runtimeService;

    public PermitService(JdbcTemplate jdbc, RuntimeService runtimeService) {
        this.jdbc = jdbc; this.runtimeService = runtimeService;
    }

    @Transactional
    public UUID submit(UUID projectId, UUID siteId, String jurisdiction,
                       String permitType, String permitNumber, UUID createdBy) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        // Fail-loud si no hay configuración de plazo para esta jurisdicción
        Integer duration = jdbc.query(
            "SELECT duration FROM permit_phase_config " +
            "WHERE jurisdiction = ? AND permit_type = ? AND phase = 'REVIEW'",
            rs -> rs.next() ? rs.getInt(1) : null,
            jurisdiction, permitType);
        if (duration == null) {
            throw new IllegalStateException(
                "Sin configuración de plazo para " + jurisdiction + "/" + permitType +
                ". No se puede someter un permiso sin saber cuál es su deadline.");
        }

        UUID permitId = UUID.randomUUID();
        jdbc.update(
            "INSERT INTO permit_application " +
            "(tenant_id, permit_id, project_id, site_id, jurisdiction, permit_type, " +
            " permit_number, status, submitted_at, created_by) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?, 'SUBMITTED'::permit_status, now(), ?)",
            tenant, permitId, projectId, siteId, jurisdiction, permitType,
            permitNumber, createdBy);

        Map<String, Object> vars = new HashMap<>();
        vars.put("tenantId", tenant);
        vars.put("permitId", permitId);
        vars.put("projectId", projectId);

        runtimeService.startProcessInstanceByKey(
            "permitApplicationProcess", permitId.toString(), vars);
        return permitId;
    }
}
