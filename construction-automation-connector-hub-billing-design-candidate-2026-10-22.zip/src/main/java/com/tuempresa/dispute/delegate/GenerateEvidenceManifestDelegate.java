package com.tuempresa.dispute.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.HexFormat;
import java.util.Map;
import java.util.UUID;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

@Component("generateEvidenceManifestDelegate")
public class GenerateEvidenceManifestDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    private final String hmacKeyConfig;

    public GenerateEvidenceManifestDelegate(
            JdbcTemplate jdbc,
            @Value("${app.evidence-hmac-key:#{null}}") String hmacKeyConfig) {
        this.jdbc = jdbc;
        this.hmacKeyConfig = hmacKeyConfig;
    }

    private byte[] resolveKey() {
        String key = hmacKeyConfig;
        if (key == null || key.isBlank()) {
            key = System.getenv("EVIDENCE_HMAC_KEY");
        }
        if (key == null || key.isBlank()) {
            throw new IllegalStateException(
                "EVIDENCE_HMAC_KEY / app.evidence-hmac-key no configurada. " +
                "Firmar evidencia es obligatorio en disputas.");
        }
        return key.getBytes(StandardCharsets.UTF_8);
    }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = asUuid(execution.getVariable("tenantId"));
        UUID disputeId = asUuid(execution.getVariable("disputeCaseId"));
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        Long docCount = jdbc.queryForObject(
            "SELECT count(*) FROM evidence_manifest_document emd " +
            "JOIN dispute_case dc ON dc.tenant_id = emd.tenant_id " +
            " AND dc.evidence_manifest_id = emd.manifest_id " +
            "WHERE dc.tenant_id = ? AND dc.dispute_case_id = ?",
            Long.class, tenant, disputeId);
        if (docCount == null || docCount < 3) {
            throw new IllegalStateException(
                "Manifiesto de disputa " + disputeId + " con " + docCount +
                " docs; mínimo 3 requeridos (contrato, factura, pago).");
        }

        Map<String, Object> manifest = Map.of(
            "disputeCaseId", disputeId.toString(),
            "documentCount", docCount
        );
        String canonical = manifest.toString();
        String hash = sha256(canonical);
        String hmac = hmacSha256Base64(canonical, resolveKey());

        jdbc.update(
            "UPDATE dispute_case SET evidence_manifest_hash = ? " +
            "WHERE tenant_id = ? AND dispute_case_id = ?",
            hash, tenant, disputeId);

        jdbc.update(
            "INSERT INTO evidence_manifest " +
            "(tenant_id, manifest_id, dispute_case_id, canonical_json, " +
            " hmac_sha256, signing_key_id) " +
            "SELECT ?, evidence_manifest_id, ?, ?::jsonb, ?, 'env:EVIDENCE_HMAC_KEY' " +
            "FROM dispute_case WHERE tenant_id = ? AND dispute_case_id = ? " +
            "ON CONFLICT DO NOTHING",
            tenant, disputeId, "{}", hmac, tenant, disputeId);

        execution.setVariable("evidenceManifestHash", hash);
    }

    private static UUID asUuid(Object v) {
        if (v == null) throw new IllegalStateException("UUID variable null");
        if (v instanceof UUID u) return u;
        return UUID.fromString(v.toString());
    }

    private String sha256(String s) {
        try {
            var md = MessageDigest.getInstance("SHA-256");
            return HexFormat.of().formatHex(md.digest(s.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private String hmacSha256Base64(String s, byte[] key) {
        try {
            Mac mac = Mac.getInstance("HmacSHA256");
            mac.init(new SecretKeySpec(key, "HmacSHA256"));
            return java.util.Base64.getEncoder()
                .encodeToString(mac.doFinal(s.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
