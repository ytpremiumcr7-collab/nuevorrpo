package com.tuempresa.dispute.delegate;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component("sendFormalNoticeDelegate")
public class SendFormalNoticeDelegate implements JavaDelegate {

    private final JdbcTemplate jdbc;
    public SendFormalNoticeDelegate(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Override
    public void execute(DelegateExecution execution) {
        UUID tenant = (UUID) execution.getVariable("tenantId");
        UUID disputeId = (UUID) execution.getVariable("disputeCaseId");
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        int updated = jdbc.update(
            "UPDATE dispute_case SET notice_sent_at = now(), " +
            "estado = 'AWAITING_ACKNOWLEDGMENT'::dispute_state, " +
            "version = version + 1 " +
            "WHERE tenant_id = ? AND dispute_case_id = ? " +
            "AND estado = 'NOTICE_PREPARED'::dispute_state",
            tenant, disputeId);
        if (updated == 0) throw new IllegalStateException(
            "Disputa " + disputeId + " no estaba en NOTICE_PREPARED");
    }
}
