package com.tuempresa.dispute.service;

import com.tuempresa.platform.tenant.TenantContext;
import org.camunda.bpm.engine.RuntimeService;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

@Service
public class DisputeService {

    private final JdbcTemplate jdbc;
    private final RuntimeService runtimeService;
    private final ApplicationEventPublisher events;

    public DisputeService(JdbcTemplate jdbc, RuntimeService runtimeService,
                          ApplicationEventPublisher events) {
        this.jdbc = jdbc; this.runtimeService = runtimeService; this.events = events;
    }

    @Transactional
    public UUID open(UUID compensationCaseId, UUID paymentId, UUID contractId,
                     String jurisdiction, String contractType,
                     BigDecimal amountClaimed, UUID createdBy) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        // Idempotencia por unique constraint
        var existing = jdbc.query(
            "SELECT dispute_case_id FROM dispute_case " +
            "WHERE tenant_id = ? AND compensation_case_id = ?",
            (rs, i) -> rs.getObject(1, UUID.class),
            tenant, compensationCaseId);
        if (!existing.isEmpty()) return existing.get(0);

        // Resolver deadline desde dispute_phase_config
        String timeUnit = jdbc.query(
            "SELECT time_unit FROM dispute_phase_config " +
            "WHERE contract_type = ? AND jurisdiction = ? AND phase = 'NOTICE' " +
            "UNION ALL " +
            "SELECT time_unit FROM dispute_phase_config " +
            "WHERE contract_type = ? AND jurisdiction = '*' AND phase = 'NOTICE' " +
            "LIMIT 1",
            rs -> rs.next() ? rs.getString(1) : null,
            contractType, jurisdiction, contractType);
        if (timeUnit == null) {
            throw new IllegalStateException(
                "No hay configuración de plazo para " + contractType + "/" + jurisdiction);
        }
        int duration = jdbc.queryForObject(
            "SELECT duration FROM dispute_phase_config " +
            "WHERE contract_type = ? AND jurisdiction IN (?, '*') AND phase = 'NOTICE' " +
            "ORDER BY (jurisdiction = ?) DESC LIMIT 1",
            Integer.class, contractType, jurisdiction, jurisdiction);

        LocalDate deadline = "BUSINESS_DAYS".equals(timeUnit)
            ? jdbc.queryForObject("SELECT add_business_days(?, CURRENT_DATE, ?)",
                                  LocalDate.class, jurisdiction, duration)
            : jdbc.queryForObject("SELECT add_calendar_days(CURRENT_DATE, ?)",
                                  LocalDate.class, duration);

        UUID caseId = UUID.randomUUID();
        UUID manifestId = UUID.randomUUID();
        jdbc.update("""
            INSERT INTO dispute_case
              (tenant_id, dispute_case_id, compensation_case_id, payment_id,
               subcontractor_id, project_id, contract_id, estado, jurisdiction,
               contract_type, response_deadline, amount_claimed, amount_in_dispute,
               evidence_manifest_id, evidence_manifest_hash, created_by)
            SELECT ?, ?, ?, ?, subcontractor_id, project_id, ?, 
                   'NOTICE_PREPARED'::dispute_state, ?, ?, ?, ?, ?, ?, '', ?
              FROM compensation_case
             WHERE tenant_id = ? AND compensation_case_id = ?
            """,
            tenant, caseId, compensationCaseId, paymentId, contractId,
            jurisdiction, contractType, deadline, amountClaimed, amountClaimed,
            manifestId, createdBy, tenant, compensationCaseId);

        // Correlacionar el message start
        Map<String, Object> vars = new HashMap<>();
        vars.put("tenantId", tenant);
        vars.put("disputeCaseId", caseId);
        vars.put("compensationCaseId", compensationCaseId);
        vars.put("paymentId", paymentId);
        vars.put("jurisdiction", jurisdiction);
        vars.put("contractType", contractType);
        vars.put("responseDeadline", deadline.toString());

        runtimeService.createMessageCorrelation("DisputeOpened")
            .setVariables(vars)
            .processInstanceBusinessKey(caseId.toString())
            .correlateStartMessage();
        return caseId;
    }

    @Transactional
    public void acknowledge(UUID disputeId) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        int updated = jdbc.update(
            "UPDATE dispute_case SET acknowledgment_at = now(), " +
            "estado = 'AWAITING_RESPONSE'::dispute_state, version = version + 1 " +
            "WHERE tenant_id = ? AND dispute_case_id = ? " +
            "AND estado = 'AWAITING_ACKNOWLEDGMENT'::dispute_state",
            tenant, disputeId);
        if (updated == 0) throw new IllegalStateException(
            "Disputa " + disputeId + " no estaba en AWAITING_ACKNOWLEDGMENT");
    }

    @Transactional
    public void recordOutcome(UUID disputeId, String outcomeType, BigDecimal amountAwarded) {
        UUID tenant = TenantContext.require();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
        int updated = jdbc.update(
            "UPDATE dispute_case SET outcome = ?::dispute_outcome, " +
            "outcome_recorded_at = now(), " +
            "estado = CASE ? " +
            "  WHEN 'CONTRACTOR_WINS_TOTAL' THEN 'RESOLVED_CONTRACTOR'::dispute_state " +
            "  WHEN 'CONTRACTOR_WINS_PARTIAL' THEN 'RESOLVED_PARTIAL'::dispute_state " +
            "  WHEN 'SUBCONTRACTOR_WINS_TOTAL' THEN 'RESOLVED_SUBCONTRACTOR'::dispute_state " +
            "  WHEN 'SUBCONTRACTOR_WINS_PARTIAL' THEN 'RESOLVED_PARTIAL'::dispute_state " +
            "  ELSE 'WITHDRAWN'::dispute_state END, " +
            "version = version + 1 " +
            "WHERE tenant_id = ? AND dispute_case_id = ?",
            outcomeType, outcomeType, tenant, disputeId);
        if (updated == 0) throw new IllegalStateException(
            "Disputa " + disputeId + " no encontrada");
    }
}
