package com.tuempresa.dispute.job;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * Snapshot diario de provisión para casos de disputa abiertos.
 * Política: provisión = monto en disputa (IAS 37), ajustada por FX del día.
 * Idempotente por (tenant, date, case, seq=0).
 */
@Component
public class ProvisionSnapshotJob {

    private static final Logger log = LoggerFactory.getLogger(ProvisionSnapshotJob.class);
    private final JdbcTemplate jdbc;

    public ProvisionSnapshotJob(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    @Scheduled(cron = "0 30 2 * * *", zone = "UTC")
    @Transactional
    public void run() {
        LocalDate asOf = LocalDate.now();
        List<UUID> tenants = jdbc.queryForList(
            "SELECT tenant_id FROM tenant WHERE active = true", UUID.class);

        for (UUID tenant : tenants) {
            jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
            snapshotForTenant(tenant, asOf);
        }
    }

    private void snapshotForTenant(UUID tenant, LocalDate asOf) {
        List<Map<String,Object>> cases = jdbc.queryForList(
            "SELECT dispute_case_id, project_id, subcontractor_id, " +
            "       amount_in_dispute_functional, amount_in_dispute_contract, currency_code " +
            "FROM dispute_case_current " +
            "WHERE tenant_id = ? " +
            "  AND estado NOT IN ('RESOLVED_CONTRACTOR','WITHDRAWN','LAPSED')",
            tenant);

        for (var c : cases) {
            // Provisión = monto en disputa (política IAS 37 para disputas de construcción)
            BigDecimal provisionFunctional = (BigDecimal) c.get("amount_in_dispute_functional");
            BigDecimal provisionContract = (BigDecimal) c.get("amount_in_dispute_contract");
            BigDecimal fxRate = provisionContract.compareTo(BigDecimal.ZERO) == 0
                ? BigDecimal.ONE
                : provisionFunctional.divide(provisionContract, 6, RoundingMode.HALF_UP);

            jdbc.update("""
                INSERT INTO dispute_provision_snapshot
                  (tenant_id, snapshot_date, dispute_case_id, snapshot_seq,
                   project_id, subcontractor_id,
                   amount_in_dispute_contract, currency_code,
                   provision_contract, provision_functional,
                   fx_rate, fx_rate_date, provision_dmn_version, provision_reason)
                VALUES (?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?, ?, 'v1', 'IAS37_best_estimate')
                ON CONFLICT (tenant_id, snapshot_date, dispute_case_id, snapshot_seq)
                DO NOTHING
                """,
                tenant, asOf, c.get("dispute_case_id"),
                c.get("project_id"), c.get("subcontractor_id"),
                c.get("amount_in_dispute_contract"), c.get("currency_code"),
                provisionContract, provisionFunctional, fxRate, asOf);
        }
        log.info("Provision snapshot completado para tenant {}: {} casos",
            tenant, cases.size());
    }
}
