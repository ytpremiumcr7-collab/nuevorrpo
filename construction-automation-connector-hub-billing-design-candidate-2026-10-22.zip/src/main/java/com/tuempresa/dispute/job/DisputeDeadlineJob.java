package com.tuempresa.dispute.job;

import org.camunda.bpm.engine.RuntimeService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

/**
 * Job diario. Hace tres cosas:
 * 1) Recalcula plazos si el calendario cambió (nuevo festivo, corrección)
 * 2) Dispara caducidad para AWAITING_RESPONSE con deadline vencido
 * 3) Alerta (no caduca) para AWAITING_ACKNOWLEDGMENT con N días sin acuse
 */
@Component
public class DisputeDeadlineJob {

    private static final Logger log = LoggerFactory.getLogger(DisputeDeadlineJob.class);
    private final JdbcTemplate jdbc;
    private final RuntimeService runtimeService;

    public DisputeDeadlineJob(JdbcTemplate jdbc, RuntimeService runtimeService) {
        this.jdbc = jdbc; this.runtimeService = runtimeService;
    }

    @Scheduled(cron = "0 0 6 * * *", zone = "UTC")
    @Transactional
    public void run() {
        List<UUID> tenants = jdbc.queryForList(
            "SELECT tenant_id FROM tenant WHERE active = true", UUID.class);

        for (UUID tenant : tenants) {
            jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");
            recalculateDeadlines(tenant);
            fireLapsed(tenant);
            alertNoAcknowledgment(tenant);
        }
    }

    private void recalculateDeadlines(UUID tenant) {
        // Solo recalcula si el deadline calculado difiere del almacenado
        // (por festivo nuevo, corrección de calendario, etc.)
        jdbc.update("""
            UPDATE dispute_case d
               SET response_deadline = calc.new_deadline
              FROM (
                SELECT d2.dispute_case_id,
                       CASE c.time_unit
                         WHEN 'BUSINESS_DAYS' THEN add_business_days(
                                d2.jurisdiction, d2.notice_sent_at::date, c.duration)
                         ELSE add_calendar_days(
                                d2.notice_sent_at::date, c.duration)
                       END AS new_deadline
                  FROM dispute_case d2
                  JOIN dispute_phase_config c
                    ON c.contract_type = d2.contract_type
                   AND (c.jurisdiction = d2.jurisdiction OR c.jurisdiction = '*')
                   AND c.phase = 'NOTICE'
                 WHERE d2.tenant_id = ? AND d2.estado = 'AWAITING_RESPONSE'
              ) calc
             WHERE d.tenant_id = ? AND d.dispute_case_id = calc.dispute_case_id
               AND d.response_deadline <> calc.new_deadline
            """, tenant, tenant);
    }

    private void fireLapsed(UUID tenant) {
        var lapsed = jdbc.queryForList(
            "SELECT dispute_case_id FROM dispute_case " +
            "WHERE tenant_id = ? AND estado = 'AWAITING_RESPONSE' " +
            "AND response_deadline < CURRENT_DATE",
            tenant);
        for (var row : lapsed) {
            UUID id = (UUID) row.get("dispute_case_id");
            int correlated = runtimeService.createMessageCorrelation("DisputeResponseLapsed")
                .processInstanceBusinessKey(id.toString())
                .correlateAllWithResult().size();
            log.info("Disputa {} caducada (correlaciones: {})", id, correlated);
        }
    }

    private void alertNoAcknowledgment(UUID tenant) {
        // No caduca: solo alerta. El plazo de respuesta corre desde el ACUSE.
        var stalled = jdbc.queryForList(
            "SELECT dispute_case_id, next_action_owner_role FROM dispute_case_current " +
            "WHERE tenant_id = ? AND estado = 'AWAITING_ACKNOWLEDGMENT' " +
            "AND days_in_phase > 15", tenant);
        for (var row : stalled) {
            log.warn("Disputa {} en AWAITING_ACKNOWLEDGMENT > 15 días; alertar a {}",
                row.get("dispute_case_id"), row.get("next_action_owner_role"));
        }
    }
}
