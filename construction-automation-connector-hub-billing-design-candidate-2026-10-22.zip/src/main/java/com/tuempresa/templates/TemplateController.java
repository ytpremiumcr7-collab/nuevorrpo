package com.tuempresa.templates;

import com.tuempresa.identity.security.UserContext;
import com.tuempresa.identity.service.ProjectAuthorizationService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/templates")
public class TemplateController {
    private final DocumentTemplateService templates;
    private final ProjectAuthorizationService authorization;
    public TemplateController(DocumentTemplateService templates, ProjectAuthorizationService authorization) {
        this.templates = templates; this.authorization = authorization;
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Map<String, String> body) {
        authorization.requireOwnerOnAnyProject();
        UUID id = templates.createTemplate(body.get("code"), body.get("name"), body.get("category"),
            body.get("bodyMarkdown"), body.get("variablesJson"));
        return ResponseEntity.ok(Map.of("templateId", id));
    }

    @PostMapping("/{code}/assemble")
    @SuppressWarnings("unchecked")
    public ResponseEntity<?> assemble(@PathVariable String code, @RequestBody Map<String, Object> body) {
        UserContext.CurrentUser me = UserContext.require();
        UUID projectId = body.get("projectId") == null ? null : UUID.fromString(body.get("projectId").toString());
        if (projectId == null) authorization.requireOwnerOnAnyProject();
        else authorization.requireProjectMember(projectId);
        Map<String, String> vars = (Map<String, String>) body.get("variables");
        UUID id = templates.assemble(code, projectId, vars, me.userId());
        return ResponseEntity.ok(Map.of("assemblyId", id, "markdown", templates.getAssembledMarkdown(id)));
    }

    @GetMapping("/assemblies/{id}")
    public ResponseEntity<?> get(@PathVariable UUID id) {
        authorization.requireEntityProject(ProjectAuthorizationService.Resource.ASSEMBLED_DOCUMENT, id,
            UserContext.ProjectRole.OWNER, UserContext.ProjectRole.PROJECT_ENGINEER,
            UserContext.ProjectRole.SAFETY_LEAD, UserContext.ProjectRole.FINANCE,
            UserContext.ProjectRole.COMPLIANCE_LEAD, UserContext.ProjectRole.SUBCONTRACTOR_ADMIN,
            UserContext.ProjectRole.VIEWER);
        return ResponseEntity.ok(Map.of("markdown", templates.getAssembledMarkdown(id)));
    }
}
