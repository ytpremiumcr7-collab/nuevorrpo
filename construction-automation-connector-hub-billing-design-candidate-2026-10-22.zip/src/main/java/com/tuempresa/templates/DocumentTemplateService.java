package com.tuempresa.templates;

import com.tuempresa.platform.tenant.TenantContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Map;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Ensamblaje de plantillas markdown con variables {{nombre}}.
 * Fail-loud si falta una variable requerida.
 */
@Service
public class DocumentTemplateService {

    private static final Pattern VAR = Pattern.compile("\\{\\{\\s*([a-zA-Z0-9_]+)\\s*\\}\\}");

    private final JdbcTemplate jdbc;

    public DocumentTemplateService(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Transactional
    public UUID createTemplate(String code, String name, String category,
                               String bodyMarkdown, String variablesJson) {
        UUID tenant = TenantContext.require();
        UUID id = UUID.randomUUID();
        jdbc.update(
            "INSERT INTO document_template " +
            "(tenant_id, template_id, code, name, category, body_markdown, variables_json) " +
            "VALUES (?, ?, ?, ?, ?, ?, ?::jsonb)",
            tenant, id, code, name, category, bodyMarkdown,
            variablesJson == null ? "[]" : variablesJson);
        return id;
    }

    @Transactional
    public UUID assemble(String templateCode, UUID projectId, Map<String, String> variables, UUID by) {
        UUID tenant = TenantContext.require();
        Map<String, Object> tpl = jdbc.queryForMap(
            "SELECT template_id, body_markdown FROM document_template " +
            "WHERE tenant_id = ? AND code = ? AND active = true " +
            "ORDER BY version DESC LIMIT 1",
            tenant, templateCode);

        String body = (String) tpl.get("body_markdown");
        Matcher m = VAR.matcher(body);
        StringBuffer sb = new StringBuffer();
        while (m.find()) {
            String key = m.group(1);
            if (!variables.containsKey(key) || variables.get(key) == null) {
                throw new IllegalStateException(
                    "Variable de plantilla requerida ausente: {{" + key + "}}");
            }
            m.appendReplacement(sb, Matcher.quoteReplacement(variables.get(key)));
        }
        m.appendTail(sb);
        String output = sb.toString();

        UUID assemblyId = UUID.randomUUID();
        String varsJson;
        try {
            varsJson = new com.fasterxml.jackson.databind.ObjectMapper().writeValueAsString(variables);
        } catch (Exception e) {
            throw new IllegalStateException("No se serializaron variables", e);
        }
        jdbc.update(
            "INSERT INTO assembled_document " +
            "(tenant_id, assembly_id, template_id, project_id, output_markdown, variables_used, assembled_by) " +
            "VALUES (?, ?, ?, ?, ?, ?::jsonb, ?)",
            tenant, assemblyId, tpl.get("template_id"), projectId, output, varsJson, by);
        return assemblyId;
    }

    public String getAssembledMarkdown(UUID assemblyId) {
        UUID tenant = TenantContext.require();
        return jdbc.queryForObject(
            "SELECT output_markdown FROM assembled_document WHERE tenant_id = ? AND assembly_id = ?",
            String.class, tenant, assemblyId);
    }
}
