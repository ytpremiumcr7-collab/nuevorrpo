package com.tuempresa.platform.audit;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.tuempresa.platform.events.DomainEvent;
import com.tuempresa.platform.events.DomainEventBridge;
import org.springframework.context.event.EventListener;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;

@Component
public class AuditListener {

    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;

    public AuditListener(JdbcTemplate jdbc, ObjectMapper mapper) {
        this.jdbc = jdbc; this.mapper = mapper;
    }

    @EventListener
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void on(DomainEventBridge.CommittedEvent committed) {
        DomainEvent event = committed.event();
        UUID tenant = event.tenantId();
        jdbc.execute("SET LOCAL app.tenant_id = '" + tenant + "'");

        String prevHash = jdbc.query(
            "SELECT event_hash FROM audit_event WHERE tenant_id = ? " +
            "ORDER BY sequence_number DESC LIMIT 1",
            rs -> rs.next() ? rs.getString(1) : "", tenant);

        String payload;
        try { payload = mapper.writeValueAsString(event); }
        catch (Exception e) { throw new RuntimeException("No serializable", e); }

        String hash = jdbc.queryForObject(
            "SELECT compute_event_hash(?, ?::jsonb)",
            String.class, prevHash == null ? "" : prevHash, payload);

        jdbc.update("""
            INSERT INTO audit_event
              (tenant_id, event_id, event_type, aggregate_type, aggregate_id,
               payload, prev_hash, event_hash)
            VALUES (?, ?, ?, ?, ?, ?::jsonb, ?, ?)
            """,
            tenant, event.eventId(), event.eventType(), event.aggregateType(),
            event.aggregateId(), payload, prevHash, hash);
    }
}
