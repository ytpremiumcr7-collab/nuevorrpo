package com.tuempresa.platform.tenant;

import java.util.UUID;

public final class TenantContext {
    private static final ThreadLocal<UUID> CURRENT = new ThreadLocal<>();
    public static void set(UUID t) { CURRENT.set(t); }
    public static UUID get() { return CURRENT.get(); }
    public static UUID require() {
        UUID t = CURRENT.get();
        if (t == null) throw new IllegalStateException(
            "No hay tenant en el contexto. El filtro debe haber corrido.");
        return t;
    }
    public static void clear() { CURRENT.remove(); }
}
