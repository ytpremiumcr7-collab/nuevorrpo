package com.tuempresa.platform.tenant;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.time.ZoneId;
import java.util.UUID;

@Component
public class ProjectTimezoneResolver {

    private final JdbcTemplate jdbc;
    public ProjectTimezoneResolver(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    public ZoneId forProject(UUID projectId) {
        String tz = jdbc.queryForObject(
            "SELECT timezone FROM project WHERE project_id = ?",
            String.class, projectId);
        if (tz == null || tz.isBlank()) throw new IllegalStateException(
            "Proyecto " + projectId + " sin timezone");
        return ZoneId.of(tz);
    }
}
