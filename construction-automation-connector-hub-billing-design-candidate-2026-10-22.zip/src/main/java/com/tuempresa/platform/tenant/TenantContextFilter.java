package com.tuempresa.platform.tenant;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.MDC;
import org.springframework.core.annotation.Order;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.UUID;

/**
 * Valida X-Tenant-Id, establece ThreadLocal + MDC.
 * El SET LOCAL de Postgres lo aplica TenantJdbcAspect en cada
 * método @Transactional de servicio (misma TX = mismo connection).
 */
@Component
@Order(Ordered.HIGHEST_PRECEDENCE + 10)
public class TenantContextFilter extends OncePerRequestFilter {

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();
        return path.startsWith("/actuator")
            || path.startsWith("/error")
            || path.equals("/")
            || path.startsWith("/index.html")
            || path.startsWith("/css/")
            || path.startsWith("/js/")
            || path.startsWith("/app/")
            || path.equals("/favicon.ico")
            || path.equals("/api/health");
    }

    @Override
    protected void doFilterInternal(HttpServletRequest req, HttpServletResponse res,
                                    FilterChain chain) throws ServletException, IOException {
        String header = req.getHeader("X-Tenant-Id");
        if (header == null || header.isBlank()) {
            res.sendError(400, "Falta header X-Tenant-Id");
            return;
        }
        UUID tenant;
        try {
            tenant = UUID.fromString(header.trim());
        } catch (IllegalArgumentException e) {
            res.sendError(400, "X-Tenant-Id no es UUID");
            return;
        }

        String traceId = UUID.randomUUID().toString();
        MDC.put("tenantId", tenant.toString());
        MDC.put("traceId", traceId);
        res.setHeader("X-Trace-Id", traceId);
        TenantContext.set(tenant);
        try {
            chain.doFilter(req, res);
        } finally {
            TenantContext.clear();
            MDC.remove("tenantId");
            MDC.remove("traceId");
        }
    }
}
