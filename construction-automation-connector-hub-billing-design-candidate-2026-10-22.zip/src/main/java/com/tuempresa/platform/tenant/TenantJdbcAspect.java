package com.tuempresa.platform.tenant;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.UUID;

/**
 * Garantiza que el contexto RLS se establezca dentro de la misma transacción
 * que ejecuta un método de servicio @Transactional. El orden del advice por
 * sí solo no garantizaba que SET LOCAL ocurriera después de abrir la TX.
 */
@Aspect
@Component
@Order(0)
public class TenantJdbcAspect {
    private final JdbcTemplate jdbc;
    private final TransactionTemplate transaction;

    public TenantJdbcAspect(JdbcTemplate jdbc, PlatformTransactionManager transactionManager) {
        this.jdbc = jdbc;
        this.transaction = new TransactionTemplate(transactionManager);
    }

    @Around("@within(org.springframework.stereotype.Service) && " +
            "@annotation(org.springframework.transaction.annotation.Transactional)")
    public Object applyTenant(ProceedingJoinPoint pjp) throws Throwable {
        UUID tenant = TenantContext.get();
        final Throwable[] failure = new Throwable[1];
        Object result = transaction.execute(status -> {
            if (tenant != null) {
                jdbc.queryForObject(
                    "SELECT set_config('app.tenant_id', ?, true)", String.class, tenant.toString());
            }
            try {
                return pjp.proceed();
            } catch (Throwable ex) {
                failure[0] = ex;
                status.setRollbackOnly();
                return null;
            }
        });
        if (failure[0] != null) throw failure[0];
        return result;
    }
}
