package com.tuempresa.platform.notification;

import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;

/**
 * Deliberately not instantiated by default: current schema has role recipients,
 * but no proven project-scoped email resolver/outbound delivery contract. An
 * enabled but log-only worker would incorrectly mark notifications as sent.
 */
@Component
@ConditionalOnProperty(name = "construction.notification-worker.enabled", havingValue = "true")
public class NotificationWorker {
    public NotificationWorker() {
        throw new IllegalStateException(
            "NotificationWorker no puede habilitarse todavía: falta routing real a destinatarios y transporte verificable");
    }
}
