package com.tuempresa.platform.notification;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {
    private static final Logger log = LoggerFactory.getLogger(NotificationService.class);
    private final JavaMailSender mailSender;

    public NotificationService(ObjectProvider<JavaMailSender> mailSender) {
        this.mailSender = mailSender.getIfAvailable();
    }

    @CircuitBreaker(name = "smtp", fallbackMethod = "fallbackSend")
    public void sendEmail(String to, String subject, String body) {
        if (mailSender == null) {
            throw new IllegalStateException("SMTP no configurado; la notificación no se considera entregada");
        }
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(to);
        message.setSubject(subject);
        message.setText(body);
        mailSender.send(message);
    }

    @SuppressWarnings("unused")
    public void fallbackSend(String to, String subject, String body, Throwable t) {
        log.error("SMTP fallback for {}. Error: {}", to, t.getMessage());
        throw new RuntimeException("SMTP failure", t);
    }
}
