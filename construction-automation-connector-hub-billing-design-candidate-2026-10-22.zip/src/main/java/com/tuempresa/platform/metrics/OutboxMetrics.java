package com.tuempresa.platform.metrics;

import io.micrometer.core.instrument.Counter;
import io.micrometer.core.instrument.Gauge;
import io.micrometer.core.instrument.MeterRegistry;
import jakarta.annotation.PostConstruct;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class OutboxMetrics {

    private final JdbcTemplate jdbc;
    private final MeterRegistry registry;
    public Counter paymentsExecuted;
    public Counter paymentsBlocked;
    public Counter complianceRevoked;

    public OutboxMetrics(JdbcTemplate jdbc, MeterRegistry registry) {
        this.jdbc = jdbc;
        this.registry = registry;
    }

    @PostConstruct
    public void init() {
        Gauge.builder("outbox_dlq_count", this,
                m -> safe(() -> jdbc.queryForObject("SELECT ops_outbox_dlq_count()", Long.class)))
            .register(registry);
        Gauge.builder("outbox_pending_count", this,
                m -> safe(() -> jdbc.queryForObject("SELECT ops_outbox_pending_count()", Long.class)))
            .register(registry);
        paymentsExecuted = Counter.builder("billing.payments.executed").register(registry);
        paymentsBlocked = Counter.builder("billing.payments.blocked").register(registry);
        complianceRevoked = Counter.builder("compliance.revocations").register(registry);
    }

    private double safe(java.util.function.Supplier<Long> s) {
        try {
            Long v = s.get();
            return v == null ? 0 : v.doubleValue();
        } catch (Exception e) {
            return -1;
        }
    }
}
