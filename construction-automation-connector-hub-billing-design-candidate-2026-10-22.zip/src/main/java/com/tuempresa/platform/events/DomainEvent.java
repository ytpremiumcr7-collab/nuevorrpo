package com.tuempresa.platform.events;

import java.time.Instant;
import java.util.UUID;

public abstract class DomainEvent {
    private final UUID eventId = UUID.randomUUID();
    private final Instant occurredAt = Instant.now();
    public UUID eventId() { return eventId; }
    public Instant occurredAt() { return occurredAt; }
    public abstract UUID tenantId();
    public abstract UUID aggregateId();
    public abstract long aggregateVersion();
    public abstract String eventType();
    public abstract String aggregateType();
}
