package com.tuempresa.platform.events;

import com.tuempresa.compliance.projector.ComplianceAsyncProjector;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.List;

/** Claim y procesamiento en transacciones distintas para evitar locks prolongados. */
@Component
@ConditionalOnProperty(name = "construction.outbox.worker.enabled", havingValue = "true")
public class OutboxPoller {
    private static final int MAX_ATTEMPTS = 8;
    private final JdbcTemplate jdbc;
    private final ComplianceAsyncProjector projector;
    private final TransactionTemplate tx;

    public OutboxPoller(@Qualifier("outboxJdbcTemplate") JdbcTemplate jdbc,
                        ComplianceAsyncProjector projector,
                        @Qualifier("outboxTransactionManager") PlatformTransactionManager txManager) {
        this.jdbc = jdbc;
        this.projector = projector;
        this.tx = new TransactionTemplate(txManager);
    }

    @Scheduled(fixedDelay = 1000)
    public void claimAndProcess() {
        List<OutboxRow> batch = claimBatch();
        for (OutboxRow row : batch) processOne(row);
    }

    private List<OutboxRow> claimBatch() {
        return tx.execute(status -> jdbc.query("SELECT * FROM claim_projection_outbox(?)",
            (rs, i) -> new OutboxRow(
                rs.getObject("id", java.util.UUID.class),
                rs.getObject("tenant_id", java.util.UUID.class),
                rs.getObject("event_id", java.util.UUID.class),
                rs.getObject("aggregate_id", java.util.UUID.class),
                rs.getLong("aggregate_version"),
                rs.getString("event_type"), rs.getString("payload"), rs.getShort("attempts")), 50));
    }

    private void processOne(OutboxRow row) {
        try {
            tx.executeWithoutResult(status -> {
                setTenant(row.tenantId());
                route(row);
                int changed = jdbc.update(
                    "UPDATE projection_outbox SET status = 'PROCESSED', processed_at = now(), last_error = null " +
                    "WHERE tenant_id = ? AND id = ? AND status = 'PROCESSING'",
                    row.tenantId(), row.id());
                if (changed != 1) throw new IllegalStateException("No se pudo finalizar outbox " + row.id());
            });
        } catch (Exception e) {
            short attempts = row.attempts();
            tx.executeWithoutResult(status -> {
                setTenant(row.tenantId());
                int changed;
                if (attempts >= MAX_ATTEMPTS) {
                    changed = jdbc.update(
                        "UPDATE projection_outbox SET status = 'DEAD_LETTERED', attempts = ?, " +
                        "dead_lettered_at = now(), last_error = ? " +
                        "WHERE tenant_id = ? AND id = ? AND status = 'PROCESSING'",
                        attempts, truncate(e.getMessage()), row.tenantId(), row.id());
                } else {
                    long base = (long) Math.pow(2, attempts);
                    double jitter = 0.7 + Math.random() * 0.6;
                    changed = jdbc.update(
                        "UPDATE projection_outbox SET status = 'PENDING', attempts = ?, " +
                        "next_retry_at = now() + (interval '1 second' * ?), last_error = ? " +
                        "WHERE tenant_id = ? AND id = ? AND status = 'PROCESSING'",
                        attempts, (long) (base * jitter), truncate(e.getMessage()), row.tenantId(), row.id());
                }
                if (changed != 1) throw new IllegalStateException("No se pudo reprogramar outbox " + row.id());
            });
        }
    }

    private void route(OutboxRow row) {
        if (row.eventType() == null || row.eventType().isBlank()) {
            throw new IllegalStateException("Evento outbox sin event_type: " + row.id());
        }
        switch (row.eventType()) {
            case "ComplianceDocumentUploaded" -> projector.apply(row);
            default -> throw new IllegalStateException("Tipo outbox sin handler registrado: " + row.eventType());
        }
    }

    private void setTenant(java.util.UUID tenant) {
        jdbc.queryForObject("SELECT set_config('app.tenant_id', ?, true)", String.class, tenant.toString());
    }

    private String truncate(String value) {
        return value == null ? null : (value.length() > 2000 ? value.substring(0, 2000) : value);
    }
}
