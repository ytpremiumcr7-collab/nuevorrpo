package com.tuempresa.platform.events;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.UUID;

public record OutboxRow(
    UUID id, UUID tenantId, UUID eventId, UUID aggregateId,
    long aggregateVersion, String eventType, String payload, short attempts
) {
    private static final ObjectMapper MAPPER = new ObjectMapper();

    public UUID documentoIdFromPayload() {
        try {
            JsonNode root = MAPPER.readTree(payload);
            if (root == null || !root.isObject()) {
                throw new IllegalArgumentException("Payload outbox no es un objeto JSON");
            }
            JsonNode node = root.get("documentoId");
            if (node == null || node.isNull()) {
                throw new IllegalArgumentException("documentoId es obligatorio para el handler de este evento");
            }
            if (!node.isTextual() || node.asText().isBlank()) {
                throw new IllegalArgumentException("documentoId debe ser UUID textual");
            }
            return UUID.fromString(node.asText());
        } catch (Exception e) {
            throw new IllegalStateException("Payload outbox inválido para documentoId, evento=" + eventId, e);
        }
    }
}
