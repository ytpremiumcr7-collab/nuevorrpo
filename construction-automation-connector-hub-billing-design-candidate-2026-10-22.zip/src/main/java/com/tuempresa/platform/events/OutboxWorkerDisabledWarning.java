package com.tuempresa.platform.events;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.stereotype.Component;

@Component
@ConditionalOnProperty(name = "construction.outbox.worker.enabled", havingValue = "false", matchIfMissing = true)
public class OutboxWorkerDisabledWarning implements ApplicationRunner {
    private static final Logger log = LoggerFactory.getLogger(OutboxWorkerDisabledWarning.class);
    @Override
    public void run(ApplicationArguments args) {
        log.error("OUTBOX WORKER DESHABILITADO: projection_outbox puede acumular eventos; configure OUTBOX_WORKER_ENABLED=true y credenciales separadas outbox_worker antes de operación real.");
    }
}
