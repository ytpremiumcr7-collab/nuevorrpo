package com.tuempresa.platform.events;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Publica el evento al outbox DENTRO de la transacción del emisor.
 * El DomainEventBridge lo re-emite a Spring DESPUÉS del commit.
 */
@Component
public class OutboxPublisher {

    private final JdbcTemplate jdbc;
    private final ObjectMapper mapper;

    public OutboxPublisher(JdbcTemplate jdbc, ObjectMapper mapper) {
        this.jdbc = jdbc; this.mapper = mapper;
    }

    @Transactional(propagation = Propagation.MANDATORY)
    public void publish(DomainEvent event) {
        try {
            String payload = mapper.writeValueAsString(event);
            jdbc.update("""
                INSERT INTO projection_outbox
                  (tenant_id, event_id, aggregate_type, aggregate_id,
                   aggregate_version, event_type, payload)
                VALUES (?, ?, ?, ?, ?, ?, ?::jsonb)
                ON CONFLICT (tenant_id, event_id) DO NOTHING
                """,
                event.tenantId(), event.eventId(), event.aggregateType(),
                event.aggregateId(), event.aggregateVersion(),
                event.eventType(), payload);
        } catch (Exception e) {
            throw new RuntimeException("Falló publicación de evento: " + event.eventType(), e);
        }
    }
}
