package com.tuempresa.platform.events;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.transaction.PlatformTransactionManager;

import javax.sql.DataSource;

/**
 * The cross-tenant outbox claim function must never be available to the HTTP API credential.
 * This configuration activates only when a separately provisioned worker datasource is enabled.
 */
@Configuration(proxyBeanMethods = false)
@ConditionalOnProperty(name = "construction.outbox.worker.enabled", havingValue = "true")
public class OutboxDataSourceConfiguration {

    // Defining a second DataSource makes Boot's default DataSource bean back off, so define
    // the normal API datasource explicitly when the worker isolation profile is enabled.
    @Bean(name = "dataSourceProperties")
    @Primary
    @ConfigurationProperties("spring.datasource")
    public DataSourceProperties mainDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean(name = "dataSource")
    @Primary
    @ConfigurationProperties("spring.datasource.hikari")
    public HikariDataSource mainDataSource(
            @Qualifier("dataSourceProperties") DataSourceProperties properties) {
        return properties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
    }

    @Bean(name = "transactionManager")
    @Primary
    public PlatformTransactionManager transactionManager(@Qualifier("dataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }

    @Bean(name = "outboxDataSourceProperties")
    @ConfigurationProperties("construction.outbox.datasource")
    public DataSourceProperties outboxDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean(name = "outboxDataSource")
    @ConfigurationProperties("construction.outbox.datasource.hikari")
    public HikariDataSource outboxDataSource(
            @Qualifier("outboxDataSourceProperties") DataSourceProperties properties) {
        return properties.initializeDataSourceBuilder().type(HikariDataSource.class).build();
    }

    @Bean(name = "outboxJdbcTemplate")
    public JdbcTemplate outboxJdbcTemplate(@Qualifier("outboxDataSource") DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean(name = "outboxTransactionManager")
    public PlatformTransactionManager outboxTransactionManager(
            @Qualifier("outboxDataSource") DataSource dataSource) {
        return new DataSourceTransactionManager(dataSource);
    }
}
