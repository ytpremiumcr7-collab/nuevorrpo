package com.tuempresa.platform.events;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

/**
 * Crítico: el bridge solo re-emite a Spring DESPUÉS del commit.
 * Así AuditListener escribe al audit_event solo si el evento quedó persistido.
 * Sin esto, el audit chain se rompe con eventos de transacciones revertidas.
 */
@Component
public class DomainEventBridge {

    private final ApplicationEventPublisher publisher;
    public DomainEventBridge(ApplicationEventPublisher publisher) { this.publisher = publisher; }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT)
    public void onCommitted(DomainEvent event) {
        publisher.publishEvent(new CommittedEvent(event));
    }

    public record CommittedEvent(DomainEvent event) {}
}
