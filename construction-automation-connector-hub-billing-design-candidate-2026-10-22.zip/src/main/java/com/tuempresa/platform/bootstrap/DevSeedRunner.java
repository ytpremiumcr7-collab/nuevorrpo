package com.tuempresa.platform.bootstrap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.UUID;

@Component
public class DevSeedRunner implements ApplicationRunner {

    private static final Logger log = LoggerFactory.getLogger(DevSeedRunner.class);
    private final JdbcTemplate jdbc;
    private final boolean enabled;

    public DevSeedRunner(JdbcTemplate jdbc,
                         @Value("${app.dev-seed:false}") boolean enabled) {
        this.jdbc = jdbc;
        this.enabled = enabled;
    }

    @Override
    public void run(ApplicationArguments args) {
        if (!enabled) return;
        UUID tenantId = UUID.fromString("11111111-1111-1111-1111-111111111111");
        UUID userId = UUID.fromString("22222222-2222-2222-2222-222222222222");
        UUID projectId = UUID.fromString("33333333-3333-3333-3333-333333333333");

        jdbc.update(
            "INSERT INTO tenant (tenant_id, name, active) VALUES (?, 'Dev Tenant', true) ON CONFLICT DO NOTHING",
            tenantId);
        jdbc.execute("SET app.tenant_id = '" + tenantId + "'");
        jdbc.update(
            "INSERT INTO app_user (tenant_id, user_id, email, display_name) " +
            "VALUES (?, ?, 'ops@dev.local', 'Ops Dev') ON CONFLICT DO NOTHING",
            tenantId, userId);
        jdbc.update(
            "INSERT INTO project_membership (tenant_id, project_id, user_id, role) " +
            "VALUES (?, ?, ?, 'OWNER'::project_role) ON CONFLICT DO NOTHING",
            tenantId, projectId, userId);
        jdbc.update(
            "INSERT INTO document_template " +
            "(tenant_id, template_id, code, name, category, body_markdown, variables_json) " +
            "VALUES (?, ?, 'RFI_STANDARD', 'RFI estándar', 'RFI', " +
            "'# RFI {{rfi_number}}\n\nProyecto: {{project_name}}\n\n**Pregunta:**\n{{question}}\n\n**Respuesta:**\n{{answer}}\n', " +
            "'[\"rfi_number\",\"project_name\",\"question\",\"answer\"]'::jsonb) " +
            "ON CONFLICT DO NOTHING",
            tenantId, UUID.randomUUID());
        log.info("Dev seed OK tenant={} user={}", tenantId, userId);
    }
}
