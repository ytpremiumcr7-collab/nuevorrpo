package com.tuempresa.platform.health;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

/**
 * Usa funciones SECURITY DEFINER para contar DLQ sin filtrar por RLS de tenant.
 */
@Component
public class DeadLetterHealthIndicator implements HealthIndicator {

    private final JdbcTemplate jdbc;

    public DeadLetterHealthIndicator(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    @Override
    public Health health() {
        try {
            Long dlq = jdbc.queryForObject("SELECT ops_outbox_dlq_count()", Long.class);
            Long stuck = jdbc.queryForObject("SELECT ops_outbox_stuck_count()", Long.class);
            if ((dlq != null && dlq > 0) || (stuck != null && stuck > 0)) {
                return Health.down()
                    .withDetail("dead_lettered", dlq)
                    .withDetail("stuck_pending", stuck)
                    .build();
            }
            return Health.up()
                .withDetail("dead_lettered", 0)
                .withDetail("stuck_pending", 0)
                .build();
        } catch (Exception e) {
            return Health.unknown().withDetail("error", e.getMessage()).build();
        }
    }
}
