package com.tuempresa.platform.web;

import com.tuempresa.identity.security.UserContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.time.Instant;
import java.util.Map;

/**
 * Errores estructurados: nada silencioso, nada de stack al cliente.
 * IllegalStateException = regla de negocio (409/422).
 */
@RestControllerAdvice
public class ApiExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(ApiExceptionHandler.class);

    @ExceptionHandler(UserContext.UnauthorizedException.class)
    public ResponseEntity<?> unauthorized(UserContext.UnauthorizedException e) {
        return body(HttpStatus.UNAUTHORIZED, "UNAUTHORIZED", e.getMessage());
    }

    @ExceptionHandler(UserContext.ForbiddenException.class)
    public ResponseEntity<?> forbidden(UserContext.ForbiddenException e) {
        return body(HttpStatus.FORBIDDEN, "FORBIDDEN", e.getMessage());
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<?> badRequest(IllegalArgumentException e) {
        return body(HttpStatus.BAD_REQUEST, "BAD_REQUEST", e.getMessage());
    }

    @ExceptionHandler(IllegalStateException.class)
    public ResponseEntity<?> conflict(IllegalStateException e) {
        return body(HttpStatus.CONFLICT, "BUSINESS_RULE", e.getMessage());
    }

    @ExceptionHandler(EmptyResultDataAccessException.class)
    public ResponseEntity<?> notFound(EmptyResultDataAccessException e) {
        return body(HttpStatus.NOT_FOUND, "NOT_FOUND", "Recurso no encontrado");
    }

    @ExceptionHandler(DataAccessException.class)
    public ResponseEntity<?> dataAccess(DataAccessException e) {
        log.error("DataAccessException: {}", e.getMostSpecificCause().getMessage(), e);
        return body(HttpStatus.INTERNAL_SERVER_ERROR, "DATA_ACCESS",
            "Error de persistencia");
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<?> generic(Exception e) {
        log.error("Unhandled: {}", e.getMessage(), e);
        return body(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL",
            "Error interno");
    }

    private ResponseEntity<Map<String, Object>> body(HttpStatus status, String code, String message) {
        return ResponseEntity.status(status).body(Map.of(
            "timestamp", Instant.now().toString(),
            "status", status.value(),
            "code", code,
            "message", message == null ? "" : message
        ));
    }
}
