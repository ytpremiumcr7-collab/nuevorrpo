package com.tuempresa.platform.web;
import java.util.List;
public record PageResponse<T>(List<T> content, int page, int size, long total) {}
