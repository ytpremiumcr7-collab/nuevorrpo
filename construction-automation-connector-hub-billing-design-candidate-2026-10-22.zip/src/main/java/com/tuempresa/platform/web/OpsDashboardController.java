package com.tuempresa.platform.web;

import com.tuempresa.identity.security.UserContext;
import com.tuempresa.platform.tenant.TenantContext;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.UUID;

@RestController
@RequestMapping("/api/ops")
@Transactional(readOnly = true)
public class OpsDashboardController {
    private final JdbcTemplate jdbc;
    public OpsDashboardController(JdbcTemplate jdbc) { this.jdbc = jdbc; }

    private UUID prepareScope() {
        UUID tenant = TenantContext.require();
        UUID user = UserContext.require().userId();
        jdbc.queryForObject("SELECT set_config('app.tenant_id', ?, true)", String.class, tenant.toString());
        return user;
    }
    private static int boundedLimit(int requested) { return Math.max(1, Math.min(requested, 100)); }
    private String scoped(String tableAlias) {
        return " EXISTS (SELECT 1 FROM project_membership pm WHERE pm.tenant_id = " + tableAlias +
            ".tenant_id AND pm.project_id = " + tableAlias + ".project_id AND pm.user_id = ? AND pm.active = true) ";
    }

    @GetMapping("/summary")
    public Map<String, Object> summary() {
        UUID userId = prepareScope();
        UUID tenant = TenantContext.require();
        Long blocked = count("SELECT count(*) FROM compliance_subcontractor_head c WHERE c.tenant_id = ? AND c.estado_global = 'BLOQUEADO' AND" + scoped("c"), tenant, userId);
        Long openRfis = count("SELECT count(*) FROM rfi r WHERE r.tenant_id = ? AND r.status IN ('ROUTED','ASSIGNED','RESPONDED','ESCALATED') AND" + scoped("r"), tenant, userId);
        Long pendingPay = count("SELECT count(*) FROM payment_application p WHERE p.tenant_id = ? AND p.status IN ('PENDING_APPROVAL','PENDING_EXECUTION','PENDING','SUBMITTED') AND" + scoped("p"), tenant, userId);
        Long openSubmittals = count("SELECT count(*) FROM submittal s WHERE s.tenant_id = ? AND s.status IN ('DRAFT','SUBMITTED') AND" + scoped("s"), tenant, userId);
        return Map.of("complianceBlocked", blocked, "openRfis", openRfis,
            "pendingPayments", pendingPay, "openSubmittals", openSubmittals);
    }

    @GetMapping("/compliance-queue")
    public List<Map<String, Object>> complianceQueue(@RequestParam(defaultValue = "50") int limit) {
        UUID userId = prepareScope(); UUID tenant = TenantContext.require();
        return jdbc.queryForList("SELECT c.subcontractor_id, c.project_id, c.estado_global, c.requisito_critico_tipo, c.requisito_critico_vencimiento, c.requisitos_bloqueados, c.actualizado_en FROM compliance_subcontractor_head c WHERE c.tenant_id = ? AND c.estado_global = 'BLOQUEADO' AND" + scoped("c") + " ORDER BY c.requisito_critico_vencimiento NULLS LAST LIMIT ?", tenant, userId, boundedLimit(limit));
    }
    @GetMapping("/rfis")
    public List<Map<String, Object>> openRfis(@RequestParam(defaultValue = "50") int limit) {
        UUID userId = prepareScope(); UUID tenant = TenantContext.require();
        return jdbc.queryForList("SELECT r.rfi_id, r.project_id, r.rfi_number, r.title, r.status, r.deadline, r.created_at FROM rfi r WHERE r.tenant_id = ? AND r.status IN ('ROUTED','ASSIGNED','RESPONDED','ESCALATED') AND" + scoped("r") + " ORDER BY r.deadline NULLS LAST, r.created_at DESC LIMIT ?", tenant, userId, boundedLimit(limit));
    }
    @GetMapping("/payments/pending")
    public List<Map<String, Object>> pendingPayments(@RequestParam(defaultValue = "50") int limit) {
        UUID userId = prepareScope(); UUID tenant = TenantContext.require();
        return jdbc.queryForList("SELECT p.payment_application_id, p.invoice_id, p.project_id, p.subcontractor_id, p.amount_requested, p.status, p.created_at FROM payment_application p WHERE p.tenant_id = ? AND p.status IN ('PENDING_APPROVAL','PENDING_EXECUTION','PENDING','SUBMITTED') AND" + scoped("p") + " ORDER BY p.created_at ASC LIMIT ?", tenant, userId, boundedLimit(limit));
    }
    @GetMapping("/submittals/open")
    public List<Map<String, Object>> openSubmittals(@RequestParam(defaultValue = "50") int limit) {
        UUID userId = prepareScope(); UUID tenant = TenantContext.require();
        return jdbc.queryForList("SELECT s.submittal_id, s.project_id, s.submittal_number, s.title, s.status, s.created_at FROM submittal s WHERE s.tenant_id = ? AND s.status IN ('DRAFT','SUBMITTED') AND" + scoped("s") + " ORDER BY s.created_at ASC LIMIT ?", tenant, userId, boundedLimit(limit));
    }
    private long count(String sql, Object... args) {
        Long value = jdbc.queryForObject(sql, Long.class, args);
        return value == null ? 0 : value;
    }
}
