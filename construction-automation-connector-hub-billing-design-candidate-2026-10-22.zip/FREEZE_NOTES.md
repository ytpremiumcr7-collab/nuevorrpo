# Frozen snapshot — Construction Automation REAL-PROOF

Date: 2026-10-22 UTC

This is a frozen engineering candidate, not a production release. It is based on the previous `construction-automation-REAL-PROOF-hardened-candidate.zip` and replays the hardening changes recorded in the user's shell transcript, while retaining every file from that baseline. The original source document is included under `reference/`.

## Included changes in this snapshot
- Isolated Flyway migration job (`Dockerfile.migrator`); HTTP runtime Flyway disabled by default and no DB-owner password passed to the API.
- Migrations V18–V21: durable approval-evidence table with tenant RLS, idempotency/request context fields, invoice/contract/project/subcontractor context constraints, monetary reservation indexes/checks, and dedicated Camunda schema isolation with fail-closed detection of legacy `ACT_%` tables in `public`.
- Payment submission requires `Idempotency-Key`, hashes the canonical request, serializes key reuse, returns the prior process for an exact replay, rejects mismatched replay, and checks invoice reservation totals while locking the invoice.
- Three-way match rejects invoice header totals that differ from extended line totals.
- Testcontainers setup uses `app_user` for application datasource, `outbox_worker` for the outbox datasource, and a separate administrative JdbcTemplate for fixtures; the RLS suite covers the new approval-evidence table.
- DMN `GERENTE` route now requires manual review; added static BPMN/DMN structural validation.

## Checks executed in this environment
- `scripts/verify-hardening-static.py`: 18/18 PASS.
- `scripts/verify-workflow-models.py`: 6/6 PASS.
- `bash -n` for `run.sh`, `test.sh`, and `scripts/*.sh`: PASS.
- XML/POM/BPMN/DMN parsing and YAML/JSON parsing: PASS.
- Archive baseline preservation: all prior candidate files retained; only new/modified files added.

## Not executed / release blockers
Maven, Docker/Podman and `psql` are unavailable in the environment. Therefore compilation, JUnit/Testcontainers, Flyway against PostgreSQL, actual RLS/role privileges, and Camunda deployment/expression execution were not run. Static checks are not runtime proof.

The approval DMN is now invoked by the payment BPMN after a successful three-way match. Auto-approval is restricted to MXN below the configured threshold and persists a versioned `POLICY/APPROVED` evidence row before payment registration. Unknown currencies and manual/default routes end without creating an instruction. There is still no authenticated human-approval service, so manual approvals are not functional end-to-end. Policy-auto instructions remain `PENDING`; no bank transfer is performed. V20 intentionally blocks a database where Camunda tables already exist in `public`; that migration requires a reviewed data move before use on such an installation.
